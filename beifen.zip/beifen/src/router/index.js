import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)
const main = r => require.ensure([], () => r(require('@/page/main')), 'main')
const index = r => require.ensure([], () => r(require('@/page/index')), 'index')
const login = r => require.ensure([], () => r(require('@/page/login/index')), 'login')
const role = r => require.ensure([], () => r(require('@/page/role')), 'role')
const managerList = r => require.ensure([], () => r(require('@/page/managerList')), 'managerList')
const authority = r => require.ensure([], () => r(require('@/page/authority')), 'authority')


const coach = r => require.ensure([], () => r(require('@/page/coach/coach_list')), 'coach')
const dayoff = r => require.ensure([], () => r(require('@/page/coach/dayoff')), 'dayoff')


const videoList = r => require.ensure([], () => r(require('@/page/video/videoList')), 'videoList')
const apps = r => require.ensure([], () => r(require('@/page/apps')), 'apps')

//班级
const classlist = r => require.ensure([], () => r(require('@/page/class/class_list')), 'classlist')
const classInfo = r => require.ensure([], () => r(require('@/page/class/class_info')), 'classInfo')
const classCourseList = r => require.ensure([], () => r(require('@/page/class/class_course')), 'classCourseList')
const classInfoIndex = r => require.ensure([], () => r(require('@/page/class/class_index')), 'classInfoIndex')
const classInfoSetting = r => require.ensure([], () => r(require('@/page/class/class_setting')), 'classInfoSetting')
const classCategory = r => require.ensure([], () => r(require('@/page/class/class_category')), 'classCategory')
const classStudent = r => require.ensure([], () => r(require('@/page/class/class_student')), 'classStudent')
const classCoach = r => require.ensure([], () => r(require('@/page/class/class_coach')), 'classCoach')

//学员
const studentinfo = r => require.ensure([], () => r(require('@/page/student/student_info')), 'studentinfo')
const theorytest = r => require.ensure([], () => r(require('@/page/student/student_info_theory')), 'theorytest')
const practical = r => require.ensure([], () => r(require('@/page/student/student_info_practical')), 'practical')
const training = r => require.ensure([], () => r(require('@/page/student/student_info_training')), 'training')
const students = r => require.ensure([], () => r(require('@/page/student/students')), 'students')
const studentIndex = r => require.ensure([], () => r(require('@/page/student/student_index')), 'studentIndex')
const graduate = r => require.ensure([], () => r(require('@/page/student/graduate')), 'graduate')
const register = r => require.ensure([], () => r(require('@/page/student/register')), 'register')

const coursecategory = r => require.ensure([], () => r(require('@/page/course/course_category')), 'coursecategory')
const courselist = r => require.ensure([], () => r(require('@/page/course/course_list')), 'courselist')
const courseInfo = r => require.ensure([], () => r(require('@/page/course/course_info')), 'courseInfo')
const courseInfoVedio = r => require.ensure([], () => r(require('@/page/course/course_vedio')), 'courseInfoVedio')
const courseInfoQuestion = r => require.ensure([], () => r(require('@/page/course/course_question')), 'courseInfoQuestion')

const questions = r => require.ensure([], () => r(require('@/page/question/questions')), 'questions')
const appointment = r => require.ensure([], () => r(require('@/page/appointment')), 'appointment')
const appointmentCoach = r => require.ensure([], () => r(require('@/page/appointment_coach')), 'appointmentCoach')
const appointmentField = r => require.ensure([], () => r(require('@/page/appointment_field')), 'appointmentField')

const fieldList = r => require.ensure([], () => r(require('@/page/field/fieldList')), 'fieldList')
const planeList = r => require.ensure([], () => r(require('@/page/plane/planeList')), 'planeList')
const testRecord = r => require.ensure([], () => r(require('@/page/test-record/testRecord')), 'testRecord')

const staCoach = r => require.ensure([], () => r(require('@/page/statistics_coach')), 'staCoach')
const staStudent = r => require.ensure([], () => r(require('@/page/statistics_students')), 'staStudent')

const test = r => require.ensure([], () => r(require('@/page/test')), 'test')
const notFoundPage = r => require.ensure([], () => r(require('@/page/404')), 'notFoundPage')
export default new Router({
  //mode:'history',
  routes: [
    {
      path: '/login',
      name: 'login',
      component: login
    },
    {
      path: '/',
      name: 'main',
      component: main,
      children: [{
        path: '',
        component: index,
        meta: []
      }, {
        path: '/index',
        component: index,
        meta: ['首页', '首页']
      }, {
        path: '/test',
        component: test,
        meta: ['首页', '首页']
      },{
        path: '/404',
        component: notFoundPage,
        meta: ['首页', '首页']
      },  {
        path: '/role',
        component: role,
        meta: ['权限管理', '角色管理']
      }, {
        path: '/managerList',
        component: managerList,
        meta: ['权限管理', '账户列表']
      }, {
        path: '/authority',
        component: authority,
        meta: ['权限管理', '账户列表']
      }, {
        path: '/coursecategory',
        component: coursecategory,
        meta: ['课程管理', '课程分类']
      }, {
        path: '/courselist',
        component: courselist,
        meta: ['课程管理', '课程列表']
      }, {
        path: '/courseInfo',
        component: courseInfo,
        redirect: '/courseInfo/vedio',
        meta: ['课程管理', '课程分类'],
        children: [{
          path: '/courseInfo/vedio',
          component: courseInfoVedio,
          meta: []
        },{
          path: '/courseInfo/question',
          component: courseInfoQuestion,
          meta: []
        }
        ]
      },{
        path: '/coach',
        component: coach,
        meta: ['教练管理', '教练列表']
      }, {
        path: '/dayoff',
        component: dayoff,
        meta: ['教练管理', '请假管理']
      }, {
        path: '/graduate',
        component: graduate,
        meta: ['权限管理', '账户列表']
      }, {
        path: '/students',
        component: students,
        meta: ['学员管理', '学员列表']
      }, {
        path: '/register',
        component: register,
        meta: ['权限管理', '账户列表']
      }, {
        path: '/videoList',
        component: videoList,
        meta: ['教学资源', '视频列表']
      }, {
        path: '/apps',
        component: apps,
        meta: ['app', 'app管理']
      }, {
        path: '/classlist',
        component: classlist,
        meta: ['班级管理', '班级列表']
      },{
        path: '/classcategory',
        component: classCategory,
        meta: ['班级管理', '专业']
      }, {
        path: '/classInfo',
        component: classInfo,
        redirect: '/classInfo/index',
        meta: ['班级管理', '班级信息'],
        children: [{
          path: '/classInfo/index',
          component: classInfoIndex,
          meta: []
        },{
          path: '/classInfo/setting',
          component: classInfoSetting,
          meta: []
        }, {
          path: '/classInfo/course',
          component: classCourseList,
          meta: []
        },{
          path: '/classInfo/student',
          component: classStudent,
          meta: []
        },{
          path: '/classInfo/coach',
          component: classCoach,
          meta: []
        },
        ]
      },{
        path: '/questions',
        component: questions,
        meta: ['教学资源', '问题列表']
      }, {
        path: '/appointment',
        component: appointment,
        meta: ['权限管理', '账户列表']
      }, {
        path: '/appointmentCoach',
        component: appointmentCoach,
        meta: ['权限管理', '账户列表']
      }, {
        path: '/appointmentField',
        component: appointmentField,
        meta: ['权限管理', '账户列表']
      }, {
        path: '/fields',
        component: fieldList,
        meta: ['权限管理', '账户列表']
      }, {
        path: '/planes',
        component: planeList,
        meta: ['权限管理', '账户列表']
      }, {
        path: '/test-records',
        component: testRecord,
        meta: ['考试管理', '考试记录']
      }, {
        path: '/staStudent',
        component: staStudent,
        meta: ['权限管理', '账户列表']
      },{
        path: '/staCoach',
        component: staCoach,
        meta: ['权限管理', '账户列表']
      },
        {
        path: '/student/studentinfo',
        component: studentinfo,
        redirect: '/student/index',
        meta: ['权限管理', '账户列表'],
        children: [{
          path: '',
          component: studentIndex,
          meta: []
        },{
          path: '/student/index',
          component: studentIndex,
          meta: ['学员管理', '学员信息']
        },{
          path: '/student/theorytest',
          component: theorytest
        }, {
          path: '/student/practical',
          component: practical,
          meta: ['学员管理', '实操']
        }, {
          path: '/student/training',
          component: training,
          meta: ['学员管理', '训练']
        }]
      }
      ]
    }
  ]
})
