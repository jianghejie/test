<template>
  <div id="items" ref="items">
    <el-radio-group>
      <span class="item" v-for="item in JSON.parse(data===''?'[]':data)">
        <el-radio :label="item.label" > {{ item.label }} : {{ item.value }}</el-radio>
      </span>
    </el-radio-group>
 </div>
</template>

<script>
  export default {
    name: 'SelectView',
    props:{
      data: String,
    },

    data() {
      return {

      };
    },

    methods: {

    },
  };
</script>

<style>
  .item{
    margin-right: 15px;
  }

  .delete{
    margin-left: 8px;
  }
</style>
