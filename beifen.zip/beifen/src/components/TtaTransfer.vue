<template>
  <div class="tta-transfer">
    <el-row :gutter="20">
      <el-col :span="11">
        <el-cascader
          class="tta-transfer-category"
          placeholder="选择分类或者直接搜索"
          :options="options"
          v-model="selectedCategory"
          @change="onCateChange"
          filterable
        >
        </el-cascader>
        <div style="margin: 15px 0;"></div>
        <div class="transfer-panel">
          <div class="transfer-panel-header">
            <el-checkbox :indeterminate="leftIsIndeterminate" v-model="leftCheckAll" @change="handleLeftCheckAllChange">
              全选
            </el-checkbox>
          </div>
          <div class="transfer-panel-body">
            <ul class="trans-items">
              <el-checkbox-group v-model="leftChecked" @change="handleLeftCheckedChange">
                <li class="trans-item" v-for="item in leftData">
                  <el-checkbox  :label="item.key" :key="item.key"> {{item.label}} </el-checkbox>
                </li>
              </el-checkbox-group>
            </ul>
          </div>
        </div>
      </el-col>

      <el-col :span="2">
        <div class="transfer-buttons">
          <el-button
            type="primary"
            class="trans-button"
            @click="moveToLeft">
            <i class="el-icon-arrow-left"></i>
          </el-button>
          <el-button
            type="primary"
            class="trans-button"
            @click="moveToRight">
            <i class="el-icon-arrow-right"></i>
          </el-button>
        </div>
      </el-col>

      <el-col :span="11">
        <el-input  placeholder="搜索">
          <el-button slot="append" icon="el-icon-search"></el-button>
        </el-input>
        <div style="margin: 15px 0;"></div>
        <div class="transfer-panel">
          <div class="transfer-panel-header">
            <el-checkbox :indeterminate="rightIsIndeterminate" v-model="rightCheckAll" @change="handleRightCheckAllChange">
              全选
            </el-checkbox>
          </div>
          <div class="transfer-panel-body">
            <ul class="trans-items">
              <el-checkbox-group v-model="rightChecked" @change="handleRightCheckedChange">
                <li class="trans-item" v-for="item in rightData">
                  <el-checkbox  :label="item.key" :key="item.key"> {{item.label}} </el-checkbox>
                </li>
              </el-checkbox-group>
            </ul>
          </div>
        </div>
      </el-col>
    </el-row>
 </div>
</template>

<script>
  import {getQuestionByCate, getQuestionByCourse, getAllCourseCatgory, importQuestion, importVideo, getVideoByCate, getVideoByCourse} from '@/api/table'
  import {equals} from '@/utils/index'
  export default {
    name: 'TtaTransfer',
    props: {
      courseId: String,
      type: String,
      onSuccess: Function,
    },

    data() {
      return {
        selectedData: [],
        //选项
        options: [],
        selectedCategory: [],

        //左复选框
        leftData: [],
        leftCheckAll: false,
        leftChecked: [],
        leftIsIndeterminate: false,

        //右复选框
        rightData: [],
        rightOldData: [],
        rightCheckAll: false,
        rightChecked: [],
        rightIsIndeterminate: false,

        catCourseId: '',
        courseId: ''
      };
    },

    watch: {
      rightData: function (newData) {
        newData.forEach((item, index) => {

        })
      },
//      courseId: function(id){
//        this.fetchRightData(id);
//      }
    },

    created() {
      this.getCategory();
    },

    methods: {
      //查询左边的数据
      fetchLeftData(cid) {
        this.leftIsIndeterminate = false;
        var request;
        if(this.type === 'question'){
          request = getQuestionByCate;
        } else if(this.type === 'video') {
          request = getVideoByCate;
        }
        request(cid).then(response => {
          const result = response.data;
          if (result.code == -1) {
            this.$message({
              type: '失败',
              message: result.msg
            });
          }
          var temp = result.data;
          this.leftData = [];
          if (temp.length != 0) {
            temp.forEach((item, index) => {
              const tableItem = {
                key: item.id,
                label: this.type === 'question' ? item.content : item.name,
                catCourseId: item.catCourseId,//备用
              }
              if (!this.contains(item.id, this.rightData)) {
                this.leftData.push(tableItem);
              }
            })
          } else {

          }

        }).catch(function (error) {
          console.log(error);
        });
      },

      //查询右边的数据
      fetchRightData(cid) {
        this.rightIsIndeterminate = false;
        var request;
        if(this.type === 'question'){
          request = getQuestionByCourse;
        } else if(this.type === 'video') {
          request = getVideoByCourse;
        }
        request(cid).then(response => {
          const result = response.data;
          if (result.code == -1) {
            this.$message({
              type: '失败',
              message: result.msg
            });
          }
          var temp = result.data;
          this.rightData = [];
          this.rightOldData = [];
          if (temp.length != 0) {
            temp.forEach((item, index) => {
              const tableItem = {
                key: item.id,
                label: this.type === 'question' ? item.content : item.name,
                catCourseId: item.catCourseId,//备用
              }
              this.rightData.push(tableItem);
              this.rightOldData.push(tableItem);
            })
          } else {

          }
        }).catch(function (error) {
          console.log(error);
        });
      },

      //列出分类
      getCategory() {
        getAllCourseCatgory().then(response => {
          const result = response.data;
          if (result.code == -1) {
            this.$message({
              type: '失败',
              message: result.msg
            });
          }
          const categoryList = result.data;
          this.options = [];
          this.options = this.refining(categoryList);
        }).catch(function (error) {
          console.log(error);
        });
      },

      refining(nestJson) {
        var opts = [];
        for (var i = 0; i < nestJson.length; i++) {
          var optionItem = {
            value: nestJson[i].id,
            label: nestJson[i].name,
            //为了便于查找一个分类的完整路径加上cateCode，注意这里数据库的命名有点不统一
            catCode: this.parseCatCode(nestJson[i].cateCode),
          };

          if (nestJson[i].children) {
            optionItem.children = this.refining(nestJson[i].children);
          }
          opts.push(optionItem);
        }
        return opts;
      },

      //根据catid获得完整分类路径
      getCateRout(nestJson, catId) {
        var opts;
        for (var i = 0; i < nestJson.length; i++) {
          if (catId == nestJson[i].value) {
            opts = nestJson[i].catCode
            return opts;
          }
          if (nestJson[i].children) {
            var temp = this.getCateRout(nestJson[i].children, catId)
            if (temp != null)
              opts = temp
          }
        }
        return opts;
      },

      //把catecode解析成cascader能读取的形式,如[id1, id2, id3]
      parseCatCode(code) {
        var fullPath = []
        for (var i = 0; i < code.length / 32; i++) {
          fullPath.push(code.substring(i * 32, (i + 1) * 32))
        }
        return fullPath
      },

      //按分类获取问题
      onCateChange(newSelectedOptions) {
        this.catCourseId = newSelectedOptions[newSelectedOptions.length - 1];
        this.fetchLeftData(this.catCourseId);
      },

      //右移
      moveToRight() {
        this.leftChecked.forEach((item, index) => {
          this.rightData.push(this.getItemByKey(item, 'left'));
          //注意这里边删查注意这里边删查，要注意用在其他地方是否会出现问题
          this.deleteItemByKey(item, 'left');
        })
        this.leftChecked = [];
        this.leftCheckAll = this.leftChecked.length === this.leftData.length;
        this.rightCheckAll = this.rightChecked.length === this.rightData.length;
      },

      //左移
      moveToLeft() {
        this.rightChecked.forEach((item, index) => {
          this.leftData.push(this.getItemByKey(item, 'right'));
          //注意这里边删查注意这里边删查，要注意用在其他地方是否会出现问题
          this.deleteItemByKey(item, 'right');
        })
        this.rightChecked = [];
        this.leftCheckAll = this.leftChecked.length === this.leftData.length;
        this.rightCheckAll = this.rightChecked.length === this.rightData.length;
      },

      //判断数组中是否存在某个元素（只判断key）
      contains(key, array) {
        for (var i = 0; i < array.length; i++) {
          if (array[i].key === key) {
            return true;
          }
        }
        return false;
      },

      //根据key获得item
      getItemByKey(key, which) {
        var item;
        var data;
        if (which === 'left')
          data = this.leftData;
        else
          data = this.rightData;
        for (var i = 0; i < data.length; i++) {
          if (key === data[i].key) {
            item = data[i];
            break;
          }
        }
        return item;
      },

      //根据key删除item
      deleteItemByKey(key, which) {
        var item;
        var data;
        if (which === 'left')
          data = this.leftData;
        else
          data = this.rightData;
        for (var i = 0; i < data.length; i++) {
          if (key === data[i].key) {
            data.splice(i, 1);
            break;
          }
        }
        return item;
      },

      //左边全选事件处理
      handleLeftCheckAllChange(isAllChecked) {
        if (isAllChecked) {
          for (var i = 0; i < this.leftData.length; i++) {
            this.leftChecked.push(this.leftData[i].key);
          }
        } else {
          this.leftChecked = [];
        }
      },

      //左边复选框选中事件处理
      handleLeftCheckedChange(value) {
        let checkedCount = value.length;
        console.log(JSON.stringify(this.leftChecked));
        this.leftCheckAll = checkedCount === this.leftData.length;
        this.leftIsIndeterminate = checkedCount > 0 && checkedCount < this.leftData.length;
      },

      //右边全选事件处理
      handleRightCheckAllChange(isAllChecked) {
        if (isAllChecked) {
          for (var i = 0; i < this.rightData.length; i++) {
            this.rightChecked.push(this.rightData[i].key);
          }
        } else {
          this.rightChecked = [];
        }
      },

      //右边复选框选中事件处理
      handleRightCheckedChange(value) {
        let checkedCount = value.length;
        this.rightCheckAll = checkedCount === this.rightData.length;
        this.rightIsIndeterminate = checkedCount > 0 && checkedCount < this.rightData.length;
      },

      importAction() {
        //最终结果
        var resultItems = {addList: [],  deleteList: []};

        //求新增数据
        for (var i = 0; i < this.rightData.length; i++) {
          if (!this.contains(this.rightData[i].key, this.rightOldData)) {
            if(this.type === 'question'){
              var item = {questionId: this.rightData[i].key, courseId: this.courseId};
            } else if(this.type === 'video') {
              var item = {videoId: this.rightData[i].key, courseId: this.courseId};
            }
            resultItems.addList.push(item);
          }
        }

        //求被删除数据
        for (var i = 0; i < this.rightOldData.length; i++) {
          if (!this.contains(this.rightOldData[i].key, this.rightData)) {
            if(this.type === 'question') {
              var item = {questionId: this.rightOldData[i].key, courseId: this.courseId};
            } else if(this.type === 'video') {
              var item = {videoId: this.rightOldData[i].key, courseId: this.courseId};
            }
            resultItems.deleteList.push(item);
          }
        }

        var importRequest
        if(this.type === 'question') {
          importRequest = importQuestion;
        } else if(this.type === 'video') {
          importRequest = importVideo;
        }

        importRequest(this.courseId, resultItems).then(response => {
          const result = response.data;
          if (result.code == 0) {
            this.onSuccess();
            this.$message({
              type: 'success',
              message: '导入成功!'
            });

          } else {
            this.$message({
              type: '导入失败',
              message: result.msg
            });
          }
        }).catch(function (error) {
          this.$message({
            type: '失败',
            message: error
          });
          console.log(error);
        });
      },

      reset() {
        this.selectedCategory = [];

        this.leftData = [];
        this.leftCheckAll = false;
        this.leftChecked = [];
        this.leftIsIndeterminate = false;

        this.rightData = [];
        this.rightOldData = [];
        this.rightCheckAll = false;
        this.rightChecked = [];
        this.rightIsIndeterminate = false;
        this.fetchRightData(this.courseId);
      }
    }
  }
</script>

<style>
  .tta-transfer-category{
    width:100%;
  }
  .transfer-panel{
    border: solid 1px #d8dce5;
  }

  .transfer-panel-header{
    padding: 5px 10px 5px 10px;
    border-bottom: solid 1px #d8dce5;
  }

  .trans-items{
    height: 400px;
    overflow-y: auto;
    margin-top:15px;
  }

  .trans-item{
    padding:10px;
  }

  .transfer-buttons{
    vertical-align: middle;
    margin-top: 180px;

  }

  .transfer-footer {
    text-align: right;
    padding: 10px;
    text-align: right;
    box-sizing: border-box;
    margin-top:25px;
  }

  .trans-button{
    display: block;
    padding: 10px;
    border-radius: 50%;
    color: #fff;
    margin: 0 auto !important;
    margin-top: 20px !important;
    background-color: #409eff;
  }
</style>
