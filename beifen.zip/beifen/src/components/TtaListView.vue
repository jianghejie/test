<template>
 <div>
   <el-card class="box-card">
     <div slot="header" class="clearfix">
       <el-button v-if="hasAddButton" type="primary" size="small" icon="el-icon-plus"  @click="openAddForm">添加</el-button>
       <el-button size="mini" @click="toggleSelection(0)">全选</el-button>
       <el-button size="mini" @click="toggleSelection(1)">反选</el-button>
       <el-button size="mini" @click="toggleSelection(2)">清除</el-button>
       <el-input class="right" placeholder="搜索" v-model="input5" style="width:230px;">
         <el-button slot="append" icon="el-icon-search"></el-button>
       </el-input>
     </div>
     <el-table
       :data="tableData"
       ref="selectTable"
       border
       style="width: 100%">
       <el-table-column
         type="selection"
         width="55">
       </el-table-column>

       <el-table-column
         v-for="item in tableInfo"
         :label="item.label"
       >
         <template slot-scope="scope">
           <TtaElTableColumn
             v-if='item.renderContent'
             :render="item.renderContent"
             :data="scope.row[item.property]"
           >
           </TtaElTableColumn>
           <span v-else>
              {{ scope.row[item.property] }}
           </span>
         </template>
       </el-table-column>
       <el-table-column
         fixed="right"
         label="操作">
         <template slot-scope="scope">
           <el-button size="mini" @click="openEditForm(scope.row.id)" type="primary" plain>编辑</el-button>
           <el-button size="mini" @click="deleteItem(scope.row.id)" type="primary" plain>删除</el-button>
         </template>
       </el-table-column>
     </el-table>
     <!-- 分页 -->
     <div class="pagination-container">
       <el-pagination
         @size-change="handleSizeChange"
         @current-change="handleCurrentChange"
         :current-page="currentPage"
         :page-sizes="[5, 20, 50, 100]"
         :page-size="pageSize"
         layout="total, sizes, prev, pager, next, jumper"
         :total="totalElements">
       </el-pagination>
     </div>
   </el-card>
   <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible" :close-on-click-modal="false">
     <TtaFormRender
       :render="renderDialog"
       :form="form"
     >
     </TtaFormRender>
     <div slot="footer" class="dialog-footer">
       <el-button @click="dialogFormVisible = false">取 消</el-button>
       <el-button v-if="dialogStatus=='create'" type="primary" @click="addItem">确 定</el-button>
       <el-button v-else type="primary" @click="saveItem">确 定</el-button>
     </div>
   </el-dialog>
 </div>
</template>

<script>
  import TtaElTableColumn from '@/components/TtaElTableColumn';
  import TtaFormRender from '@/components/TtaFormRender';
  import {toast, formatTime, addSimpleData, deleteData, getOneForEdit, saveData} from '@/utils/index'
  /**
   * 通用实体列表类
   * @author jianghejie
   *
   * tableInfo格式：
   * [{property:"name" , label:"名称", renderContent:''}, {property:"location" , label:"地点"}]
   *
   * form格式
   * {name:"name" , description:"名称", title:''}
   *
   * formInfo 格式：
   * [{label:"名称", property: '', type: 'input'}, {label:"名称", property: '', type: 'input'}]
   */
  export default {
    components: {
      TtaElTableColumn,
      TtaFormRender,
    },
    name: 'tta-list-view',
    props: {
      title: String,
      hasAddButton:{
        type:Boolean,
        default:true
      } ,
      tableInfo: Array,
      formInfo: Array,
      form:{},
      addOne: Function,
      getPage: Function,
      deleteOne: Function,
      getOne: Function,
      saveOne: Function,
      renderDialog: Function
    },

    data() {
      return {
        tableData: [],
        textMap: {
          update: '编辑',
          create: '创建'
        },
        dialogStatus: '',
        //分页相关
        currentPage: 0,

        pageSize:12,
        dialogFormVisible: false
      }
    },

    created() {
      if(tableData){

      } else {
        this.fetchData(this.currentPage, this.pageSize);
      }

    },

    methods: {
      //分页查询
      fetchData(page, size) {
        this.getPage(page, size).then(response => {
          const result = response.data;
          if(result.code == -1){
            this.$message({
              type: '失败',
              message: result.msg
            });
          }
          var temp = result.data.content;
          this.tableData = temp;
        }).catch(function (error) {
          console.log(error);
        });
      },

      //打开添加表单
      openAddForm() {
        this.dialogStatus = "create"
        this.dialogFormVisible = true;
        //清空表单数据
        for (let key in this.form) {
          this.form[key] = ""
        }
      },

      //打开编辑表单
      openEditForm(id) {
        this.dialogStatus = "update"
        this.selectedId = id;
        getOneForEdit(this, id, this.getOne);
      },

      //根据id删除
      deleteItem(id) {
        deleteData(this, this.deleteOne, id, '确定删除此'+ this.title +'吗?');
      },

      //添加
      addItem() {
        addSimpleData(this, this.addOne);
      },

      //编辑
      saveItem() {
        saveData(this, this.saveOne, this.selectedId);
      },

      //处理分页数据的变化
      handleSizeChange(val) {
        this.pageSize = val;
        this.currentPage = 0;
        this.fetchData(this.currentPage, this.pageSize);
      },

      handleCurrentChange(val) {
        if(val > 1) {
          this.currentPage = val - 1;
          this.fetchData(this.currentPage, this.pageSize);
        }
      },

      toggleSelection(type){
        if(type === 0) {
          this.tableData.forEach((row, index) => {
            this.$refs.selectTable.toggleRowSelection(row,true);
          });
        } else if (type === 1) {
          this.tableData.forEach((row, index) => {
            this.$refs.selectTable.toggleRowSelection(row);
          });
        } else {
          this.$refs.selectTable.clearSelection();
        }
      },
    }
  }
</script>
