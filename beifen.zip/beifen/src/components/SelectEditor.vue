<template>
  <div id="items" ref="items">
    <el-radio-group>
      <span class="item" v-for="item in JSON.parse(data===''?'[]':data)">
        <el-radio :label="item.label" > {{ item.label }} : {{ item.value }}</el-radio>
        <el-button class="select-delete" size="mini"  @click="deleteItem(item.label)" type="primary"><i class="el-icon-close"></i></el-button>
      </span>
    </el-radio-group>
    <el-button size="mini"  @click="openAddDialog" class="select-add" type="primary"  ><i class="el-icon-plus"></i></el-button>

    <el-dialog :visible.sync="selectionDialogVisible"  append-to-body width="30%">
      <el-form :model="form">
        <el-form-item label="选项" :label-width="formLabelWidth">
          <el-input v-model="form.label"  auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="内容" :label-width="formLabelWidth">
          <el-input v-model="form.value"  auto-complete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="selectionDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="addItem">确 定</el-button>
      </div>
    </el-dialog>
 </div>
</template>

<script>
  export default {
    name: 'SelectEditor',
    props:{
      data: String,
    },

    model: {
      prop: 'data',
      event: 'change'
    },

    data() {
      return {
        selectionDialogVisible: false,
        //表单
        form: {
          label: '',
          value: '',
        },
      };
    },

    methods: {
      init(data) {

      },

      addItem() {
        //把data转换为数组
        if(this.data == ''){
          var dataArray = [];
        }else{
          var dataArray = JSON.parse(this.data);
        }

        //判断是否已经有选项存在
        var item = {label: this.form.label.toUpperCase(), value: this.form.value};
        for(var i = 0; i < dataArray.length; i++ ){
          if(dataArray[i].label.toUpperCase() === this.form.label.toUpperCase()){
            this.$message.error(this.form.label.toUpperCase() + '选项已经存在');
            return;
          }
        }

        dataArray.push(item);
        var zimu = [];

        //取出label并按字母排序
        for(var i = 0; i < dataArray.length; i++ ){
          zimu.push(dataArray[i].label);
        }
        zimu.sort();

        //根据zimu的顺序重新排序数组
        var temp= [];
        for(var i = 0; i < zimu.length; i++ ){
          for(var j = 0; j < dataArray.length; j++ ){
            if(dataArray[j].label === zimu[i]){
              var newItem = {label: dataArray[j].label.toUpperCase(), value: dataArray[j].value};
              temp.push(newItem);
              break;
            }
          }
        }
        this.$emit('change', this.data = JSON.stringify(temp));
        this.selectionDialogVisible = false;
      },

      deleteItem(label){
        var index = -1;
        var dataArray = JSON.parse(this.data);

        //获得要被删除的item的数组索引
        for(var i = 0; i < dataArray.length; i++ ){
          if(dataArray[i].label === label){
            index = i;
            break;
          }
        }

        if(index > -1){
          //删除一个选项
          dataArray.splice(index,1) ;
          //防止删除完了之后JSON.stringify(dataArray)得到一个'[]'字符串
          if(dataArray.length == 0)
            var temp = '';
          else
            var temp = JSON.stringify(dataArray);
          this.$emit('change',  this.data = temp);
        }
      },

      openAddDialog(){
        this.form.label = '';
        this.form.value = '';
        this.selectionDialogVisible = true;
      }
    },
  };
</script>

<style>
  .item{
    margin-right: 15px;
  }

  .select-add, .select-delete {
    display: inline-block;
    padding: 5px;
    border-radius: 50%;
    color: #fff;
    margin-left: 8px;;
    background-color: #409eff;
  }

</style>
