<template>
  <div class="uploader">
    <el-upload
      class="tt-uploader"
      action="http://up-z2.qiniu.com"
      :data="uploadData"
      ref="upload"
      :show-file-list="showFileList"
      :file-list="fileList"
      :auto-upload="false"
      :on-change = "onChange"
      :on-success="onUploadSuccess"
      :before-upload="beforeUpload"
      >
      <template v-if="uploadStatus === 'success' && type === 'img' || srcUrl !='' && type === 'img' ">
        <img :src="srcUrl" class="uploaded-img">
      </template>
      <template v-if="uploadStatus === 'success' && type === 'video' || srcUrl !='' && type === 'video' ">
        <video src="srcUrl" controls="controls">
          您的浏览器不支持 video 标签。
        </video>
      </template>
      <i v-else-if="uploadStatus === 'start'" class="el-icon-plus"></i>

      <i v-else-if="uploadStatus === 'uploading'" class="el-icon-loading"></i>
      <div v-else>
      </div>
    </el-upload>
 </div>
</template>

<script>
  import URI from '@/api/URI'
  export default {
    name: 'uploader',
    props:{
      onSuccess: Function,
      srcUrl: String,
      showFileList: Boolean,
      type: String
    },

    data() {
      return {
        fileList: [],
        file: {
          self: null,
          size: null,
          type: null,
          suffix: null,
        },

        // 服务器返回的令牌和一些信息
        serverToken: {
          upToken: null,
          fileName:null,
        },

        successImages: [],
        uploadData: [],
        uploadStatus: "start",

      };
    },

    methods: {
      onUploadSuccess(response, file, fileList) {
        console.log(response);
        this.srcUrl = URL.createObjectURL(file.raw);
        this.uploadStatus = "success";
        //向外传递上传成功事件
        this.onSuccess(URI.QINIU_UPLOAD_BASEURL + response.data.key);
      },

      beforeUpload(file) {
        const isJPG = this.isImage(file);
        const isVideo = this.isVideo(file);
        const isLt2M = file.size / 1024 / 1024 < 3;

        if (this.type === 'img') {
          if(!isJPG) {
            this.$message.error('请上传图片文件');
            this.reset();
            return false;
          }

          if(!isLt2M) {
            this.$message.error('大小不能超过 3MB!');
            this.reset();
            return false;
          }
        }

        if (this.type === 'video') {
          if(!isVideo) {
            this.$message.error('请上传视频文件');
            this.reset();
            return false;
          }
        }
        return true;
      },

      // 上传按钮被点击
      uploadButtonOnClick() {

        // 申请 token 成功回调
        const okCallBack = function (data) {
          this.serverToken = data;
          // 上传到七牛
          this.uploadFileToQiniu();
        };
        // 申请 token 失败回调
        const failCallBack = function (message) {
          this.buttonAvailable = true;
          this.error = message;
          this.reset();
        };
        // 获取上传 token
        this.applyUploadToken(this.file.suffix, okCallBack.bind(this), failCallBack.bind(this));
      },

      onChange(file) {
        if(this.uploadStatus != "start")
          return
        this.uploadStatus = "uploading";
        // 判断用户是否选择文件
        if (file != null) {
          this.file = {
            self: file,
            size: file.size,
            type: file.type,
            suffix: file.name.substring((file.name.lastIndexOf('.')), file.name.length).toLowerCase(),
          };
          this.uploadButtonOnClick();

        } else {
          this.reset();
        }
      },
      // 恢复默认
      reset() {
        this.file = {
          self: null,
          size: null,
          type: null,
          suffix: null,
        };
        this.uploadStatus = "start";
        this.srcUrl = "";
        this.fileList = [];
      },

      // 申请上传 token
      applyUploadToken(fileSuffixName, successCallBack, errorCallBack) {
        // 请求api
        this.$http.get(URI.APPLY_QINIUUPLOADTOKEN_API, {
          params: {
            mimeType: fileSuffixName,
            isPrivate:0
          }
        }).then((response) => {
          if (response.status === 200) {
            // 回调
            successCallBack(response.data.data);
          } else {
            errorCallBack('向服务器请求上传 token 失败');
          }
        }, () => {
          errorCallBack('检查您的网络连接');
        });
      },

      uploadFileToQiniu() {
        if (this.file.self != null) {
          this.uploadData.token = this.serverToken.upToken;
          this.uploadData.key =  this.serverToken.fileName;

          this.$refs.upload.submit();
        } else {
          this.error = '上传失败';
        }
      },

      isImage(file){
        if(typeof FileReader != 'undefined'){
          if((file.type).indexOf("image/")==-1){
            return false;
          }
        } else {
          var fileName=file.value;
          var suffixIndex=fileName.lastIndexOf(".");
          var suffix=fileName.substring(suffixIndex+1).toUpperCase();
          if(suffix!="BMP"&&suffix!="JPG"&&suffix!="JPEG"&&suffix!="PNG"&&suffix!="GIF"){
             return false
          }
        }

        return true;
      },

      isVideo(file){
        if(typeof FileReader != 'undefined'){
          if((file.type).indexOf("video/")==-1){
            return false;
          }
        } else {
          var fileName=file.value;
          var suffixIndex=fileName.lastIndexOf(".");
          var suffix=fileName.substring(suffixIndex+1).toUpperCase();
          if(suffix!="mp4"&&suffix!="flv"&&suffix!="avi"&&suffix!="rmvb"&&suffix!="mkv"){
            return false
          }
        }

        return true;
      },
    },
  };
</script>


<style>
  .tt-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }

  .tt-uploader .el-upload:hover {
    border-color: #409EFF;
  }

  .tt-uploader .el-icon-plus, .tt-uploader .el-icon-loading{
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }

  .uploaded-img {
    width: 178px;
    height: 178px;
    display: block;
  }
</style>
