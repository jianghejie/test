
<script>
  export default {
    name: 'TtaFormRender',
    functional: true,
    props:{
      render: Function,
      form: Object
    },
    render: (h, ctx) => {
      return ctx.props.render(h, ctx.props.form);
    },
  }
</script>
