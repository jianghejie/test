<template>
 <div>
   <el-card class="box-card">
     <div slot="header" class="clearfix">
       <el-button v-if="hasAddButton" type="primary" size="small" icon="el-icon-plus"  @click="openAddForm">添加</el-button>
       <el-button size="mini" @click="toggleSelection(0)">全选</el-button>
       <el-button size="mini" @click="toggleSelection(1)">反选</el-button>
       <el-button size="mini" @click="toggleSelection(2)">清除</el-button>
       <el-input class="right" placeholder="搜索" v-model="input5" style="width:230px;">
         <el-button slot="append" icon="el-icon-search"></el-button>
       </el-input>
     </div>
     <el-table
       :data="tableData"
       ref="selectTable"
       border
       style="width: 100%">
       <el-table-column
         type="selection"
         width="55">
       </el-table-column>

       <el-table-column
         v-for="item in tableInfo"
         :label="item.label"
       >
         <template slot-scope="scope">
           <TtaElTableColumn
             v-if='item.renderContent'
             :renderContent="item.renderContent"
             :data="scope.row[item.property]"
           >
           </TtaElTableColumn>
           <span v-else>
              {{ scope.row[item.property] }}
           </span>
         </template>
       </el-table-column>
     </el-table>
     <!-- 分页 -->
     <div class="pagination-container">
       <el-pagination
         @size-change="handleSizeChange"
         @current-change="handleCurrentChange"
         :current-page="currentPage"
         :page-sizes="[5, 20, 50, 100]"
         :page-size="pageSize"
         layout="total, sizes, prev, pager, next, jumper"
         :total="totalElements">
       </el-pagination>
     </div>
   </el-card>
   <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible" :close-on-click-modal="false">
     <el-form :model="form">
       <el-form-item label="科目" :label-width="formLabelWidth">
         <el-cascader
           :options="options"
           :show-all-levels="false"
           v-model="selectedOptions">
         </el-cascader>
       </el-form-item>
       <el-form-item label="试题内容" :label-width="formLabelWidth">
         <el-input v-model="form.content"  auto-complete="off"></el-input>
       </el-form-item>
       <el-form-item label="选项" :label-width="formLabelWidth">
         <SelectEditor v-model="form.selection"></SelectEditor>
       </el-form-item>
       <el-form-item label="答案" :label-width="formLabelWidth">
         <el-input v-model="form.rightAnswer" auto-complete="off"></el-input>
       </el-form-item>

       <el-form-item label="题型" :label-width="formLabelWidth">
         <el-select v-model="form.typeId" placeholder="请选择">
           <el-option
             v-for="item in typeOptions"
             :key="item.value"
             :label="item.label"
             :value="item.value">
           </el-option>
         </el-select>
       </el-form-item>

     </el-form>
     <div slot="footer" class="dialog-footer">
       <el-button @click="dialogFormVisible = false">取 消</el-button>
       <el-button v-if="dialogStatus=='create'" type="primary" @click="addItem">确 定</el-button>
       <el-button v-else type="primary" @click="saveItem">确 定</el-button>
     </div>
   </el-dialog>
 </div>
</template>

<script>
  import TtaElTableColumn from '@/components/TtaElTableColumn';
  /**
   * 通用表格类
   * tableInfo格式：
   * [{property:"name" , description:"名称", renderContent:''}, {property:"location" , description:"地点"}]
   */
  export default {
    components: {
      TtaElTableColumn,
    },
    name: 'tta-table',
    props: {
      title: String,
      hasAddButton: Boolean,
      tableData: Array,
      tableInfo: Array,
      totalElements: Number,
      pageSize: Number,
    },

    data() {
      return {
        //分页相关
        currentPage: 0,
      }
    },

  }
</script>

<style>

</style>
