
<script>
  /**
   * 表单item动态渲染（bug）
   * @author jianghejie
   */
  export default {
    name: 'TtaFormItemRender',
    functional: true,
    props:{
      type: String,
      value: Object,
      label: String
    },

    model: {
      prop: 'value',
      event: 'change'
    },

    methods: {
      onChange(newValue) {
        console.log("s");
        this.$emit('change', this.value = newValue);
      }
    },

    render: (h, ctx) => {
      if (ctx.props.type == 'input') {
        return (
          <el-form-item label={ctx.props.label}>
            <el-input  value={ctx.props.value} on-change={(newValue) => this.onChange(newValue)}  auto-complete="off"></el-input>
          </el-form-item>
        );
      } else if(ctx.props.type == 'cascader') {
        return (
          <el-form-item  label={ctx.props.label}  label-width="formLabelWidth">
            <el-cascader
              show-all-levels="false"
              v-model={ctx.props.value}>
            </el-cascader>
          </el-form-item>
        );
      }
    },
  }
</script>


