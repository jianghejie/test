<template>
 <div class="info-block">
    <div class="info-title">{{title}}</div>
    <count-to class="info-num" :startVal="0" :endVal="number" :duration="1200"></count-to>
    <div class="clear"></div>
 </div>
</template>

<script>
import CountTo from 'vue-count-to'
export default {
  components: {
    CountTo
  },
  name: 'info-block',
  props:{
    title:{
      type:String
    },
    number:{
      type:Number
    }
  }
}
</script>

<style>
.info-block{
  padding:8px;
  background-color: #fff;
  border: none;
  border-radius: 5px;
  position: relative;
  margin-bottom: 24px;
  box-shadow: 0 5px 5px 0 rgba(0,0,0,.25);
}
.info-title{
  float:left;
}
.info-num{
  float:left;
  margin-left: 15px;
  color: #5491de;
}
.clear{
  clear: both;
}
</style>


