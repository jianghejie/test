
<script>
  export default {
    name: 'TtaElTableColumn',
    functional: true,
    props:{
      render: Function,
      data:String
    },
    render: (h, ctx) => {
      return ctx.props.render(h, ctx.props.data);
    },
  }
</script>


