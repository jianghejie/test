import request from '@/network/request'

export function loginByUsername(data) {
  return request({
    url: '/auth/login',
    method: 'post',
    params: {
      username: data.username,
      password: data.password,
      deviceId: data.deviceId
    },
    headers : {
      "Authorization":'Basic dHRhOnR0YXNlY3JldA=='
    },
  })
}

export function logout() {
  return request({
    url: '/auth/login/logout',
    method: 'post'
  })
}

export function getUserInfo(token) {
  return request({
    url: '/user/info',
    method: 'get',
    params: { token }
  })
}

