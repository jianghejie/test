export default {
  //后端获取token的地址
  APPLY_QINIUUPLOADTOKEN_API: '/qi/qiniu/upload',
  //七牛上传文件的地址
  QINIU_UPLOAD_HTTP_API: 'http://up-z2.qiniu.com',
  //对象的域名
  QINIU_UPLOAD_BASEURL: 'http://p20sw0y5q.bkt.clouddn.com/',
};
