import request from '@/network/request'
const PATH_PREDIX = "/remote/admin"
//权限
const AUTHORITY = "/authorities";

//课程
const COURSE_CATE = "/course-categories";
const COURSE = "/courses";

//问题
const QUESTION = "/questions";

//视频
const VIDEO = "/videos";

//班级
const CLASS_CATE = "/class-categories";
const CLASS = "/classes";

//飞机
const PLANE = "/planes";

//场地
const FIELD = "/fields";
/**
 * 获得所有权限
 */
export function getAllAuthority() {
  return request({
    url: PATH_PREDIX + AUTHORITY,
    method: 'get'
  })
}

/**
 * 添加权限
 * @param data
 */
export function addAuthority(data) {
  return request({
    url: PATH_PREDIX + AUTHORITY,
    method: 'post',
    headers : {
      "Content-Type":'application/json; charset=UTF-8'
    },
    data
  })
}

/**
 * 删除权限
 * @param id
 */
export function deleteAuthority(id) {
  return request({
    url: PATH_PREDIX + AUTHORITY + "/" + id,
    method: 'delete',
  })
}

/**
 * 获得一个权限
 * @param id
 */
export function getAuthorityById(id) {
  var url = PATH_PREDIX + AUTHORITY + "/"  + id;
  return request({
    url: url,
    method: 'get',
  })
}

/**
 * 权限编辑的保存
 * @param data
 */
export function saveAuthority(data, id) {
  return request({
    url: PATH_PREDIX + AUTHORITY + "/"  + id,
    method: 'put',
    headers : {
      "Content-Type":'application/json; charset=UTF-8',
    },
    data
  })
}


/**
 * 添加课程分类
 * @param data
 */
export function addCourseCatgory(data) {
  return request({
    url: PATH_PREDIX + COURSE_CATE,
    method: 'post',
    headers : {
      "Content-Type":'application/json; charset=UTF-8'
    },
    data
  })
}

/**
 * 查询课程分类
 * @param data
 */
export function getCourseCatgory(id) {
  return request({
    url: PATH_PREDIX + COURSE_CATE + "/" + id,
    method: 'get',
  })
}

/**
 * 查询所有课程分类
 * @param data
 */
export function getAllCourseCatgory() {
  return request({
    url: PATH_PREDIX + COURSE_CATE,
    method: 'get',
  })
}


/**
 * 删除课程分类
 * @param data
 */
export function deleteCourseCatgory(id) {
  return request({
    url: PATH_PREDIX + COURSE_CATE + '/' + id,
    method: 'delete',
  })
}

/**
 * 分页查询课程
 * @param data
 */
export function getCourseByPage(p, size) {
  return request({
    url: PATH_PREDIX + COURSE,
    method: 'get',
    params: {
      page: p,
      size: size,
    }
  })
}

/**
 * 查询课程
 * @param data
 */
export function getCourse(id) {
  return request({
    url: PATH_PREDIX + COURSE + '/' + id,
    method: 'get',
  })
}
/**
 * 添加课程
 * @param data
 */
export function addCourse(data) {
  return request({
    url: PATH_PREDIX + COURSE,
    method: 'post',
    headers : {
      "Content-Type":'application/json; charset=UTF-8'
    },
    data
  })
}

/**
 * 删除课程
 * @param data
 */
export function deleteCourse(id) {
  return request({
    url: PATH_PREDIX + COURSE + '/' + id,
    method: 'delete',
  })
}

/**
 * 课程编辑的保存
 * @param data
 */
export function saveCourse(data, id) {
  return request({
    url: PATH_PREDIX + COURSE + '/' + id,
    method: 'put',
    headers : {
      "Content-Type":'application/json; charset=UTF-8',
    },
    data
  })
}

/**
 * 添加班级分类
 * @param data
 */
export function addClassCatgory(data) {
  return request({
    url: PATH_PREDIX + CLASS_CATE,
    method: 'post',
    headers : {
      "Content-Type":'application/json; charset=UTF-8'
    },
    data
  })
}

/**
 * 查询班级分类
 * @param data
 */
export function getClassCatgory(id) {
  return request({
    url: PATH_PREDIX + CLASS_CATE + '/' + id,
    method: 'get',
  })
}

/**
 * 查询所有班级分类
 * @param data
 */
export function getAllClassCatgory() {
  return request({
    url: PATH_PREDIX + CLASS_CATE,
    method: 'get',
  })
}


/**
 * 删除班级分类
 * @param data
 */
export function deleteClassCatgory(id) {
  return request({
    url: PATH_PREDIX + CLASS_CATE + '/' + id,
    method: 'delete',
  })
}

/**
 * 分页查询班级
 * @param data
 */
export function getClassByPage(p, size) {
  return request({
    url: PATH_PREDIX + CLASS,
    method: 'get',
    params: {
      page: p,
      size: size,
    }
  })
}

/**
 * 查询班级
 * @param data
 */
export function getClass(id) {
  return request({
    url: PATH_PREDIX + CLASS + '/' + id,
    method: 'get',
  })
}

/**
 * 添加班级
 * @param data
 */
export function addClass(data) {
  return request({
    url: PATH_PREDIX + CLASS,
    method: 'post',
    headers : {
      "Content-Type":'application/json; charset=UTF-8'
    },
    data
  })
}

/**
 * 删除班级
 * @param data
 */
export function deleteClass(id) {
  return request({
    url: PATH_PREDIX + CLASS + '/' + id,
    method: 'delete',
  })
}

/**
 * 班级编辑的保存
 * @param data
 */
export function saveClass(data, id) {
  return request({
    url: PATH_PREDIX + CLASS + '/' + id,
    method: 'put',
    headers : {
      "Content-Type":'application/json; charset=UTF-8',
    },
    data
  })
}

/**
 * 分页查询问题
 * @param data
 */
export function getQuestionByPage(p, size) {
  return request({
    url: PATH_PREDIX + QUESTION,
    method: 'get',
    params: {
      page: p,
      size: size,
    }
  })
}

/**
 * 按分类查询问题
 * @param data
 */
export function getQuestionByCate(id) {
  return request({
    url: PATH_PREDIX + COURSE_CATE + '/' + id + QUESTION,
    method: 'get',
  })
}

/**
 * 按课程查询问题
 * @param data
 */
export function getQuestionByCourse(id) {
  return request({
    url: PATH_PREDIX + COURSE + '/' + id + QUESTION,
    method: 'get',
  })
}

/**
 * 为课程导入问题
 * @param data
 */
export function importQuestion(id, data) {
  return request({
    url: PATH_PREDIX + COURSE + '/' + id + QUESTION,
    method: 'post',
    headers : {
      "Content-Type":'application/json; charset=UTF-8'
    },
    data
  })
}

/**
 * 查询问题
 * @param data
 */
export function getQuestion(id) {
  return request({
    url: PATH_PREDIX + QUESTION + '/' + id,
    method: 'get',
  })
}

/**
 * 添加问题
 * @param data
 */
export function addQuestion(data) {
  return request({
    url: PATH_PREDIX + QUESTION,
    method: 'post',
    headers : {
      "Content-Type":'application/json; charset=UTF-8'
    },
    data
  })
}

/**
 * 删除问题
 * @param data
 */
export function deleteQuestion(id) {
  return request({
    url: PATH_PREDIX + QUESTION + '/' + id,
    method: 'delete',
  })
}

/**
 * 问题编辑的保存
 * @param data
 */
export function saveQuestion(data, id) {
  return request({
    url: PATH_PREDIX + QUESTION + '/' + id,
    method: 'put',
    headers : {
      "Content-Type":'application/json; charset=UTF-8',
    },
    data
  })
}


/**
 * 分页查询视频
 * @param data
 */
export function getVideoByPage(p, size) {
  return request({
    url: PATH_PREDIX + VIDEO,
    method: 'get',
    params: {
      page: p,
      size: size,
    }
  })
}

/**
 * 查询视频
 * @param data
 */
export function getVideo(id) {
  return request({
    url: PATH_PREDIX + VIDEO + '/' + id,
    method: 'get',
  })
}

/**
 * 按分类查询视频
 * @param data
 */
export function getVideoByCate(id) {
  return request({
    url: PATH_PREDIX + COURSE_CATE + '/' + id + VIDEO,
    method: 'get',
  })
}

/**
 * 按课程查询视频
 * @param data
 */
export function getVideoByCourse(id) {
  return request({
    url: PATH_PREDIX + COURSE + '/' + id + VIDEO,
    method: 'get',
  })
}

/**
 * 为课程导入视频
 * @param data
 */
export function importVideo(id, data) {
  return request({
    url: PATH_PREDIX + COURSE + '/' + id + VIDEO,
    method: 'post',
    headers : {
      "Content-Type":'application/json; charset=UTF-8'
    },
    data
  })
}

/**
 * 添加视频
 * @param data
 */
export function addVideo(data) {
  return request({
    url: PATH_PREDIX + VIDEO,
    method: 'post',
    headers : {
      "Content-Type":'application/json; charset=UTF-8'
    },
    data
  })
}

/**
 * 删除视频
 * @param data
 */
export function deleteVideo(id) {
  return request({
    url: PATH_PREDIX + VIDEO + '/' + id,
    method: 'delete',
  })
}

/**
 * 视频编辑的保存
 * @param data
 */
export function saveVideo(data, id) {
  return request({
    url: PATH_PREDIX + VIDEO + '/' + id,
    method: 'put',
    headers : {
      "Content-Type":'application/json; charset=UTF-8',
    },
    data
  })
}

/**
 * 分页查询飞机
 * @param data
 */
export function getPlaneByPage(p, size) {
  return request({
    url: PATH_PREDIX + PLANE,
    method: 'get',
    params: {
      page: p,
      size: size,
    }
  })
}

/**
 * 查询飞机
 * @param data
 */
export function getPlane(id) {
  return request({
    url: PATH_PREDIX + PLANE + '/' + id,
    method: 'get',
  })
}

/**
 * 添加飞机
 * @param data
 */
export function addPlane(data) {
  return request({
    url: PATH_PREDIX + PLANE,
    method: 'post',
    headers : {
      "Content-Type":'application/json; charset=UTF-8'
    },
    data
  })
}

/**
 * 删除飞机
 * @param data
 */
export function deletePlane(id) {
  return request({
    url: PATH_PREDIX + PLANE + '/' + id,
    method: 'delete',
  })
}

/**
 * 飞机编辑的保存
 * @param data
 */
export function savePlane(data, id) {
  return request({
    url: PATH_PREDIX + PLANE + '/' + id,
    method: 'put',
    headers : {
      "Content-Type":'application/json; charset=UTF-8',
    },
    data
  })
}


/**
 * 分页查询场地
 * @param data
 */
export function getFieldByPage(p, size) {
  return request({
    url: PATH_PREDIX + FIELD,
    method: 'get',
    params: {
      page: p,
      size: size,
    }
  })
}

/**
 * 查询场地
 * @param data
 */
export function getField(id) {
  return request({
    url: PATH_PREDIX + FIELD + '/' + id,
    method: 'get',
  })
}

/**
 * 添加场地
 * @param data
 */
export function addField(data) {
  return request({
    url: PATH_PREDIX + FIELD,
    method: 'post',
    headers : {
      "Content-Type":'application/json; charset=UTF-8'
    },
    data
  })
}

/**
 * 删除场地
 * @param data
 */
export function deleteField(id) {
  return request({
    url: PATH_PREDIX + FIELD + '/' + id,
    method: 'delete',
  })
}

/**
 * 场地编辑的保存
 * @param data
 */
export function saveField(data, id) {
  return request({
    url: PATH_PREDIX + FIELD + '/' + id,
    method: 'put',
    headers : {
      "Content-Type":'application/json; charset=UTF-8',
    },
    data
  })
}
