// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue';
import App from './App';
import router from './router';
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import AMap from 'vue-amap';
import Vuex from 'vuex';
import store from './vuex/store';
import axios from 'axios';
import VueAxios from 'vue-axios';

Vue.config.productionTip = false
Vue.use(ElementUI);

Vue.use(Vuex)
Vue.use(AMap);
Vue.use(VueAxios, axios);

AMap.initAMapApiLoader({
  key: '5c2a10b8f0e77ac87df08feb3e786d83',
  plugin: ['AMap.Autocomplete', 'AMap.PlaceSearch', 'AMap.Scale', 'AMap.OverView', 'AMap.ToolBar', 'AMap.MapType', 'AMap.PolyEditor', 'AMap.CircleEditor']
});

router.beforeEach((to, from, next) => {
  if (to.matched.length === 0) {
    next();//from.name ? next({ name:from.name }) : next('/404');
  } else {
    next();
  }
});

router.afterEach((to, from, next) => {
  store.state.leftNavIndex = to.path;
});

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  template: '<App/>',
  components: { App }
});

//router.push('/index');
