import { getAllClassCatgory } from '@/api/table'
const app = {
  state: {
    leftNavIndex: "index",
    activeClass: [],
    classCategory: [],
    resourceCategory: []
  },

  mutations: {
    SET_CLASS_CATEGORY: (state, categoty) => {
      state.classCategory = categoty;
    },
    SET_RESOURCE_CATEGORY: (state, categoty) => {
      state.classCategory = categoty;
    },
    SET_CLASS_CATEGORY: (state, categoty) => {
      state.classCategory = categoty;
    },
  },
  actions: {
    //获取班级分类
    getAllClassCatgory({ commit }, userInfo) {
      return new Promise((resolve, reject) => {
        getAllClassCatgory(userInfo).then(response => {
          const data = response.data.data;
          commit('SET_CLASS_CATEGORY', data.access_token	);
          resolve();
        }).catch(error => {
          reject(error);
        })
      })
    },
  }
}
export default app
