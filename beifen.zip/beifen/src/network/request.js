import axios from 'axios'
import {getToken, removeToken} from '@/network/auth'
import store from '@/vuex/store.js'
import router from '@/router'
// 创建axios实例
const service = axios.create({
  baseURL: "/",
  timeout: 15000
})

// request拦截器
service.interceptors.request.use(config => {
  config.headers['Authorization'] = 'Basic dHRhOnR0YXNlY3JldA==';
  if (store.getters.token) {
    if (config.params) {
      config.params['access_token'] = getToken();
      config.params['deviceId'] = "5555";
    } else {
      config.params = {};
      config.params['access_token'] = getToken();
      config.params['deviceId'] = "5555";
    }
  }
  return config
}, error => {
  // Do something with request error
  console.log(error);
});

service.interceptors.response.use(
  response => {
    if(response.data.error === 'invalid_token'){
      store.dispatch('logOut').then(() => {
        router.push({ path: '/login' });
      }).catch(() => {
      })
    }
    if(response.data.code == '403') {
      router.push({ path: '/login' });
    }
    return response;
  },
  error => {
    if (error.response) {
      switch (error.response.status) {
        case 401:
          store.dispatch('logOut').then(() => {
            router.push({ path: '/login' });
          }).catch(() => {
          })
      }
    }
    return Promise.reject(error.response.data)
  });
export default service
