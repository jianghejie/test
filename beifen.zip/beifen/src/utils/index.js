

export function toast(obj,type, msg) {
  obj.$message({
    type: type,
    message: msg
  });
}

export function addSimpleData(obj, requestFun) {
  requestFun(obj.form).then(response => {
    const result = response.data;
    if (result.code == 0) {
      obj.$message({
        type: 'success',
        message: '添加成功!'
      });
      obj.dialogFormVisible = false;
      obj.fetchData(obj.currentPage, obj.pageSize);
    }else {
      obj.$message({
        type: '失败',
        message: result.msg
      });
    }
  }).catch(function (error) {
    obj.$message({
      type: '失败',
      message: error
    });
    console.log(error);
  });
}

export function saveData(obj, requestFun, id) {
  requestFun(obj.form, id).then(response => {
    const result = response.data;
    if (result.code == 0) {
      obj.$message({
        type: 'success',
        message: '保存成功!'
      });
      obj.dialogFormVisible = false;
      obj.fetchData();
    } else {
      obj.$message({
        type: '失败',
        message: result.msg
      });
    }
  }).catch(function (error) {
    obj.$message({
      type: '失败',
      message: error
    });
    console.log(error);
  });
}

export function deleteData(obj, requestFun, id, confirm) {
  obj.$confirm(confirm, '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    requestFun(id).then(response => {
      const result = response.data;
      if (result.code == 0) {
        obj.fetchData(obj.currentPage, obj.pageSize);
        obj.$message({
          type: 'success',
          message: '删除成功!'
        });
      }else {
        obj.$message({
          type: '失败',
          message: result.msg
        });
      }
    }).catch(function (error) {
      obj.$message({
        type: '失败',
        message: error
      });
      console.log(error);
    });
  }).catch(() => {

  });
}

export function getOneForEdit(obj, id, requestFun, successCallBack) {
  requestFun(id).then(response => {
    const result = response.data;
    if (result.code == 0) {
      for(let key in obj.form) {
        obj.form[key] = result.data[key]
      }
      obj.dialogFormVisible = true;
      if(successCallBack != null) {
        successCallBack();
      }
    } else {
      obj.$message({
        type: '失败',
        message: result.msg
      });
    }
  }).catch(function (error) {
    obj.$message({
      type: '失败',
      message: error.toString()
    });
  });
}

export function parseTime(time, cFormat) {
  if (arguments.length === 0) {
    return null
  }
  const format = cFormat || '{y}-{m}-{d} {h}:{i}:{s}'
  let date
  if (typeof time === 'object') {
    date = time
  } else {
    if (('' + time).length === 10) time = parseInt(time) * 1000
    date = new Date(time)
  }
  const formatObj = {
    y: date.getFullYear(),
    m: date.getMonth() + 1,
    d: date.getDate(),
    h: date.getHours(),
    i: date.getMinutes(),
    s: date.getSeconds(),
    a: date.getDay()
  }
  const time_str = format.replace(/{(y|m|d|h|i|s|a)+}/g, (result, key) => {
    let value = formatObj[key]
    if (key === 'a') return ['一', '二', '三', '四', '五', '六', '日'][value - 1]
    if (result.length > 0 && value < 10) {
      value = '0' + value
    }
    return value || 0
  })
  return time_str
}

/**
 * 毫秒转换友好的显示格式
 * 输出格式：21小时前
 * @param  {[type]} time [description]
 * @return {[type]}      [description]
 */
export function formatTime(date){
  //获取js 时间戳
  var time=new Date().getTime();
  //去掉 js 时间戳后三位，与php 时间戳保持一致
  time=parseInt((time-date*1000)/1000);

  //存储转换值
  var s;
  if(time<60*10){//十分钟内
    return '刚刚';
  }else if((time<60*60)&&(time>=60*10)){
    //超过十分钟少于1小时
    s = Math.floor(time/60);
    return  s+"分钟前";
  }else if((time<60*60*24)&&(time>=60*60)){
    //超过1小时少于24小时
    s = Math.floor(time/60/60);
    return  s+"小时前";
  }else if((time<60*60*24*3)&&(time>=60*60*24)){
    //超过1天少于3天内
    s = Math.floor(time/60/60/24);
    return s+"天前";
  }else{
    //超过3天
    var date= new Date(parseInt(date) * 1000);
    return date.getFullYear()+"/"+(date.getMonth()+1)+"/"+date.getDate();
  }
}

/**
 *判断两个对象是否相等
 */
export function equals ( x, y ) {
  // If both x and y are null or undefined and exactly the same
  if ( x === y ) {
    return true;
  }

  // If they are not strictly equal, they both need to be Objects
  if ( ! ( x instanceof Object ) || ! ( y instanceof Object ) ) {
    return false;
  }

  // They must have the exact same prototype chain, the closest we can do is
  // test the constructor.
  if ( x.constructor !== y.constructor ) {
    return false;
  }

  for ( var p in x ) {
    // Inherited properties were tested using x.constructor === y.constructor
    if ( x.hasOwnProperty( p ) ) {
      // Allows comparing x[ p ] and y[ p ] when set to undefined
      if ( ! y.hasOwnProperty( p ) ) {
        return false;
      }

      // If they have the same strict value or identity then they are equal
      if ( x[ p ] === y[ p ] ) {
        continue;
      }

      // Numbers, Strings, Functions, Booleans must be strictly equal
      if ( typeof( x[ p ] ) !== "object" ) {
        return false;
      }

      // Objects and Arrays must be tested recursively
      if ( ! Object.equals( x[ p ],  y[ p ] ) ) {
        return false;
      }
    }
  }

  for ( p in y ) {
    // allows x[ p ] to be set to undefined
    if ( y.hasOwnProperty( p ) && ! x.hasOwnProperty( p ) ) {
      return false;
    }
  }
  return true;
};

/**
 *秒转时分秒
 */
export function formatSeconds(value) {
  var theTime = parseInt(value);// 秒
  var theTime1 = 0;// 分
  var theTime2 = 0;// 小时
// alert(theTime);
  if(theTime > 60) {
    theTime1 = parseInt(theTime/60);
    theTime = parseInt(theTime%60);
// alert(theTime1+"-"+theTime);
    if(theTime1 > 60) {
      theTime2 = parseInt(theTime1/60);
      theTime1 = parseInt(theTime1%60);
    }
  }
  var result = ""+parseInt(theTime)+"秒";
  if(theTime1 > 0) {
    result = ""+parseInt(theTime1)+"分"+result;
  }
  if(theTime2 > 0) {
    result = ""+parseInt(theTime2)+"小时"+result;
  }
  return result;
}
