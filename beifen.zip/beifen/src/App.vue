<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style lang="less">
	@import './style/common';

  .amap-box {
    width: 500px;
    height: 500px;
  }

</style>
