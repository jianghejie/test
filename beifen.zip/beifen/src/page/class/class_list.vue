<template>
    <div class="fillcontain">
      <div class="head-top">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item :to="{ path: '/index' }">首页</el-breadcrumb-item>
          <el-breadcrumb-item>班级列表</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="main_content">

        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <el-button type="primary" size="small" icon="el-icon-plus"  @click="openAddForm">开班</el-button>
            <el-button size="mini" @click="toggleSelection(0)">全选</el-button>
            <el-button size="mini" @click="toggleSelection(1)">反选</el-button>
            <el-button size="mini" @click="toggleSelection(2)">清除</el-button>
            <el-input class="right" placeholder="搜索" v-model="input5" style="width:230px;">
              <el-button slot="append" icon="el-icon-search"></el-button>
            </el-input>
          </div>
          <el-table
            :data="tableData"
            ref="selectTable"
            border
            style="width: 100%">
            <el-table-column
              type="selection"
              width="55">
            </el-table-column>
            <el-table-column
              prop="catName"
              label="所属专业"
              :filters="[{ text: '农业无人机飞防专业', value: '1' }, { text: '理论课程', value: '2' }]"
                    :filter-method="filterTag"
                    filter-placement="bottom-end"
              width="180">
            </el-table-column>
            <el-table-column
              prop="name"
              label="班级名称">
            </el-table-column>
            <el-table-column
              prop="location"
              label="班级地点">
            </el-table-column>
            <el-table-column
              prop="coachId"
              label="教练">
              <template slot-scope="scope">
                <router-link to="/classInfo/coach">  {{ scope.row.coachId }}  </router-link>
              </template>
            </el-table-column>
            <el-table-column
              prop="tuition"
              label="学费">
            </el-table-column>
            <el-table-column
              prop="maxNum"
              label="招收人数">
            </el-table-column>
            <el-table-column
              prop="enrolledNum"
              label="报名人数">
                <template slot-scope="scope">
                     <router-link to="/classInfo/student">  {{ scope.row.register_num }}  </router-link>
                </template>
            </el-table-column>
            <el-table-column
              prop="startTime"
              label="开班时间">
            </el-table-column>
            <el-table-column
              prop="endTime"
              label="结束时间">
            </el-table-column>
             <el-table-column
               prop="state"
               label="状态">
             </el-table-column>
            <el-table-column
              fixed="right"
              width="250"
              label="操作">
              <template slot-scope="scope">
                <el-button size="mini" @click="openDetails(scope.row.id)" type="primary" plain>详情</el-button>
                <el-button size="mini" @click="openEditForm(scope.row.id)" type="primary" plain>编辑</el-button>
                <el-button size="mini" @click="deleteItem(scope.row.id)" type="primary" plain>删除</el-button>
              </template>
            </el-table-column>
          </el-table>
          <!-- 分页 -->
          <div class="pagination-container">
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="currentPage"
              :page-sizes="[5, 20, 50, 100]"
              :page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="totalElements">
            </el-pagination>
          </div>
        </el-card>

      </div>

      <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible">
        <el-form :model="form">
          <el-form-item label="专业" :label-width="formLabelWidth">
            <el-cascader
              :options="options"
              :show-all-levels="false"
              v-model="selectedOptions"
              @change="onCategorySelected">
            </el-cascader>

          </el-form-item>
          <el-form-item label="班级名称" :label-width="formLabelWidth">
            <el-input v-model="form.name" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="地点" :label-width="formLabelWidth">
            <el-input v-model="form.location" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="指定教练" :label-width="formLabelWidth">
            <el-input v-model="form.coachId" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="开班时间" :label-width="formLabelWidth">
            <el-col :span="11">
              <el-date-picker type="date" placeholder="开班" v-model="_startTime" style="width: 100%;"></el-date-picker>
            </el-col>
            <el-col class="line" :span="2" style="text-align:center">-</el-col>
            <el-col :span="11">
              <el-date-picker type="date" placeholder="结束"  v-model="_endTime" style="width: 100%;"></el-date-picker>
            </el-col>
          </el-form-item>
          <el-form-item label="培训费用" :label-width="formLabelWidth">
            <el-input v-model="form.tuition" value="200" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="培训介绍" :label-width="formLabelWidth">
            <el-input
              type="textarea"
              :rows="2"
              placeholder="请输入内容"
              v-model="form.description">
            </el-input>
          </el-form-item>
          <el-form-item label="招收人数" :label-width="formLabelWidth">
            <el-input v-model="form.maxNum" value="200" auto-complete="off"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button v-if="dialogStatus=='create'" type="primary" @click="addItem">确 定</el-button>
          <el-button v-else type="primary" @click="saveItem">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </template>

  <script>
    import {getClassByPage, deleteClass, addClass, getClass, saveClass, getAllClassCatgory} from '@/api/table'
    import {toast, formatTime, addSimpleData, deleteData, getOneForEdit, saveData} from '@/utils/index'
    export default {
      data() {
        return {
          //下拉选项相关
          options: [],
          selectedOptions: [],

          //表格
          tableData: [],
          selectedId:'',
          formLabelWidth: '120px',

          //对话框
          dialogFormVisible: false,
          textMap: {
            update: '编辑',
            create: '创建'
          },
          dialogStatus: '',

          //表单
          form: {
            name: "",
            catId: "",
            coachId: "",
            tuition: "",
            location:"",
            description: "",
            maxNum: "",
            startTime: "",
            endTime: "",
          },
          listLoading: false,

          //分页
          currentPage: 0,
          pageSize: 5,
          totalElements: 0,
        }
      },

      created() {
        this.fetchData(this.currentPage, this.pageSize);
        this.getCategory();
      },

      watch: {
        selectedOptions: function (newSelectedOptions) {
          this.form.catId = newSelectedOptions[newSelectedOptions.length-1];
        },
      },

      computed: {
        _startTime: {
          set: function(value) {
            var timestamp = Date.parse(value);
            timestamp = timestamp / 1000;
            this.form.startTime = timestamp;
          },

          get: function() {
            var newDate = new Date();
            if(this.form.startTime == "")
              return ""
            else {
              newDate.setTime(this.form.startTime * 1000);
              return newDate
            }
          }
        },

        _endTime: {
          set: function(value) {
            var timestamp = Date.parse(value);
            timestamp = timestamp / 1000;
            this.form.endTime = timestamp;
          },

          get: function() {
            var newDate = new Date();
            if(this.form.endTime == "")
              return ""
            else {
              newDate.setTime(this.form.endTime * 1000);
              return newDate
            }
          }
        }
      },

      methods: {
        //打开添加表单
        openAddForm() {
          this.dialogStatus = "create"
          this.dialogFormVisible = true;
          //清空表单数据
          for (let key in this.form) {
            this.form[key] = ""
          }
          this.selectedOptions = [];
        },

        //打开编辑表单
        openEditForm(id) {
          this.dialogStatus = "update"
          this.selectedId = id;
          var callBack = function () {
            this.selectedOptions = this.getCateRout(this.options, this.form.catId);
          };
          getOneForEdit(this, id, getClass, callBack.bind(this));
        },

        //根据id删除
        deleteItem(id) {
          deleteData(this, deleteClass, id, '确定删除此班级吗?');
        },

        //添加
        addItem() {
          addSimpleData(this, addClass);
        },

        //编辑
        saveItem() {
          saveData(this, saveClass, this.selectedId);
        },

        //分页查询
        fetchData(page, size) {
          this.listLoading = true
          getClassByPage(page, size).then(response => {
            const result = response.data;
            if(result.code == -1){
              this.$message({
                type: '失败',
                message: result.msg
              });
            }

            var temp = result.data.content;
            this.totalElements = result.data.totalElements;
            this.tableData = [];
            if(temp.length != 0){
              temp.forEach((item, index) => {
                const tableItem = {
                  id:item.id,
                  name: item.name,
                  catId: item.catId,
                  coachId: item.coachId,
                  catName:item.catName,
                  location: item.location,
                  tuition: item.tuition,
                  startTime: item.startTime,
                  endTime: item.endTime,
                  description: item.description,
                  createTime: formatTime(item.createTime),
                  enrolledNum: item.enrolledNum,
                  maxNum: item.maxNum,
                  status: item.status
                }
                this.tableData.push(tableItem)
              })
            } else {

            }

          }).catch(function (error) {
            console.log(error);
          });
          this.listLoading = false
        },

        openDetails(id){
          this.$router.push({path:'/classInfo'});
        },

        //列出分类
        getCategory() {
          getAllClassCatgory().then(response => {
            const result = response.data;
            if(result.code == -1){
              this.$message({
                type: '失败',
                message: result.msg
              });
            }
            const categoryList = result.data;
            this.options = [];
            this.options = this.refining(categoryList);

          }).catch(function (error) {
            console.log(error);
          });
        },

        //递归遍历修改原始数据项字段名为{value:'', label:''}
        refining(nestJson) {
          var opts = [];
          for (var i = 0; i < nestJson.length; i++) {
            var optionItem = {
              value: nestJson[i].id,
              label: nestJson[i].name,
              //为了便于查找一个分类的完整路径加上cateCode，注意这里数据库的命名有点不统一
              catCode: this.parseCatCode(nestJson[i].cateCode),
            };

            if (nestJson[i].children) {
              optionItem.children = this.refining(nestJson[i].children);
            }
            opts.push(optionItem);
          }
          return opts;
        },

        //根据catid获得完整分类路径
        getCateRout(nestJson, catId) {
          var opts;
          for (var i = 0; i < nestJson.length; i++) {
            if(catId == nestJson[i].value){
              opts = nestJson[i].catCode
              return opts;
            }
            if (nestJson[i].children) {
              var temp = this.getCateRout(nestJson[i].children, catId)
              if(temp != null)
                opts = temp
            }
          }
          return opts;
        },

        //把catecode解析成cascader能读取的形式,如[id1, id2, id3]
        parseCatCode(code){
          var fullPath = []
          for(var i = 0; i < code.length/32; i++){
            fullPath.push(code.substring(i*32, (i+1)*32))
          }
          return fullPath
        },

        //处理分页数据的变化
        handleSizeChange(val) {
          this.pageSize = val;
          this.currentPage = 0;
          this.fetchData(this.currentPage, this.pageSize);
        },

        handleCurrentChange(val) {
          if(val > 1) {
            this.currentPage = val - 1;
            this.fetchData(this.currentPage, this.pageSize);
          }
        },

        toggleSelection(type){
          if(type === 0) {
            this.tableData.forEach((row, index) => {
              this.$refs.selectTable.toggleRowSelection(row,true);
            });
          } else if (type === 1) {
            this.tableData.forEach((row, index) => {
              this.$refs.selectTable.toggleRowSelection(row);
            });
          } else {
            this.$refs.selectTable.clearSelection();
          }
        },

      }
    }
  </script>
