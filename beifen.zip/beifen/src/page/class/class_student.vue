<template>
    <div>
      <div>
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            共100名学员
          </div>
          <el-table
            :data="tableData"
            style="width: 100%">
            <el-table-column
              prop="name"
              label="姓名">
            </el-table-column>
            <el-table-column
              prop="sex"
              label="性别">
            </el-table-column>
            <el-table-column
              prop="phone"
              label="电话">
            </el-table-column>

            <el-table-column
              prop="progress"
              label="学习进度">
                <template slot-scope="scope">
                  <el-progress :percentage="70"></el-progress>
                </template>
            </el-table-column>

            <el-table-column
              prop="reg_time"
              label="注册时间">
            </el-table-column>
            <el-table-column
              prop="last_login"
              label="上次登录">
            </el-table-column>

          </el-table>
          <!-- 分页 -->
          <div class="pagination-container">
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="currentPage4"
              :page-sizes="[100, 200, 300, 400]"
              :page-size="100"
              layout="total, sizes, prev, pager, next, jumper"
              :total="400">
            </el-pagination>
          </div>
        </el-card>
      </div>

      <el-dialog title="学员信息" :visible.sync="dialogFormVisible">
        <el-form :model="form">
          <el-form-item label="姓名" :label-width="formLabelWidth">
            <el-input v-model="form.name" value="ss" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="性别" :label-width="formLabelWidth">
            <el-input v-model="form.description" value="xx" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="电话" :label-width="formLabelWidth">
            <el-input v-model="form.description" value="xx" auto-complete="off"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </template>

  <script>
    export default {
      data() {
        return {
          tableData: [{
            name: '郝莹',
            sex: '女',
            phone: '18210773363',
            class: 'AOPA一期',
            reg_time: '2017.11.1',
            last_login: '2017.11.05'
          }, {
            name: '郝莹',
            sex: '女',
            phone: '18210773363',
            class: 'AOPA一期',
            reg_time: '2017.11.1',
            last_login: '2017.11.05'
          }, {
            name: '郝莹',
            sex: '女',
            phone: '18210773363',
            class: 'AOPA一期',
            reg_time: '2017.11.1',
            last_login: '2017.11.05'
           }],
          dialogTableVisible: false,
          dialogFormVisible: false,
          form: {
            name: '',
            region: '',
            date1: '',
            date2: '',
            delivery: false,
            type: [],
            resource: '',
            desc: ''
          },
          formLabelWidth: '120px',
          isIndeterminate: true
        }
      },
      methods: {
        handleCheckAllChange(val) {
          this.checkedCities = val ? cityOptions : [];
          this.isIndeterminate = false;
        },
        handleCheckedCitiesChange(value) {
          let checkedCount = value.length;
          this.checkAll = checkedCount === this.cities.length;
          this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length;
        },
        openDetail (){
          this.$router.push({path:'/student/studentinfo'});
        },
        deleteItem() {
          this.$confirm('确定删除此学员吗?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            });
          }).catch(() => {

          });
        }
      }
    }
  </script>
