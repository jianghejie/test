<template>
  <div>
    <el-row :gutter="30">
      <el-col :span="12">
        <div class="grid-content bg-purple">
          <div class="chart-box">
            <div class="chart-box-title">概要<span></span></div>
            <div class="chart">
              <el-table
                :data="tableData"
                style="width: 100%"
                border>
                <el-table-column
                  prop="type"
                  label="类型"
                  >
                </el-table-column>
                <el-table-column
                  prop="num"
                  label="人数"
                 >
                </el-table-column>
                <el-table-column
                  fixed="right"
                  label="操作">
                  <template slot-scope="scope">
                    <el-button type="text" size="small"  @click="openDetails(scope.$index, scope.row)">查看</el-button>
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </div>
        </div>
      </el-col>
      <el-col :span="12">
        <div class="grid-content bg-purple">
          <div class="chart-box">
            <div class="chart-box-title">进度<span></span></div>
            <div id="progress" class="chart"></div>
          </div>
        </div>
      </el-col>
    </el-row>
    <el-row :gutter="30">
      <el-col :span="12">
        <div class="grid-content bg-purple">
          <div class="chart-box">
            <div class="chart-box-title"><span>课程表</span></div>
            <div id="schedule"  class="chart"></div>
          </div>
        </div>
      </el-col>
      <el-col :span="12">
        <div class="grid-content bg-purple">
          <div class="chart-box">
            <div class="chart-box-title">考勤<span></span></div>
            <div id="absent" class="chart"></div>
          </div>
        </div>
      </el-col>
    </el-row>

  </div>

</template>
<script>
  import echarts from 'echarts/lib/echarts';
  // 引入柱状图
  import 'echarts/lib/chart/bar';
  import 'echarts/lib/chart/line';
  import 'echarts/lib/component/title';
  import 'echarts/lib/component/legend';
  import 'echarts/lib/component/toolbox';
  import 'echarts/lib/component/markPoint';
  import 'echarts/lib/component/tooltip';

  export default {

    data() {
      return {
        tableData: [{
          type: '学员',
          num: '100'

        }, {
          type: '教练',
          num: '2'
        },  {
          type: '课程',
          num: '50'
        }],
        dialogTableVisible: false,
        dialogFormVisible: false,
        form: {
          name: '',
          region: '',
          date1: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          desc: ''
        },
        formLabelWidth: '120px',
        checkAll: false,
        checkedCities: ['培训课程', '资料分类'],
        isIndeterminate: true
      }
    },
    mounted(){
      this.drawProgress();
      this.drawAbsent();
    },
    deactivated () {
      this.$destroy()
    },
    methods: {
      drawProgress(){
        this.myChart = echarts.init(document.getElementById('progress'));
        var seriesLabel = {
          normal: {
            show: true,
            textBorderColor: '#333',
            textBorderWidth: 2
          }
        };
        var option = {
          title : {
            text: ''
          },
          tooltip : {
            trigger: 'axis'
          },
          legend: {
            data:['AOPA一期学员进度']
          },
          toolbox: {
            show : true,
            feature : {
              mark : {show: true},
              dataView : {show: true, readOnly: false},
              magicType: {show: true, type: ['line', 'bar']},
              restore : {show: true},
              saveAsImage : {show: true}
            }
          },
          calculable : true,
          xAxis : [
            {
              type : 'value',
              splitArea : {show : true},
              boundaryGap : [0, 0.01],
              max: 28
            }
          ],
          yAxis : [
            {
              type : 'category',
              data : ['张三','李四','王明','学员3','学员1','学员2']
            }
          ],
          series : [
            {
              clickable : true,
              name:'AOPA一期学员进度',
              label: seriesLabel,
              type:'bar',
              data:[2, 5, 28, 5, 15, 10],
              itemStyle:{
                normal:{
                  color:'#409EFF',
                },
                label: {
                  show: true
                }
              },
            }
          ]
        };
        this.myChart.setOption(option);
      },
      drawAbsent() {
        this.myChart = echarts.init(document.getElementById('absent'));
        var option = {
          title: {
            text: ' '
          },
          tooltip: {
            trigger: 'axis'
          },
          legend: {
            data:['旷课','请假']
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
          },
          toolbox: {
            show : true,
            feature : {
              mark : {show: true},
              dataView : {show: true, readOnly: false},
              magicType: {show: true, type: ['line', 'bar']},
              restore : {show: true},
              saveAsImage : {show: true}
            }
          },
          xAxis: {
            type: 'category',
            boundaryGap: false,
            data: ['2017.11.17','2017.11.18','2017.11.19','2017.11.20','2017.11.21','2017.11.22','2017.11.23']
          },
          yAxis: {
            type: 'value'
          },
          series: [
            {
              name:'旷课',
              type:'line',
              data:[5, 3, 2, 6, 8, 5, 1],
              itemStyle:{
                normal:{
                  color:'#ff083e',
                },
                label: {
                  show: true
                }
              },
            },
            {
              name:'请假',
              type:'line',
              data:[5, 20, 30, 15, 14, 11, 30],
              itemStyle:{
                normal:{
                  color:'#409EFF',
                },
                label: {
                  show: true
                }
              },
            }
          ]
        };
        this.myChart.setOption(option);
      },

      chartItemClicked(param) {
        if (typeof param.seriesIndex == 'undefined') {
          return;
        }
        if (param.type == 'click') {
          alert(param.data+1);
        }
      },
      handleCheckAllChange(val) {
        this.checkedCities = val ? cityOptions : [];
        this.isIndeterminate = false;
      },
      handleCheckedCitiesChange(value) {
        let checkedCount = value.length;
        this.checkAll = checkedCount === this.cities.length;
        this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length;
      },
      openDetails(index, row) {

        if(index === 0) {
          this.$router.push({path:'/classInfo/student'});
        } else if(index === 1) {
          this.$router.push({path:'/classInfo/coach'});
        } else {
          this.$router.push({path:'/classInfo/course'});
        }
      }
    }
  }
</script>
<style lang="less">
  .line1{
    display: flex;
    justify-content: center;
  }
  .chart-box-title{
    margin-bottom: 30px;
  }
  .chart-box{
    width:100%;
    height: 350px;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #e3e3e3;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;
  }
  .chart{
    width:100%;
    height: 330px;
  }
</style>
