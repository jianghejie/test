<template>
    <div>
      <div>
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            共3名教练 <el-button type="primary" size="small" icon="el-icon-plus"  @click="dialogFormVisible = true">添加教练</el-button>
          </div>
          <el-table
            :data="tableData"
            style="width: 100%">
            <el-table-column
              prop="name"
              label="姓名"
              width="180">
            </el-table-column>
            <el-table-column
              prop="phone"
              label="电话">
            </el-table-column>

            <el-table-column
              fixed="right"
              label="操作">
              <template slot-scope="scope">
                <el-button type="text" size="small"  @click="deleteItem">删除</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </div>

      <el-dialog title="添加教练" :visible.sync="dialogFormVisible">
        <el-form :model="form">
          <el-form-item label="教练" :label-width="formLabelWidth">
            <template>
              <el-select v-model="value" placeholder="请选择">
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </template>
          </el-form-item>

        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </template>

  <script>
    const cityOptions = ['培训课程', '资料分类', '学员管理', '购买视频记录', '合作企业管理', '推广人', '招生课程', '资料管理', '学习记录','培训记录','招聘信息管理','培训题库'];
    export default {
      data() {
        return {
          tableData: [{
            name: '郝莹',
            phone: '18210773363',
            class: 'AOPA一期',
            student: '30人'
          }, {
            name: '陈朋',
            phone: '18210773363',
            class: 'AOPA一期',
            student: '30人'
          }, {
            name: '孙佳旺',
            phone: '18210773363',
            class: 'AOPA一期',
            student: '30人'
           }],
          dialogTableVisible: false,
          dialogFormVisible: false,
          form: {
            name: '',
            region: '',
            date1: '',
            date2: '',
            delivery: false,
            type: [],
            resource: '',
            desc: ''
          },
          formLabelWidth: '120px',
          checkAll: false,
          checkedCities: ['培训课程', '资料分类'],
          cities: cityOptions,
          isIndeterminate: true
        }
      },
      methods: {
        handleCheckAllChange(val) {
          this.checkedCities = val ? cityOptions : [];
          this.isIndeterminate = false;
        },
        handleCheckedCitiesChange(value) {
          let checkedCount = value.length;
          this.checkAll = checkedCount === this.cities.length;
          this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length;
        },
        deleteItem() {
          this.$confirm('确定删除此教练吗?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            });
          }).catch(() => {

          });
        }
      }
    }
  </script>
