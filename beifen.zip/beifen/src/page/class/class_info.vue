<template>
    <div class="fillcontain">
        <div class="head-top">
          <el-breadcrumb separator="/">
            <el-breadcrumb-item :to="{ path: '/index' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item><router-link to="/classlist">班级列表</router-link></el-breadcrumb-item>
            <el-breadcrumb-item>AOPA一期</el-breadcrumb-item>
          </el-breadcrumb>
          <el-tabs v-model="activeName" @tab-click="onTabChange">
            <el-tab-pane label="概要" name="index"></el-tab-pane>
            <el-tab-pane label="基本设置" name="setting"></el-tab-pane>
            <el-tab-pane label="课程" name="course"></el-tab-pane>
            <el-tab-pane label="学员" name="student"></el-tab-pane>
            <el-tab-pane label="教练" name="coach"></el-tab-pane>
          </el-tabs>
        </div>
        <div class="main_content">
          <router-view></router-view>
        </div>
    </div>
  </template>

  <script>
    export default {
      mounted(){

      },
      //根据路由设置正确的tab选项卡
      computed:{
        activeName: function () {
          var index = this.$store.state.adminleftnavnum.lastIndexOf("/");
          var tabItem = this.$store.state.adminleftnavnum.substring(index);
          return tabItem;
        }
      },
      data() {
        return {
          tableData: [{
            type: '理论课程',
            name: '2017.7福建培训',
            location: '福建',
            coach: '陈朋',
            tuition: '10000',
            enrolled_num: '100',
            register_num: '50',
            start_time: '2010.10.23',
            end_time: '2010.10.23',
            state: '已经开始招生'
          }, {
            type: '理论课程',
            name: '2017.7福建培训',
            location: '福建',
            coach: '陈朋',
            tuition: '10000',
            enrolled_num: '100',
            register_num: '50',
            start_time: '2010.10.23',
            end_time: '2010.10.23',
            state: '结束'
          }, {
            type: '理论课程',
            name: '2017.7福建培训',
            location: '福建',
            coach: '陈朋',
            tuition: '10000',
            enrolled_num: '100',
            register_num: '50',
            start_time: '2010.10.23',
            end_time: '2010.10.23',
            state: '已经开始招生'
           }],
          dialogTableVisible: false,
          dialogFormVisible: false,
          activeName:"index",
          form: {
            name: '',
            region: '',
            date1: '',
            date2: '',
            delivery: false,
            type: [],
            resource: '',
            desc: ''
          },

          formLabelWidth: '120px',
          isIndeterminate: true
        }
      },
      //销毁内层页面
      deactivated () {
        this.$destroy()
      },
      methods: {
        //处理选项卡的切换
        onTabChange(tab, event){
          if(tab.name == "index")
            this.$router.push({path:'/classInfo/index'});
          else if(tab.name == "setting")
            this.$router.push({path:'/classInfo/setting'});
          else if(tab.name == "course")
            this.$router.push({path:'/classInfo/course'});
          else if(tab.name == "student")
            this.$router.push({path:'/classInfo/student'});
          else if(tab.name == "coach")
            this.$router.push({path:'/classInfo/coach'});
        },
      }
    }
  </script>

