<template>
    <div class="fillcontain">
      <div class="main_content">
        <el-form :model="form" label-width="180px">
          <el-form-item label="班级分类">
            <el-input v-model="form.name" value="农业无人机飞防专业" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="班级名称">
            <el-input v-model="form.name" value="34期北京培训" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="地点">
            <el-input v-model="form.description" value="北京" auto-complete="off"></el-input>
          </el-form-item>

          <el-form-item label="开班时间">
            <el-col :span="11">
              <el-date-picker type="date" placeholder="开班" v-model="form.date1" style="width: 100%;"></el-date-picker>
            </el-col>
            <el-col class="line" :span="2" style="text-align:center">-</el-col>
            <el-col :span="11">
              <el-date-picker type="date" placeholder="结束" v-model="form.date2" style="width: 100%;"></el-date-picker>
            </el-col>
          </el-form-item>

          <el-form-item label="培训费用">
            <el-input v-model="form.description" value="200" auto-complete="off"></el-input>
          </el-form-item>

          <el-form-item label="培训介绍">
            <el-input
              type="textarea"
              :rows="2"
              placeholder="请输入内容"
              v-model="textarea">
            </el-input>
          </el-form-item>
          <el-form-item label="招收人数">
            <el-input v-model="form.description" value="200" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="onSubmit">确 定</el-button>
            <el-button>取消</el-button>
          </el-form-item>
        </el-form>

      </div>
    </div>
  </template>

  <script>
    export default {
      data() {
        return {
          tableData: [{
            type: '理论课程',
            name: '2017.7福建培训',
            location: '福建',
            coach: '陈朋',
            tuition: '10000',
            enrolled_num: '100',
            register_num: '50',
            start_time: '2010.10.23',
            end_time: '2010.10.23',
            state: '已经开始招生'
          }, {
            type: '理论课程',
            name: '2017.7福建培训',
            location: '福建',
            coach: '陈朋',
            tuition: '10000',
            enrolled_num: '100',
            register_num: '50',
            start_time: '2010.10.23',
            end_time: '2010.10.23',
            state: '结束'
          }, {
            type: '理论课程',
            name: '2017.7福建培训',
            location: '福建',
            coach: '陈朋',
            tuition: '10000',
            enrolled_num: '100',
            register_num: '50',
            start_time: '2010.10.23',
            end_time: '2010.10.23',
            state: '已经开始招生'
          }],
          dialogTableVisible: false,
          dialogFormVisible: false,
          form: {
            name: '',
            region: '',
            date1: '',
            date2: '',
            delivery: false,
            type: [],
            resource: '',
            desc: ''
          },
          formLabelWidth: '120px',
          checkAll: false,

          isIndeterminate: true
        }
      },
      deactivated () {
        this.$destroy()
      },
    }
  </script>
