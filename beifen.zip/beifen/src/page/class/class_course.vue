<template>
  <div>
    <div>
      <el-card class="box-card">
        <div slot="header" class="clearfix">
          共30门课程 <el-button type="primary" size="mini" icon="el-icon-plus"  @click="courseSelectVisible = true">导入课程</el-button>
        </div>
        <el-table
          :data="tableData"
          v-loading="loading"
          ref="multipleTable"
          @selection-change="handleSelectionChange"
          style="width: 100%">
          <el-table-column
            type="selection"
            width="55">
          </el-table-column>
          <el-table-column
            prop="type"
            label="课程分类"
            :filters="[{ text: '农业无人机飞防专业', value: '1' }, { text: '理论课程', value: '2' }]"
            :filter-method="filterTag"
            filter-placement="bottom-end"
            width="180">
          </el-table-column>
          <el-table-column
            prop="name"
            label="课程名称">
          </el-table-column>
          <el-table-column
            prop="teach_way"
            label="授课形式">
          </el-table-column>
          <el-table-column
            prop="cover"
            label="封面">
          </el-table-column>

          <el-table-column
            prop="create_time"
            label="创建时间">
          </el-table-column>
          <el-table-column
            prop="state"
            label="状态">
          </el-table-column>
          <el-table-column
            fixed="right"
            label="操作">
            <template slot-scope="scope">

              <el-button type="text" size="small"  @click="dialogFormVisible = true"><i class="el-icon-close"></i></el-button>

            </template>
          </el-table-column>
        </el-table>
        <!-- 分页 -->
        <div class="pagination-container">
          <el-row :gutter="30">
            <el-col :span="6">
              <el-button size="mini" @click="toggleSelection(0)">全选</el-button>
              <el-button size="mini"  @click="toggleSelection(1)">反选</el-button>
              <el-button size="mini"  @click="toggleSelection(2)">清除</el-button>
              <el-button size="mini"  @click="deleteItems()">删除</el-button>
            </el-col>
            <el-col :span="3">
              <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="currentPage4"
                :page-sizes="[100, 200, 300, 400]"
                :page-size="100"
                layout="total, sizes, prev, pager, next, jumper"
                :total="400">
              </el-pagination>
            </el-col>
          </el-row>
        </div>
      </el-card>

    </div>
    <el-dialog
      width="50%"
      title="选择课程"
      :visible.sync="courseSelectVisible"
      append-to-body>
      分类
      <el-select v-model="value" size="small"  placeholder="请选择" style="width:150px;margin-bottom: 15px;margin-left: 15px;">
        <el-option
          v-for="item in options"
          :key="item.value"
          :label="item.label"
          :value="item.value">
        </el-option>
      </el-select>

      <el-table
        :data="tableCourseData"
        v-loading="loading"
        ref="courseSelectTable"
        @selection-change="handleCourseSelectionChange"
        style="width: 100%">
        <el-table-column
          type="selection"
          width="55">
        </el-table-column>
        <el-table-column
          prop="type"
          label="课程分类"
          width="180">
        </el-table-column>
        <el-table-column
          prop="name"
          label="课程名称">
        </el-table-column>

        <el-table-column
          prop="cover"
          label="封面">
        </el-table-column>

      </el-table>
      <!-- 分页 -->
      <div class="pagination-container">
        <el-row :gutter="30">
          <el-col :span="21">
            <el-button size="mini" @click="toggleCourseSelection(0)">全选</el-button>
            <el-button size="mini"  @click="toggleCourseSelection(1)">反选</el-button>
            <el-button size="mini"  @click="toggleCourseSelection(2)">清除</el-button>
          </el-col>
          <el-col :span="3">
            <el-button size="mini" type="primary" @click="importCourse()">导入</el-button>
          </el-col>
        </el-row>
      </div>
    </el-dialog>

  </div>
</template>
<style>
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }

</style>
<script>
  export default {
    data() {
      return {
        tableCourseData:[
          {
            type: '农林飞防',
            name: '走进植保无人机 ',
            teach_way: '视频',
            cover: '/',
            test: '100',
            vedio: '30',
            create_time: '2017.11.29',
            state: '在线'
          },{
            type: '农林飞防',
            name: '走进植保无人机 ',
            teach_way: '视频',
            cover: '/',
            test: '100',
            vedio: '30',
            create_time: '2017.11.29',
            state: '在线'
          },{
            type: '农林飞防',
            name: '走进植保无人机 ',
            teach_way: '视频',
            cover: '/',
            test: '100',
            vedio: '30',
            create_time: '2017.11.29',
            state: '在线'
          }
        ],
        tableData: [{
          type: '农林飞防',
          name: '走进植保无人机 ',
          teach_way: '视频',
          cover: '/',
          test: '100',
          vedio: '30',
          create_time: '2017.11.29',
          state: '在线'
        },{
          type: '农林飞防',
          name: '走进植保无人机 ',
          teach_way: '视频',
          cover: '/',
          test: '100',
          vedio: '30',
          create_time: '2017.11.29',
          state: '在线'
        },{
          type: '农林飞防',
          name: '走进植保无人机 ',
          teach_way: '视频',
          cover: '/',
          test: '100',
          vedio: '30',
          create_time: '2017.11.29',
          state: '在线'
        }],
        dialogTableVisible: false,
        dialogFormVisible: false,
        innerVisible: false,
        courseSelectVisible: false,
        form: {
          name: '',
          region: '',
          date1: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          desc: ''
        },
        formLabelWidth: '120px',
        checkAll: false,
        checkedCities: ['培训课程', '资料分类'],
        currentPage4: 4,
        isIndeterminate: true,
        multipleSelection: [],
        multipleCourseSelection: []
      }
    },
    methods: {
      handleCheckAllChange(val) {
        this.checkedCities = val ? cityOptions : [];
        this.isIndeterminate = false;
      },
      handleCheckedCitiesChange(value) {
        let checkedCount = value.length;
        this.checkAll = checkedCount === this.cities.length;
        this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length;
      },
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`);
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`);
      },
      toggleSelection(type) {
        if(type === 0) {
          this.tableData.forEach((row, index) => {
            this.$refs.multipleTable.toggleRowSelection(row,true);
          });
        } else if (type === 1) {
          this.tableData.forEach((row, index) => {
            this.$refs.multipleTable.toggleRowSelection(row);
          });
        } else {
          this.$refs.multipleTable.clearSelection();
        }
      },
      toggleCourseSelection(type){
        if(type === 0) {
          this.tableCourseData.forEach((row, index) => {
            this.$refs.courseSelectTable.toggleRowSelection(row,true);
          });
        } else if (type === 1) {
          this.tableCourseData.forEach((row, index) => {
            this.$refs.courseSelectTable.toggleRowSelection(row);
          });
        } else {
          this.$refs.courseSelectTable.clearSelection();
        }
      },
      deleteItems() {

      },
      importCourse () {

      },
      handleSelectionChange(val) {
        this.multipleSelection = val;
      },
      handleCourseSelectionChange(val) {
        this.multipleCourseSelection = val;
      },

    },
    created() {
      //this.loading = true;
    },
    mounted() {
      //this.loading = false;
    }
  }
</script>
