<template>
    <div class="fillcontain">
      <div class="head-top">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item :to="{ path: '/index' }">首页</el-breadcrumb-item>
          <el-breadcrumb-item><router-link to="/classlist">班级列表</router-link></el-breadcrumb-item>
          <el-breadcrumb-item>AOPA一期</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="main_content">
        <div class="bar">
          <div id="bar" class="" style="width: 90%;height:450px;"></div>

        </div>
      </div>
    </div>
  </template>

  <script>
    import echarts from 'echarts/lib/echarts';
    // 引入柱状图
    import 'echarts/lib/chart/bar';
    import 'echarts/lib/chart/line';
    import 'echarts/lib/component/title';
    import 'echarts/lib/component/legend';
    import 'echarts/lib/component/toolbox';
    import 'echarts/lib/component/markPoint';
    import 'echarts/lib/component/tooltip';

    export default {
      mounted(){
        this.myChart = echarts.init(document.getElementById('bar'));
        this.initData();
      },
      data() {
        return {
          tableData: [{
            type: '理论课程',
            name: '2017.7福建培训',
            location: '福建',
            coach: '陈朋',
            tuition: '10000',
            enrolled_num: '100',
            register_num: '50',
            start_time: '2010.10.23',
            end_time: '2010.10.23',
            state: '已经开始招生'
          }, {
            type: '理论课程',
            name: '2017.7福建培训',
            location: '福建',
            coach: '陈朋',
            tuition: '10000',
            enrolled_num: '100',
            register_num: '50',
            start_time: '2010.10.23',
            end_time: '2010.10.23',
            state: '结束'
          }, {
            type: '理论课程',
            name: '2017.7福建培训',
            location: '福建',
            coach: '陈朋',
            tuition: '10000',
            enrolled_num: '100',
            register_num: '50',
            start_time: '2010.10.23',
            end_time: '2010.10.23',
            state: '已经开始招生'
           }],
          dialogTableVisible: false,
          dialogFormVisible: false,
          form: {
            name: '',
            region: '',
            date1: '',
            date2: '',
            delivery: false,
            type: [],
            resource: '',
            desc: ''
          },
          formLabelWidth: '120px',
          checkAll: false,
          checkedCities: ['培训课程', '资料分类'],
          cities: cityOptions,
          isIndeterminate: true
        }
      },
      methods: {
        initData(){
          var seriesLabel = {
            normal: {
              show: true,
              textBorderColor: '#333',
              textBorderWidth: 2
            }
          };
          var option = {
            title : {
              text: ''
            },
            tooltip : {
              trigger: 'axis'
            },
            legend: {
              data:['AOPA一期学员进度']
            },
            toolbox: {
              show : true,
              feature : {
                mark : {show: true},
                dataView : {show: true, readOnly: false},
                magicType: {show: true, type: ['line', 'bar']},
                restore : {show: true},
                saveAsImage : {show: true}
              }
            },
            calculable : true,
            xAxis : [
              {
                type : 'value',
                splitArea : {show : true},
                boundaryGap : [0, 0.01],
                max: 28
              }
            ],
            yAxis : [
              {
                type : 'category',
                data : ['张三','李四','王明','学员3','学员1','学员2']
              }
            ],
            series : [
              {
                clickable : true,
                name:'AOPA一期学员进度',
                label: seriesLabel,
                type:'bar',
                data:[2, 5, 28, 5, 15, 10],
                itemStyle:{
                  normal:{
                    color:'#409EFF',
                  },
                  label: {
                    show: true
                  }
                },
              }
            ]
          };
          this.myChart.setOption(option);
          var ecConfig = require('echarts/lib/config');
          this.myChart.on(ecConfig.EVENT.CLICK, chartItemClicked);
        },
        chartItemClicked(param) {
          if (typeof param.seriesIndex == 'undefined') {
            return;
          }
          if (param.type == 'click') {
            alert(param.data+1);
          }
        },
        handleCheckAllChange(val) {
          this.checkedCities = val ? cityOptions : [];
          this.isIndeterminate = false;
        },
        handleCheckedCitiesChange(value) {
          let checkedCount = value.length;
          this.checkAll = checkedCount === this.cities.length;
          this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length;
        },
        open() {
                this.$confirm('此操作将永久删除该角色, 是否继续?', '提示', {
                  confirmButtonText: '确定',
                  cancelButtonText: '取消',
                  type: 'warning'
                }).then(() => {
                  this.$message({
                    type: 'success',
                    message: '删除成功!'
                  });
                }).catch(() => {

                });
               }
      }
    }
  </script>
