<template>
    <div class="fillcontain">
      <div class="head-top">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item>首页</el-breadcrumb-item>
          <el-breadcrumb-item>场地管理</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="main_content">
        <el-card class="box-card" v-loading="listLoading">
          <div slot="header" class="clearfix">
            <el-button type="primary" size="small" icon="el-icon-plus"  @click="dialogFormVisible = true">添加场地</el-button>
          </div>
          <el-table
            :data="tableData"
            border
            style="width: 100%">
            <el-table-column
              prop="title"
              label="标题">
            </el-table-column>
            <el-table-column
              prop="content"
              label="内容">
            </el-table-column>
            <el-table-column
              prop="thumbnail"
              label="缩略图">
            </el-table-column>
            <el-table-column
              prop="time"
              label="创建时间">
            </el-table-column>

            <el-table-column
              fixed="right"
              label="操作">
              <template slot-scope="scope">
                <el-button type="text" size="small"  @click="dialogFormVisible = true">编辑</el-button>
                <el-button type="text" size="small"  @click="open">删除</el-button>
              </template>
            </el-table-column>
          </el-table>
          <!-- 分页 -->
          <div class="pagination-container">
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="currentPage4"
              :page-sizes="[100, 200, 300, 400]"
              :page-size="100"
              layout="total, sizes, prev, pager, next, jumper"
              :total="400">
            </el-pagination>
          </div>
        </el-card>

      </div>

      <el-dialog title="编辑" :visible.sync="dialogFormVisible">
        <el-form :model="form">
          <el-form-item label="班级分类" :label-width="formLabelWidth">
            <el-input v-model="form.name" value="农业无人机飞防专业" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="班级名称" :label-width="formLabelWidth">
            <el-input v-model="form.name" value="34期北京培训" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="地点" :label-width="formLabelWidth">
            <el-input v-model="form.description" value="北京" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="指定教练" :label-width="formLabelWidth">
            <template>
              <el-select v-model="value" placeholder="请选择">
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </template>
          </el-form-item>
          <el-form-item label="开班时间" :label-width="formLabelWidth">
            <el-col :span="11">
              <el-date-picker type="date" placeholder="开班" v-model="form.date1" style="width: 100%;"></el-date-picker>
            </el-col>
            <el-col class="line" :span="2" style="text-align:center">-</el-col>
            <el-col :span="11">
              <el-date-picker type="date" placeholder="结束" v-model="form.date2" style="width: 100%;"></el-date-picker>
            </el-col>
          </el-form-item>
          <el-form-item label="培训费用" :label-width="formLabelWidth">
            <el-input v-model="form.description" value="200" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="培训介绍" :label-width="formLabelWidth">
            <el-input
              type="textarea"
              :rows="2"
              placeholder="请输入内容"
              v-model="textarea">
            </el-input>
          </el-form-item>
          <el-form-item label="招收人数" :label-width="formLabelWidth">
            <el-input v-model="form.description" value="200" auto-complete="off"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </template>
  <script>
    import {   } from '@/api/table'
    export default {
      data() {
        return {
          tableData: [],
          dialogTableVisible: false,
          dialogFormVisible: false,
          form: {
            name: '',
            region: '',
            date1: '',
            date2: '',
            delivery: false,
            type: [],
            resource: '',
            desc: ''
          },
          formLabelWidth: '120px',
          checkAll: false,
          checkedCities: ['培训课程', '资料分类'],
          isIndeterminate: true
        }
      },
      created(){
        this.fetchData();
      },
      methods: {
        fetchData() {
          this.listLoading = true

        },
        handleCheckAllChange(val) {
          this.checkedCities = val ? cityOptions : [];
          this.isIndeterminate = false;
        },
        handleCheckedCitiesChange(value) {
          let checkedCount = value.length;
          this.checkAll = checkedCount === this.cities.length;
          this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length;
        },
        open() {
          this.$confirm('此操作将永久删除该角色, 是否继续?', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
          }).then(() => {
          this.$message({
              type: 'success',
              message: '删除成功!'
            });
          }).catch(() => {

          });
        }
      }
    }
  </script>
