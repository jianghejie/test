<template>
  <el-container>
    <el-header>
      <div style="width:200px;color:#ffffff;font-weight:600;float:left;line-height:60px;">天途教育后台管理</div>
      <div class="userinfo">
        <el-dropdown>
        <span class="el-dropdown-link">
          <img class="avatar" width="40" height="40" src="../assets/avatar.png" />
        </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item>个人信息</el-dropdown-item>
            <el-dropdown-item>退出</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
    </el-header>
    <el-container>
      <el-aside>
        <el-menu
          class="main-menu"
          default-active="index"
          @open="handleOpen"
          @close="handleClose"
          unique-opened="true"
          :default-active="navselected"
          :active="navselected"
          router>
          <el-menu-item index="/index"><i class="el-icon-tickets"></i>首页</el-menu-item>

          <el-submenu index="manager">
            <template slot="title"><i class="el-icon-menu"></i>权限管理</template>
            <el-menu-item index="/role">角色管理</el-menu-item>
            <el-menu-item index="/managerList">账户列表</el-menu-item>
            <el-menu-item index="/authority">权限</el-menu-item>
          </el-submenu>

          <el-submenu index="course">
            <template slot="title"><i class="el-icon-document"></i>课程管理</template>
            <el-menu-item index="/classcategory">专业</el-menu-item>
            <el-menu-item index="/courselist">课程列表</el-menu-item>
          </el-submenu>

          <el-submenu index="class">
            <template slot="title"><i class="el-icon-info"></i>班级管理</template>
            <el-menu-item index="/classlist">班级列表</el-menu-item>
          </el-submenu>

          <el-submenu index="student">
            <template slot="title"><i class="el-icon-edit"></i>学员管理</template>
            <el-menu-item index="/register">报名审批</el-menu-item>
            <el-menu-item index="/students">学员列表</el-menu-item>
            <el-menu-item index="/graduate">毕业学员列表</el-menu-item>
          </el-submenu>

          <el-submenu index="coach">
            <template slot="title"><i class="el-icon-star-on"></i>教练管理</template>
            <el-menu-item index="/coach">教练列表</el-menu-item>
            <el-menu-item index="/dayoff">请假管理</el-menu-item>
          </el-submenu>

          <el-submenu index="resources">
            <template slot="title"><i class="el-icon-setting"></i>教学资源</template>
            <el-menu-item index="/coursecategory">学科</el-menu-item>
            <el-menu-item index="/videoList">视频</el-menu-item>
            <el-menu-item index="/questions">题库</el-menu-item>
          </el-submenu>
          <el-menu-item index="/planes"><i class="el-icon-news"></i>无人机管理</el-menu-item>
          <el-menu-item index="/fields"><i class="el-icon-location-outline"></i>场地管理</el-menu-item>
          <el-submenu index="appointment">
            <template slot="title"><i class="el-icon-warning"></i>预约管理</template>
            <el-menu-item index="/appointment">考试预约</el-menu-item>
            <el-menu-item index="/appointmentField">教练预约</el-menu-item>
          </el-submenu>

          <el-submenu index="statistics">
            <template slot="title"><i class="el-icon-warning"></i>统计</template>
            <el-menu-item index="/staStudent">学员统计</el-menu-item>
            <el-menu-item index="/staCoach">教练统计</el-menu-item>
          </el-submenu>
          <el-menu-item index="/apps">app管理</el-menu-item>
        </el-menu>
      </el-aside>
      <el-container>
        <div class="main" v-bind:style="{minHeight: mainHeight + 'px'}">
          <keep-alive>
            <router-view></router-view>
          </keep-alive>
        </div>
        <el-footer>Powered by tiantu v1.0.0 ©2017-2020 </el-footer>
      </el-container>
    </el-container>
  </el-container>
</template>
<script>
  export default {
    data() {
      return {
        mainHeight: document.body.clientHeight,
        //navselected: this.$store.state.adminleftnavnum
      }
    },
    computed:{
      navselected: function () {
        return this.$store.state.adminleftnavnum;
      }
    },
    methods: {
      handleOpen(key, keyPath) {
        console.log(key, keyPath);
      },
      handleClose(key, keyPath) {
        console.log(key, keyPath);
      }
    },
    mounted () {
      window.onresize = () => {
        return (() => {
          this.mainHeight = document.body.clientHeight;
        })()
      }
    },

  }
</script>

<style lang="less" scoped>
  @import '../style/mixin';
  .manage_page{

  }

  .userinfo{
    height:60px;
    float:right;
  }

  .userinfo	.avatar{
    margin-top:10px;
  }


</style>

