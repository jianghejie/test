  <template>
    <div class="fillcontain">
      <div class="head-top">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item>首页</el-breadcrumb-item>
          <el-breadcrumb-item>题库</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="main_content">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <el-button type="primary" size="small" icon="el-icon-plus"  @click="openAddForm">添加试题</el-button>
            <el-button size="mini" @click="toggleSelection(0)">全选</el-button>
            <el-button size="mini" @click="toggleSelection(1)">反选</el-button>
            <el-button size="mini" @click="toggleSelection(2)">清除</el-button>
            <el-input class="right" placeholder="搜索" v-model="input5" style="width:230px;">
              <el-button slot="append" icon="el-icon-search"></el-button>
            </el-input>
          </div>
          <el-table
            :data="tableData"
            border
            ref="selectTable"
            style="width: 100%">
            <el-table-column
              type="selection"
              width="55">
            </el-table-column>
            <el-table-column
              prop="content"
              label="试题内容">
            </el-table-column>
            <el-table-column
              prop="selection"
              label="选项">
              <template slot-scope="scope">
                <SelectView :data="scope.row.selection"></SelectView>
              </template>
            </el-table-column>
            <el-table-column
              prop="rightAnswer"
              label="答案">
            </el-table-column>
            <el-table-column
              prop="typeId"
              label="题型">
            </el-table-column>
            <el-table-column
              prop="createTime"
              label="创建时间">
            </el-table-column>
            <el-table-column
              label="操作">
              <template slot-scope="scope">
                <el-button size="mini" @click="openEditForm(scope.row.id)" type="primary" plain>编辑</el-button>
                <el-button size="mini" @click="deleteItem(scope.row.id)" type="primary" plain>删除</el-button>
              </template>
            </el-table-column>
          </el-table>
          <!-- 分页 -->
          <div class="pagination-container">
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="currentPage"
              :page-sizes="[5, 20, 50, 100]"
              :page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="totalElements">
            </el-pagination>
          </div>
        </el-card>
      </div>

      <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible" :close-on-click-modal="false">
        <el-form :model="form">
          <el-form-item label="科目" :label-width="formLabelWidth">
            <el-cascader
              :options="options"
              :show-all-levels="false"
              v-model="selectedOptions">
            </el-cascader>
          </el-form-item>
          <el-form-item label="试题内容" :label-width="formLabelWidth">
            <el-input v-model="form.content"  auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="选项" :label-width="formLabelWidth">
            <SelectEditor v-model="form.selection"></SelectEditor>
          </el-form-item>
          <el-form-item label="答案" :label-width="formLabelWidth">
            <el-input v-model="form.rightAnswer" auto-complete="off"></el-input>
          </el-form-item>

          <el-form-item label="题型" :label-width="formLabelWidth">
              <el-select v-model="form.typeId" placeholder="请选择">
                <el-option
                  v-for="item in typeOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
          </el-form-item>

        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button v-if="dialogStatus=='create'" type="primary" @click="addItem">确 定</el-button>
          <el-button v-else type="primary" @click="saveItem">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </template>

  <script>
    import {getQuestionByPage, deleteQuestion, addQuestion, getQuestion, saveQuestion, getAllCourseCatgory} from '@/api/table'
    import {toast, formatTime, addSimpleData, deleteData, getOneForEdit, saveData} from '@/utils/index'
    import SelectEditor from '@/components/SelectEditor';
    import SelectView from '@/components/SelectView';
    export default {
      components: {
        SelectEditor,
        SelectView,
      },
      data() {
        return {
          //表格
          tableData: [],

          //对话框
          dialogFormVisible: false,
          textMap: {
            update: '编辑',
            create: '创建'
          },
          dialogStatus: '',

          //表单
          form: {
            content: '',
            rightAnswer: '',
            typeId: '',
            selection: '',
            catCourseId: '',
          },
          formLabelWidth: '120px',

          //选项
          options: [],
          typeOptions: [{value:0, label:"选择题"}],
          selectedOptions: [],

          //分页相关
          currentPage: 0,
          pageSize: 5,
          totalElements: 0,
        }
      },

      created() {
        this.fetchData(this.currentPage, this.pageSize);
        this.getCategory();
      },

      watch: {
        selectedOptions: function (newSelectedOptions) {
          this.form.catCourseId = newSelectedOptions[newSelectedOptions.length-1];
        },
      },

      methods: {
        //打开添加表单
        openAddForm() {
          this.dialogStatus = "create"
          this.dialogFormVisible = true;
          //清空表单数据
          for (let key in this.form) {
            this.form[key] = ""
          }
          this.selectedOptions = [];
        },

        //打开编辑表单
        openEditForm(id) {
          this.dialogStatus = "update"
          this.selectedId = id;
          var callBack = function () {
            this.selectedOptions = this.getCateRout(this.options, this.form.catCourseId);
          };
          getOneForEdit(this, id, getQuestion, callBack.bind(this));
        },

        //根据id删除
        deleteItem(id) {
          deleteData(this, deleteQuestion, id, '确定删除此问题吗?');
        },

        //添加
        addItem() {
          addSimpleData(this, addQuestion);
        },

        //编辑
        saveItem() {
          saveData(this, saveQuestion, this.selectedId);
        },

        //分页查询
        fetchData(page, size) {
          this.listLoading = true
          getQuestionByPage(page, size).then(response => {
            const result = response.data;
            if(result.code == -1){
              this.$message({
                type: '失败',
                message: result.msg
              });
            }
            var temp = result.data.content;
            this.totalElements = result.data.totalElements;
            this.tableData = [];
            if(temp.length != 0){
              temp.forEach((item, index) => {
                const tableItem = {
                  id:item.id,
                  content: item.content,
                  typeId: item.typeId,
                  rightAnswer: item.rightAnswer,
                  selection: item.selection,
                  catCourseId:item.catCourseId,
                  catCourseName:item.catCourseName,
                  createTime:formatTime(item.createTime),
                }
                this.tableData.push(tableItem)
              })
            } else {

            }

          }).catch(function (error) {
            console.log(error);
          });
          this.listLoading = false
        },

        //列出分类
        getCategory() {
          getAllCourseCatgory().then(response => {
            const result = response.data;
            if(result.code == -1){
              this.$message({
                type: '失败',
                message: result.msg
              });
            }
            const categoryList = result.data.content;
            this.options = [];
            this.options = this.refining(categoryList);
            console.log(this.options);
          }).catch(function (error) {
            console.log(error);
          });
        },

        refining(nestJson) {
          var opts = [];
          for (var i = 0; i < nestJson.length; i++) {
            var optionItem = {
              value: nestJson[i].id,
              label: nestJson[i].name,
              //为了便于查找一个分类的完整路径加上cateCode，注意这里数据库的命名有点不统一
              catCode: this.parseCatCode(nestJson[i].cateCode),
            };

            if (nestJson[i].children) {
              optionItem.children = this.refining(nestJson[i].children);
            }
            opts.push(optionItem);
          }
          return opts;
        },

        //根据catid获得完整分类路径
        getCateRout(nestJson, catId) {
          var opts;
          for (var i = 0; i < nestJson.length; i++) {
            if(catId == nestJson[i].value){
              opts = nestJson[i].catCode
              return opts;
            }
            if (nestJson[i].children) {
              var temp = this.getCateRout(nestJson[i].children, catId)
              if(temp != null)
                opts = temp
            }
          }
          return opts;
        },

        //把catecode解析成cascader能读取的形式,如[id1, id2, id3]
        parseCatCode(code){
          var fullPath = []
          for(var i = 0; i < code.length/32; i++){
            fullPath.push(code.substring(i*32, (i+1)*32))
          }
          return fullPath
        },

        //全选，不选，反选
        toggleSelection(type){
          if(type === 0) {
            this.tableData.forEach((row, index) => {
              this.$refs.selectTable.toggleRowSelection(row,true);
            });
          } else if (type === 1) {
            this.tableData.forEach((row, index) => {
              this.$refs.selectTable.toggleRowSelection(row);
            });
          } else {
            this.$refs.selectTable.clearSelection();
          }
        },
      }
    }
  </script>
