  <template>
    <div class="fillcontain">
          <el-table
            :data="tableData"
            style="width: 100%">
            <el-table-column
              prop="coach"
              label="教练">
            </el-table-column>
            <el-table-column
              prop="name"
              label="姓名">
            </el-table-column>
            <el-table-column
              prop="phone"
              label="联系电话">
            </el-table-column>
            <el-table-column
              prop="start_time"
              label="开始时间">
            </el-table-column>
            <el-table-column
              prop="training_duration"
              label="训练时间">
            </el-table-column>
            <el-table-column
              prop="end_time"
              label="结束时间">
            </el-table-column>
            <el-table-column
              prop="step"
              label="阶段">
            </el-table-column>
          </el-table>

    </div>
  </template>
  <script>
    export default {
      data() {
        return {
          tableData: [{
            coach: '陈向军',
            name: '宁东',
            phone: '13621186969',
            start_time: '2017/07/01 10:00:00',
            training_duration: '1.5',
            end_time: '2017/7/1 12:00',
            step: '带飞'

          }, {
            coach: '陈向军',
            name: '宁东',
            phone: '13621186969',
            start_time: '2017/07/01 10:00:00',
            training_duration: '1.5',
            end_time: '2017/7/1 12:00',
            step: '带飞'
          }, {
            coach: '陈向军',
            name: '宁东',
            phone: '13621186969',
            start_time: '2017/07/01 10:00:00',
            training_duration: '1.5',
            end_time: '2017/7/1 12:00',
            step: '带飞'
           }],
          dialogTableVisible: false,
          dialogFormVisible: false,
          isIndeterminate: true
        }
      },
        methods: {
          handleCheckAllChange(val) {
            this.checkedCities = val ? cityOptions : [];
            this.isIndeterminate = false;
          },
          handleCheckedCitiesChange(value) {
            let checkedCount = value.length;
            this.checkAll = checkedCount === this.cities.length;
            this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length;
          },
          onTabChange(tab, event){
            if(tab.name="first")
              this.$router.push({path:'/studentinfo1'});
            else if(tab.name="second")
              this.$router.push({path:'/studentinfo1'});
            else
              this.$router.push({path:'/studentinfo1'});
          },
          open() {
            this.$confirm('此操作将永久删除该角色, 是否继续?', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              this.$message({
                type: 'success',
                message: '删除成功!'
              });
            }).catch(() => {

            });
           }
        }
    }
  </script>
