<template>
    <div class="fillcontain">
      <div class="head-top">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item>首页</el-breadcrumb-item>
          <el-breadcrumb-item>报名审批</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="main_content">
        <el-table
          :data="tableData"
          style="width: 100%">
          <el-table-column
            prop="name"
            label="姓名"
            width="180">
          </el-table-column>
          <el-table-column
            prop="class"
            label="班级">
          </el-table-column>
          <el-table-column
            prop="time"
            label="报名时间">
          </el-table-column>
          <el-table-column
            fixed="right"
            label="操作">
            <template slot-scope="scope">
              <el-button size="mini"  @click="open" type="primary" plain>审批</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>

      <el-dialog title="角色修改" :visible.sync="dialogFormVisible">
        <el-form :model="form">
          <el-form-item label="名称" :label-width="formLabelWidth">
            <el-input v-model="form.name" value="超级管理员" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="描述" :label-width="formLabelWidth">
            <el-input v-model="form.description" value="超级管理员" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="权限" :label-width="formLabelWidth">
            <template>
              <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">全选</el-checkbox>
              <div style="margin: 15px 0;"></div>
              <el-checkbox-group v-model="form.authority" @change="handleCheckedCitiesChange">
                <el-checkbox v-for="city in cities" :label="city" :key="city">{{city}}</el-checkbox>
              </el-checkbox-group>
            </template>

          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </template>

  <script>
    const cityOptions = ['培训课程', '资料分类', '学员管理', '购买视频记录', '合作企业管理', '推广人', '招生课程', '资料管理', '学习记录','培训记录','招聘信息管理','培训题库'];
    export default {
      data() {
        return {
          tableData: [{
            name: '郝莹',
            class: 'AOPA一期',
            time: '2017.2.3'
          }, {
            name: '郝莹',
            class: 'AOPA一期',
            time: '2017.2.3'
          }, {
            name: '郝莹',
            class: 'AOPA一期',
            time: '2017.2.3'
           }],
          dialogTableVisible: false,
          dialogFormVisible: false,
          form: {
            name: '',
            region: '',
            date1: '',
            date2: '',
            delivery: false,
            type: [],
            resource: '',
            desc: ''
          },
          formLabelWidth: '120px',
          checkAll: false,
          checkedCities: ['培训课程', '资料分类'],
          cities: cityOptions,
          isIndeterminate: true
        }
      },
        methods: {
          handleCheckAllChange(val) {
            this.checkedCities = val ? cityOptions : [];
            this.isIndeterminate = false;
          },
          handleCheckedCitiesChange(value) {
            let checkedCount = value.length;
            this.checkAll = checkedCount === this.cities.length;
            this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length;
          },
          open() {
                  this.$confirm('是否通过该报名申请', '提示', {
                    confirmButtonText: '通过',
                    cancelButtonText: '拒绝',
                    type: 'warning'
                  }).then(() => {
                    this.$message({
                      type: 'success',
                      message: '审核成功!'
                    });
                  }).catch(() => {

                  });
                 }
        }
    }
  </script>
