<template>
  <div class="fillcontain">
    <div class="head-top">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item>首页</el-breadcrumb-item>
        <el-breadcrumb-item>未报班学生</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="main_content">
      <el-card class="box-card">
        <div slot="header" class="clearfix">
          <el-button size="mini" @click="toggleSelection(0)">全选</el-button>
          <el-button size="mini" @click="toggleSelection(1)">反选</el-button>
          <el-button size="mini" @click="toggleSelection(2)">清除</el-button>
          <el-input class="right" placeholder="搜索" v-model="input5" style="width:230px;">
            <el-button slot="append" icon="el-icon-search"></el-button>
          </el-input>
        </div>
        <el-table
          :data="tableData"
          ref="selectTable"
          style="width: 100%">
          <el-table-column
            type="selection"
            width="55">
          </el-table-column>
          <el-table-column
            prop="userName"
            width="90"
            label="姓名">
          </el-table-column>
          <el-table-column
            prop="sex"
            width="50"
            label="性别">
          </el-table-column>
          <el-table-column
            prop="mobilePhone"
            label="电话">
          </el-table-column>
          <el-table-column
            prop="createTime"
            label="注册时间">
          </el-table-column>
          <el-table-column
            fixed="right"
            width="240"
            label="操作">
            <template slot-scope="scope">
              <el-button size="mini" @click="openDetails(scope.row.id)" type="primary" plain>报名</el-button>
              <el-button size="mini" @click="deleteItem(scope.row.id)" type="primary" plain>删除</el-button>
            </template>
          </el-table-column>
        </el-table>
        <!-- 分页 -->
        <div class="pagination-container">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="[5, 20, 50, 100]"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="totalElements">
          </el-pagination>
        </div>
      </el-card>
    </div>
    <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible" :close-on-click-modal="false">
      <el-form :model="form" :rules="rules">
        <el-form-item label="姓名" :label-width="formLabelWidth">
          <el-input v-model="form.userName" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="性别" :label-width="formLabelWidth">
          <el-radio-group v-model="form.sex">
            <el-radio label="0">男</el-radio>
            <el-radio label="1">女</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="电话" :label-width="formLabelWidth">
          <el-input v-model="form.mobilePhone" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="班级" :label-width="formLabelWidth">
          <el-select v-model="value" placeholder="请选择">
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
  import {getUnEnrollStudentList} from '@/api/table'
  import {toast, formatTime, addSimpleData, deleteData, getOneForEdit, saveData} from '@/utils/index'

  export default {
    data() {
      return {
        //表格
        tableData: [],
        selectedId:'',
        formLabelWidth: '120px',

        //对话框
        dialogFormVisible: false,
        textMap: {
          update: '编辑',
          create: '创建'
        },
        dialogStatus: '',

        //表单
        form: {
          userName: '',
          sex: '',
          mobilePhone: '',
        },
        rules: {
          name: [
            { required: true, message: '请输入姓名', trigger: 'change' },
          ],
          sex: [
            { required: true, message: '请选择性别', trigger: 'change' }
          ],
          mobilePhone: [
            { required: true, message: '请输入手机号', trigger: 'change' }
          ],
        },
        listLoading: false,

        //分页
        currentPage: 0,
        pageSize: 5,
        totalElements: 0,
      }
    },

    created() {
      this.fetchData(this.currentPage, this.pageSize);
    },

    methods: {
      //打开添加表单
      openAddForm() {
        this.dialogStatus = "create"
        this.dialogFormVisible = true;
        //清空表单数据
        for (let key in this.form) {
          this.form[key] = ""
        }
        this.selectedOptions = [];
      },

      //打开编辑表单
      openEditForm(id) {
        this.dialogStatus = "update"
        this.selectedId = id;
        getOneForEdit(this, id, getStudent, null);
      },

      //根据id删除
      deleteItem(id) {
        deleteData(this, deleteStudent, id, '确定删除此学员吗?');
      },

      //添加
      addItem() {
        addSimpleData(this, addStudent);
      },

      //编辑
      saveItem() {
        saveData(this, saveStudent, this.selectedId);
      },

      openDetail (id){
        this.$router.push({path:'/student/studentinfo'});
      },

      //分页查询
      fetchData(page, size) {
        this.listLoading = true
        getUnEnrollStudentList(page, size).then(response => {
          const result = response.data;
          if(result.code == -1){
            this.$message({
              type: '失败',
              message: result.msg
            });
          }

          var temp = result.data.content;
          this.totalElements = result.data.totalElements;
          this.tableData = [];
          if(temp.length != 0){
            temp.forEach((item, index) => {
              const tableItem = {
                id:item.id,
                userName: item.userName,
                mobilePhone: item.mobilePhone,
                sex: item.sex == 1 ? '男' : '女',
                className: item.className,
                createTime: item.createTime,
              }
              this.tableData.push(tableItem)
            })
          } else {

          }
        }).catch(function (error) {
          console.log(error);
        });
        this.listLoading = false
      },

      //全选，不选，反选
      toggleSelection(type) {
        if(type === 0) {
          this.tableData.forEach((row, index) => {
            this.$refs.selectTable.toggleRowSelection(row,true);
          });
        } else if (type === 1) {
          this.tableData.forEach((row, index) => {
            this.$refs.selectTable.toggleRowSelection(row);
          });
        } else {
          this.$refs.selectTable.clearSelection();
        }
      },
    }
  }
</script>
