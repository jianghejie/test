  <template>
    <div class="fillcontain">
      <div class="head-top">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item>首页</el-breadcrumb-item>
          <el-breadcrumb-item><router-link to="/students">学员列表</router-link></el-breadcrumb-item>
          <el-breadcrumb-item>小王</el-breadcrumb-item>
        </el-breadcrumb>
        <el-tabs  @tab-click="onTabChange">
          <el-tab-pane label="概要" name="index"></el-tab-pane>
          <el-tab-pane label="理论成绩" name="theorytest"></el-tab-pane>
          <el-tab-pane label="实操考试" name="practical"></el-tab-pane>
          <el-tab-pane label="训练情况" name="training"></el-tab-pane>
        </el-tabs>
      </div>
      <div class="main_content">


        <router-view></router-view>

      </div>
    </div>
  </template>
  <script>
    export default {

      data() {
        return {
          tableData: [{
            name: '郝莹',
            sex: '女',
            phone: '18210773363',
            class: 'AOPA一期',
            reg_time: '2017.11.1',
            last_login: '2017.11.05'
          }, {
            name: '郝莹',
            sex: '女',
            phone: '18210773363',
            class: 'AOPA一期',
            reg_time: '2017.11.1',
            last_login: '2017.11.05'
          }, {
            name: '郝莹',
            sex: '女',
            phone: '18210773363',
            class: 'AOPA一期',
            reg_time: '2017.11.1',
            last_login: '2017.11.05'
           }],
          checkAll: false,

        }
      },

      deactivated () {
        this.$destroy()
      },
        methods: {
          handleCheckAllChange(val) {
            this.checkedCities = val ? cityOptions : [];
            this.isIndeterminate = false;
          },
          handleCheckedCitiesChange(value) {
            let checkedCount = value.length;
            this.checkAll = checkedCount === this.cities.length;
            this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length;
          },
          onTabChange(tab, event){
            if(tab.name == "index")
              this.$router.push({path:'/student/index'});
            else if(tab.name == "theorytest")
              this.$router.push({path:'/student/theorytest'});
            else if(tab.name == "practical")
              this.$router.push({path:'/student/practical'});
            else
              this.$router.push({path:'/student/training'});
          },
          open() {
            this.$confirm('此操作将永久删除该角色, 是否继续?', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              this.$message({
                type: 'success',
                message: '删除成功!'
              });
            }).catch(() => {

            });
           }
        }
    }
  </script>
