<template>
  <div>
    <el-collapse v-model="activeNames" @change="handleChange">
      <el-collapse-item title="基本信息" name="1">
        <el-form label-position="left"  class="demo-table-expand">
          <el-form-item label="姓名">
            <span>小王</span>
          </el-form-item>
          <el-form-item label="性别">
            <span>男</span>
          </el-form-item>
          <el-form-item label="邮箱">
            <span>jianghejie@gmail.com </span>
          </el-form-item>
          <el-form-item label="手机">
            <span>11225555</span>
          </el-form-item>
          <el-form-item label="注册时间">
            <span> 2017.12.26 </span>
          </el-form-item>
          <el-form-item label="最近登录时间">
            <span> 2017.12.26 </span>
          </el-form-item>
          <el-form-item label="qq">
            <span> 125566 </span>
          </el-form-item>
        </el-form>
      </el-collapse-item>

    </el-collapse>

    <el-collapse v-model="activeNames" @change="handleChange">
      <el-collapse-item title="考勤" name="2">
        <el-table
          :data="attendanceTableData"
          style="width: 100%">
          <el-table-column
            prop="date"
            label="日期"
            width="180">
          </el-table-column>
          <el-table-column
            prop="dayoff"
            label="是否旷课"
            width="180">
          </el-table-column>

        </el-table>
      </el-collapse-item>

    </el-collapse>
  </div>

</template>
<script>
  import echarts from 'echarts/lib/echarts';
  // 引入柱状图
  import 'echarts/lib/chart/bar';
  import 'echarts/lib/chart/line';
  import 'echarts/lib/component/title';
  import 'echarts/lib/component/legend';
  import 'echarts/lib/component/toolbox';
  import 'echarts/lib/component/markPoint';
  import 'echarts/lib/component/tooltip';

  export default {
    mounted(){
      this.myChart = echarts.init(document.getElementById('chart'));
      this.initData();
    },
    data() {
      return {
        tableData: [{
          type: '学员',
          num: '100'

        }, {
          type: '教练',
          num: '2'
        },  {
          type: '课程',
          num: '50'
        }],
        attendanceTableData: [{
          date: '2017.11.20',
          dayoff: '是'

        }, {
          date: '2017.11.20',
          dayoff: '否'
        },  {
          date: '2017.11.20',
          dayoff: '否'
        },  {
          date: '2017.11.20',
          dayoff: '否'
        },  {
          date: '2017.11.20',
          dayoff: '否'
        },  {
          date: '2017.11.20',
          dayoff: '否'
        },  {
          date: '2017.11.20',
          dayoff: '否'
        }],
        activeNames: ['1','2'],
        dialogTableVisible: false,
        dialogFormVisible: false,
        form: {
          name: '',
          region: '',
          date1: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          desc: ''
        },
        formLabelWidth: '120px',
        checkAll: false,
        checkedCities: ['培训课程', '资料分类'],
        isIndeterminate: true
      }
    },
    deactivated () {
      this.$destroy()
    },
    methods: {
      initData(){
        var seriesLabel = {
          normal: {
            show: true,
            textBorderColor: '#333',
            textBorderWidth: 2
          }
        };
        var option = {
          title : {
            text: ''
          },
          tooltip : {
            trigger: 'axis'
          },
          legend: {
            data:['AOPA一期学员进度']
          },
          toolbox: {
            show : true,
            feature : {
              mark : {show: true},
              dataView : {show: true, readOnly: false},
              magicType: {show: true, type: ['line', 'bar']},
              restore : {show: true},
              saveAsImage : {show: true}
            }
          },
          calculable : true,
          xAxis : [
            {
              type : 'value',
              splitArea : {show : true},
              boundaryGap : [0, 0.01],
              max: 28
            }
          ],
          yAxis : [
            {
              type : 'category',
              data : ['张三','李四','王明','学员3','学员1','学员2']
            }
          ],
          series : [
            {
              clickable : true,
              name:'AOPA一期学员进度',
              label: seriesLabel,
              type:'bar',
              data:[2, 5, 28, 5, 15, 10],
              itemStyle:{
                normal:{
                  color:'#409EFF',
                },
                label: {
                  show: true
                }
              },
            }
          ]
        };
        this.myChart.setOption(option);
        var ecConfig = require('echarts/lib/config');
        this.myChart.on(ecConfig.EVENT.CLICK, chartItemClicked);
      },

      chartItemClicked(param) {
        if (typeof param.seriesIndex == 'undefined') {
          return;
        }
        if (param.type == 'click') {
          alert(param.data+1);
        }
      },
      handleCheckAllChange(val) {
        this.checkedCities = val ? cityOptions : [];
        this.isIndeterminate = false;
      },
      handleCheckedCitiesChange(value) {
        let checkedCount = value.length;
        this.checkAll = checkedCount === this.cities.length;
        this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length;
      },
      openDetails(id) {
        this.$router.push({path:'/classInfo/classCourseList'});
      }
    }
  }
</script>
<style lang="less">
  .line1{
    display: flex;
    justify-content: center;
  }
  .chart-box-title{
    margin-bottom: 30px;
  }
  .chart-box{
    width:100%;
    height: 350px;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #e3e3e3;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;
  }
  .chart{
    width:100%;
    height: 330px;
  }
</style>
