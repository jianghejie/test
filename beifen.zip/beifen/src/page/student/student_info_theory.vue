  <template>
    <div class="fillcontain">
          <el-table
            :data="tableData"
            style="width: 100%">
            <el-table-column
              prop="class"
              label="班级">
            </el-table-column>
            <el-table-column
              prop="name"
              label="姓名">
            </el-table-column>
            <el-table-column
              prop="course"
              label="课程">
            </el-table-column>
            <el-table-column
              prop="score"
              label="得分">
            </el-table-column>
            <el-table-column
              prop="time"
              label="时间">
            </el-table-column>
          </el-table>
    </div>
  </template>
  <script>
    export default {
      data() {
        return {
          tableData: [{
            class: '北京36期培训',
            name: '徐昱豪',
            course: '飞行原理1',
            score: '85',
            time: '2017.11.1'
          }, {
            class: '北京36期培训',
            name: '徐昱豪',
            course: '飞行原理2',
            score: '90',
            time: '2017.11.1'
          }, {
            class: '北京36期培训',
            name: '徐昱豪',
            course: '口试试题讲解',
            score: '85',
            time: '2017.11.1'
           }],
          dialogTableVisible: false,
          dialogFormVisible: false,
          isIndeterminate: true
        }
      },
        methods: {
          handleCheckAllChange(val) {
            this.checkedCities = val ? cityOptions : [];
            this.isIndeterminate = false;
          },
          handleCheckedCitiesChange(value) {
            let checkedCount = value.length;
            this.checkAll = checkedCount === this.cities.length;
            this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length;
          },
          onTabChange(tab, event){
            if(tab.name="first")
              this.$router.push({path:'/studentinfo1'});
            else if(tab.name="second")
              this.$router.push({path:'/studentinfo1'});
            else
              this.$router.push({path:'/studentinfo1'});
          },
          open() {
            this.$confirm('此操作将永久删除该角色, 是否继续?', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              this.$message({
                type: 'success',
                message: '删除成功!'
              });
            }).catch(() => {

            });
           }
        }
    }
  </script>
