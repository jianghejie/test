<template>
    <div class="fillcontain">
      <div class="head-top">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item>首页</el-breadcrumb-item>
          <el-breadcrumb-item>学员列表</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="main_content">
        <el-table
          :data="tableData"
          style="width: 100%">
          <el-table-column
            prop="name"
            width="90"
            label="姓名">
          </el-table-column>
          <el-table-column
            prop="sex"
            width="50"
            label="性别">
          </el-table-column>
          <el-table-column
            prop="phone"
            label="电话">
          </el-table-column>
          <el-table-column
            prop="class"
            label="班级">
          </el-table-column>
          <el-table-column
            prop="progress"
            label="学习进度">
              <template slot-scope="scope">
                <el-progress :percentage="70"></el-progress>
              </template>
          </el-table-column>

          <el-table-column
            prop="reg_time"
            label="注册时间">
          </el-table-column>
          <el-table-column
            prop="last_login"
            label="上次登录">
          </el-table-column>
          <el-table-column
            fixed="right"
            width="240"
            label="操作">
            <template slot-scope="scope">
              <el-button size="mini" @click="dialogFormVisible = true" type="primary" plain>编辑</el-button>
              <el-button size="mini"  @click="deleteItem" type="primary" plain>删除</el-button>
              <el-button size="mini"  @click="openDetail" type="primary" plain>详情</el-button>
            </template>
          </el-table-column>
        </el-table>
        <!-- 分页 -->
        <div class="pagination-container">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage4"
            :page-sizes="[100, 200, 300, 400]"
            :page-size="100"
            layout="total, sizes, prev, pager, next, jumper"
            :total="400">
          </el-pagination>
        </div>
      </div>

      <el-dialog title="学员信息" :visible.sync="dialogFormVisible">
        <el-form :model="form">
          <el-form-item label="姓名" :label-width="formLabelWidth">
            <el-input v-model="form.name" value="ss" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="性别" :label-width="formLabelWidth">
            <el-input v-model="form.description" value="xx" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="电话" :label-width="formLabelWidth">
            <el-input v-model="form.description" value="xx" auto-complete="off"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </template>

  <script>
    const cityOptions = ['培训课程', '资料分类', '学员管理', '购买视频记录', '合作企业管理', '推广人', '招生课程', '资料管理', '学习记录','培训记录','招聘信息管理','培训题库'];
    export default {
      data() {
        return {
          tableData: [{
            name: '郝莹',
            sex: '女',
            phone: '18210773363',
            class: 'AOPA一期',
            reg_time: '2017.11.1',
            last_login: '2017.11.05'
          }, {
            name: '郝莹',
            sex: '女',
            phone: '18210773363',
            class: 'AOPA一期',
            reg_time: '2017.11.1',
            last_login: '2017.11.05'
          }, {
            name: '郝莹',
            sex: '女',
            phone: '18210773363',
            class: 'AOPA一期',
            reg_time: '2017.11.1',
            last_login: '2017.11.05'
           }],
          dialogTableVisible: false,
          dialogFormVisible: false,
          form: {
            name: '',
            region: '',
            date1: '',
            date2: '',
            delivery: false,
            type: [],
            resource: '',
            desc: ''
          },
          formLabelWidth: '120px',
          checkAll: false,
          checkedCities: ['培训课程', '资料分类'],
          cities: cityOptions,
          isIndeterminate: true
        }
      },
      methods: {
        handleCheckAllChange(val) {
          this.checkedCities = val ? cityOptions : [];
          this.isIndeterminate = false;
        },
        handleCheckedCitiesChange(value) {
          let checkedCount = value.length;
          this.checkAll = checkedCount === this.cities.length;
          this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length;
        },
        openDetail (){
          this.$router.push({path:'/student/studentinfo'});
        },
        deleteItem() {
          this.$confirm('确定删除此学员吗?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            });
          }).catch(() => {

          });
        }
      }
    }
  </script>
