  <template>
    <div class="fillcontain">
          <el-table
            :data="tableData"
            border
            style="width: 100%">
            <el-table-column
              prop="plane"
              label="飞机">
            </el-table-column>
            <el-table-column
              prop="systemscore"
              label="系统评分">
            </el-table-column>
            <el-table-column
              prop="teacherscore"
              label="教员评分">
            </el-table-column>
            <el-table-column
              prop="duration"
              label="飞行时长">
            </el-table-column>
            <el-table-column
              prop="endtime"
              label="飞行结束时间">
            </el-table-column>
            <el-table-column
              prop="field"
              label="场地">
            </el-table-column>
            <el-table-column
              prop="subject"
              label="科目">
            </el-table-column>
            <el-table-column
              prop="coach"
              label="执机教练">
            </el-table-column>
            <el-table-column
              prop="wind"
              label="风力">
            </el-table-column>
            <el-table-column
              prop="ucount"
              label="架次">
            </el-table-column>
            <el-table-column
              prop="height"
              label="高度">
            </el-table-column>
            <el-table-column
              prop="angle"
              label="角度">
            </el-table-column>
            <el-table-column
              prop="distance"
              label="距离">
            </el-table-column>
            <el-table-column
              prop="outward"
              label="向外偏移值">
            </el-table-column>
            <el-table-column
              prop="inward"
              label="向内偏移值">
            </el-table-column>
          </el-table>

    </div>
  </template>
  <script>
    export default {
      data() {
        return {
          tableData: [{
            plane: '李跃01',
            systemscore: '0',
            teacherscore: '0',
            duration: '45秒',
            endtime: '2017/12/01 11:33:22',

            field: '20171028六号场',
            subject: '悬停训练',
            coach: '董超',
            wind: '0',
            ucount: '32',

            height: '93',
            angle: '0',
            distance: '0',
            outward: '2.66',
            inward: '0'
          }, {
            plane: '李跃01',
            systemscore: '0',
            teacherscore: '0',
            duration: '45秒',
            endtime: '2017/12/01 11:33:22',

            field: '20171028六号场',
            subject: '悬停训练',
            coach: '董超',
            wind: '0',
            ucount: '32',

            height: '93',
            angle: '0',
            distance: '0',
            outward: '2.66',
            inward: '0'
          }, {
            plane: '李跃01',
            systemscore: '0',
            teacherscore: '0',
            duration: '45秒',
            endtime: '2017/12/01 11:33:22',

            field: '20171028六号场',
            subject: '悬停训练',
            coach: '董超',
            wind: '0',
            ucount: '32',

            height: '93',
            angle: '0',
            distance: '0',
            outward: '2.66',
            inward: '0'
           }],
          dialogTableVisible: false,
          dialogFormVisible: false,
          isIndeterminate: true
        }
      },
        methods: {
          handleCheckAllChange(val) {
            this.checkedCities = val ? cityOptions : [];
            this.isIndeterminate = false;
          },
          handleCheckedCitiesChange(value) {
            let checkedCount = value.length;
            this.checkAll = checkedCount === this.cities.length;
            this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length;
          },
          onTabChange(tab, event){
            if(tab.name="first")
              this.$router.push({path:'/studentinfo1'});
            else if(tab.name="second")
              this.$router.push({path:'/studentinfo1'});
            else
              this.$router.push({path:'/studentinfo1'});
          },
          open() {
            this.$confirm('此操作将永久删除该角色, 是否继续?', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              this.$message({
                type: 'success',
                message: '删除成功!'
              });
            }).catch(() => {

            });
           }
        }
    }
  </script>
