<template>
  <div class="fillcontain">
    <div class="head-top">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item>首页</el-breadcrumb-item>
        <el-breadcrumb-item>权限管理</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="main_content">
      <el-card class="box-card">
        <div slot="header" class="clearfix">
          <el-button type="primary" size="small" icon="el-icon-plus" @click="openAddForm">添加权限</el-button>
          <el-button type="primary" size="small" icon="el-icon-refresh" @click="refresh">刷新</el-button>
        </div>
        <el-table
          :data="tableData"
          v-loading="loading"
          style="width: 100%">
          <el-table-column
            prop="authName"
            label="名称"
            width="180">
          </el-table-column>
          <el-table-column
            prop="authDesc"
            label="描述">
          </el-table-column>
          <el-table-column
            fixed="right"
            label="操作">
            <template slot-scope="scope">
              <el-button size="mini" @click="openEditForm(scope.row.id)" type="primary" plain>编辑</el-button>
              <el-button size="small" @click="deleteItem(scope.$index, scope.row)" type="primary" plain>删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-card>
    </div>

    <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible">
      <el-form :model="form" ref="dataForm">
        <el-form-item label="名称" :label-width="formLabelWidth">
          <el-input v-model="form.authName" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="描述" :label-width="formLabelWidth">
          <el-input v-model="form.authDesc" auto-complete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button v-if="dialogStatus=='create'" type="primary" @click="addData">确 定</el-button>
        <el-button v-else type="primary" @click="saveData">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import {getAllAuthority, addAuthority, deleteAuthority, getAuthorityById, saveAuthority} from '@/api/table'
  import { toast } from '@/utils/index'
  export default {
    data() {
      return {
        tableData: [],
        dialogFormVisible: false,

        form: {
          authName: '',
          authDesc: '',
        },
        selectedId:'',

        dialogStatus: '',
        textMap: {
          update: '编辑',
          create: '创建'
        },
        formLabelWidth: '120px',
        isIndeterminate: true
      }
    },
    created() {
      this.refresh();
    },
    methods: {
      refresh(){
        this.loading = true
        this.fetchData()
      },

      //列出权限
      fetchData() {
        getAllAuthority().then(response => {
          const result = response.data;
          if(result.code == -1){
            this.$message({
              type: '失败',
              message: result.msg
            });
          }
          const authoritys = result.data;
          this.tableData = [];
          if(authoritys.length != 0){
            authoritys.forEach((item, index) => {
              const tableItem = {
                id:item.id,
                authName: item.authName,
                authDesc: item.authDesc,
                createTime: item.createTime,
                updateTime: item.updateTime,
                index: index
              }
              this.tableData.push(tableItem)
            })
          } else {

          }
          this.loading = false

        }).catch(function (error) {
          console.log(error);
        });
      },

      //打开添加表单
      openAddForm() {
        this.dialogStatus = "create"
        this.dialogFormVisible = true;
        //先清空表单中的数据（编辑的时候会留下一些数据）
        this.form = {
          authName: '',
          authDesc: '',
        }
      },

      //添加权限
      addData() {
        addAuthority(this.form).then(response => {
          const result = response.data;
          if (result.code == 0) {
            this.$message({
              type: 'success',
              message: '添加成功!'
            });
            this.dialogFormVisible = false;
            this.fetchData();
            this.form = {
              authName: '',
              authDesc: '',
            }
          }else {
            this.$message({
              type: '失败',
              message: result.msg
            });
          }
        }).catch(function (error) {
          this.$message({
            type: '失败',
            message: error
          });
          console.log(error);
        });
      },

      //打开编辑表单
      openEditForm(id) {
        this.selectedId = id;
        this.dialogStatus = "update"
        getAuthorityById(id).then(response => {
          const result = response.data;
          if (result.code == 0) {
            this.form = {
              authName: result.data.authName,
              authDesc: result.data.authDesc,
            }
            this.dialogFormVisible = true;
          }else {
            this.$message({
              type: '失败',
              message: result.msg
            });
          }
        }).catch(function (error) {
          this.$message({
            type: '失败',
            message: error
          });
        });
      },

      //保存编辑数据
      saveData() {
        saveAuthority(this.form, this.selectedId).then(response => {
          const result = response.data;
          if (result.code == 0) {
            toast(this, "success", "修改成功");
            this.dialogFormVisible = false;
            this.fetchData();
            this.form = {
              authName: '',
              authDesc: '',
            }
          }else {
            toast(this, "失败", result.msg);
          }
        }).catch(function (error) {
          toast(this, "失败", error);
          console.log(error);
        });
      },

      //根据id删除一个权限
      deleteItem(index, row) {
        this.$confirm('确定删除此权限吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          deleteAuthority(row.id).then(response => {
            const result = response.data;
            if (result.code == 0) {
              this.$message({
                type: 'success',
                message: '删除成功!'
              });
              this.tableData.splice(index, 1);
            }else {
              this.$message({
                type: '失败',
                message: result.msg
              });
            }
          }).catch(function (error) {
            this.$message({
              type: '失败',
              message: error
            });
            console.log(error);
          });
        }).catch(() => {

        });

      },
      // method end
    }
  }
</script>
