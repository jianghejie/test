<template>
    <div class="fillcontain">
        <div class="head-top">
          <el-breadcrumb separator="/">
            <el-breadcrumb-item>首页</el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        <div class="main_content">
          <div class="line1">
              <div id="line1" class="" style="width: 90%;height:450px;"></div>
              <div id="line2" class="" style="width: 90%;height:450px;"></div>
          </div>
        </div>
    </div>
</template>

<script>
    import echarts from 'echarts/lib/echarts';

    // 引入柱状图
    import 'echarts/lib/chart/bar';
    import 'echarts/lib/chart/line';
    import 'echarts/lib/component/title';
    import 'echarts/lib/component/legend';
    import 'echarts/lib/component/toolbox';
    import 'echarts/lib/component/markPoint';
    import 'echarts/lib/component/tooltip';
    export default {
        mounted(){
            this.myChart = echarts.init(document.getElementById('line1'));
            this.drawTest();
            this.myChart = echarts.init(document.getElementById('line2'));
            this.drawMap();
        },
        props: ['sevenDate', 'sevenDay'],
        methods: {
          drawTest(){
            var option = {
              title : {
                text: '世界人口总量',
                subtext: '数据来自网络'
              },
              tooltip : {
                trigger: 'axis'
              },
              legend: {
                data:['2011年']
              },
              toolbox: {
                show : true,
                feature : {
                  mark : {show: true},
                  dataView : {show: true, readOnly: false},
                  magicType: {show: true, type: ['line', 'bar']},
                  restore : {show: true},
                  saveAsImage : {show: true}
                }
              },
              calculable : true,
              xAxis : [
                {
                  type : 'value',
                  boundaryGap : [0, 0.01]
                }
              ],
              yAxis : [
                {
                  type : 'category',
                  data : ['巴西','印尼','美国','印度','中国','世界人口(万)']
                }
              ],
              series : [
                {
                  name:'2011年',
                  type:'bar',
                  data:[18203, 23489, 29034, 104970, 131744, 630230]
                }
              ]
            };
            this.myChart.setOption(option);
          },
          drawMap(){
            var dataAxis = ['点', '击', '柱', '子', '或', '者', '两', '指', '在', '触', '屏', '上', '滑', '动', '能', '够', '自', '动', '缩', '放'];
            var data = [220, 182, 191, 234, 290, 330, 310, 123, 442, 321, 90, 149, 210, 122, 133, 334, 198, 123, 125, 220];
            var yMax = 500;
            var dataShadow = [];

            for (var i = 0; i < data.length; i++) {
              dataShadow.push(yMax);
            }

            var option = {
              title: {
                text: '特性示例：渐变色 阴影 点击缩放',
                subtext: 'Feature Sample: Gradient Color, Shadow, Click Zoom'
              },
              xAxis: {
                data: dataAxis,
                axisLabel: {
                  inside: true,
                  textStyle: {
                    color: '#fff'
                  }
                },
                axisTick: {
                  show: false
                },
                axisLine: {
                  show: false
                },
                z: 10
              },
              yAxis: {
                axisLine: {
                  show: false
                },
                axisTick: {
                  show: false
                },
                axisLabel: {
                  textStyle: {
                    color: '#999'
                  }
                }
              },
              dataZoom: [
                {
                  type: 'inside'
                }
              ],
              series: [
                { // For shadow
                  type: 'bar',
                  itemStyle: {
                    normal: {color: 'rgba(0,0,0,0.05)'}
                  },
                  barGap:'-100%',
                  barCategoryGap:'40%',
                  data: dataShadow,
                  animation: false
                },
                {
                  type: 'bar',
                  itemStyle: {
                    normal: {
                      color: new echarts.graphic.LinearGradient(
                        0, 0, 0, 1,
                        [
                          {offset: 0, color: '#83bff6'},
                          {offset: 0.5, color: '#188df0'},
                          {offset: 1, color: '#188df0'}
                        ]
                      )
                    },
                    emphasis: {
                      color: new echarts.graphic.LinearGradient(
                        0, 0, 0, 1,
                        [
                          {offset: 0, color: '#2378f7'},
                          {offset: 0.7, color: '#2378f7'},
                          {offset: 1, color: '#83bff6'}
                        ]
                      )
                    }
                  },
                  data: data
                }
              ]
            };
            this.myChart.setOption(option);
          }
        },
        watch: {
            sevenDate: function (){
                this.initData()
            },
            sevenDay: function (){
                this.initData()
            }
        }
    }
</script>

<style lang="less">
	@import '../style/mixin';
    .line1{
        display: flex;
        justify-content: center;
    }
</style>

