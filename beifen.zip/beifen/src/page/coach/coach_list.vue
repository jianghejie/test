<template>
    <div class="fillcontain">
      <div class="head-top">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item :to="{ path: '/index' }">首页</el-breadcrumb-item>
          <el-breadcrumb-item>教练管理</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="main_content">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <el-button type="primary" size="small" icon="el-icon-plus"  @click="dialogFormVisible = true">添加教练</el-button>
          </div>
          <el-table
            :data="tableData"
            style="width: 100%">
            <el-table-column
              prop="name"
              label="姓名"
              width="180">
            </el-table-column>
            <el-table-column
              prop="phone"
              label="电话">
            </el-table-column>
            <el-table-column
              prop="class"
              label="班级">
              <template slot-scope="scope">
                <router-link to="/classInfo">  {{ scope.row.class }}  </router-link>
              </template>
            </el-table-column>
            <el-table-column
              prop="student"
              label="学员">
            </el-table-column>
            <el-table-column
              fixed="right"
              label="操作">
              <template slot-scope="scope">
                <el-button size="mini" @click="dialogFormVisible = true" type="primary" plain>编辑</el-button>
                <el-button size="mini"  @click="deleteItem" type="primary" plain>删除</el-button>
              </template>
            </el-table-column>
          </el-table>
          <!-- 分页 -->
          <div class="pagination-container">
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="currentPage4"
              :page-sizes="[100, 200, 300, 400]"
              :page-size="100"
              layout="total, sizes, prev, pager, next, jumper"
              :total="400">
            </el-pagination>
          </div>
        </el-card>
      </div>

      <el-dialog title="添加教练" :visible.sync="dialogFormVisible">
        <el-form :model="form">
          <el-form-item label="教练" :label-width="formLabelWidth">
            <template>
              <el-select v-model="value" placeholder="请选择">
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </template>
          </el-form-item>
          <el-form-item label="选择课程" :label-width="formLabelWidth">
              <el-transfer v-model="value1" :data="data" :titles="['选择课程', '已选']">

              </el-transfer>
          </el-form-item>
          <el-form-item label="排课" :label-width="formLabelWidth">

          </el-form-item>
          <el-form-item label="上午8点" :label-width="formLabelWidth">
              <el-select v-model="value" placeholder="请选择">
                <el-option label="外场第三阶段：自旋/八字航点" value="shanghai"></el-option>
                <el-option label="云上智农第一阶段：飞行训练" value="beijing"></el-option>
              </el-select>
          </el-form-item>

          <el-form-item label="上午10点" :label-width="formLabelWidth">
              <el-select v-model="value" placeholder="请选择">
                <el-option label="外场第三阶段：自旋/八字航点" value="shanghai"></el-option>
                <el-option label="云上智农第一阶段：飞行训练" value="beijing"></el-option>
              </el-select>
          </el-form-item>
          <el-form-item label="下午13点" :label-width="formLabelWidth">
              <el-select v-model="value" placeholder="请选择">
                <el-option label="外场第三阶段：自旋/八字航点" value="shanghai"></el-option>
                <el-option label="云上智农第一阶段：飞行训练" value="beijing"></el-option>
              </el-select>
          </el-form-item>
          <el-form-item label="下午15点" :label-width="formLabelWidth">
              <el-select v-model="value" placeholder="请选择">
                <el-option label="外场第三阶段：自旋/八字航点" value="shanghai"></el-option>
                <el-option label="云上智农第一阶段：飞行训练" value="beijing"></el-option>
              </el-select>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </template>

  <script>
    const cityOptions = ['培训课程', '资料分类', '学员管理', '购买视频记录', '合作企业管理', '推广人', '招生课程', '资料管理', '学习记录','培训记录','招聘信息管理','培训题库'];
    export default {
      data() {
        return {
          tableData: [{
            name: '郝莹',
            phone: '18210773363',
            class: 'AOPA一期',
            student: '30人'
          }, {
            name: '陈朋',
            phone: '18210773363',
            class: 'AOPA一期',
            student: '30人'
          }, {
            name: '孙佳旺',
            phone: '18210773363',
            class: 'AOPA一期',
            student: '30人'
           }],
          dialogTableVisible: false,
          dialogFormVisible: false,
          form: {
            name: '',
            region: '',
            date1: '',
            date2: '',
            delivery: false,
            type: [],
            resource: '',
            desc: ''
          },
          formLabelWidth: '120px',
          checkAll: false,
          checkedCities: ['培训课程', '资料分类'],
          cities: cityOptions,
          isIndeterminate: true
        }
      },
      methods: {
        handleCheckAllChange(val) {
          this.checkedCities = val ? cityOptions : [];
          this.isIndeterminate = false;
        },
        handleCheckedCitiesChange(value) {
          let checkedCount = value.length;
          this.checkAll = checkedCount === this.cities.length;
          this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length;
        },
        deleteItem() {
          this.$confirm('确定删除此教练吗?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            });
          }).catch(() => {

          });
        }
      }
    }
  </script>
