<template>
    <div class="fillcontain">
        <div class="head-top">
          <el-breadcrumb separator="/">
            <el-breadcrumb-item>首页</el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        <div class="main_content">
          <el-row class="panel-group" :gutter="40">
            <el-col :span="12">
              <el-card class="box-card">
                <div slot="header" class="clearfix">
                  <span>公告</span>
                </div>
                <div  class="text item">
                  暂无公告
                </div>
              </el-card>
            </el-col>
            <el-col :span="12">
              <el-card class="box-card">
                <div slot="header" class="clearfix">
                  <span>消息</span>
                </div>
                <div  class="text item">
                  暂无消息
                </div>
              </el-card>
            </el-col>
          </el-row>
          <el-row class="panel-group" :gutter="40">
            <el-col :span="24">
              <el-card class="box-card">
                <div slot="header" class="clearfix">
                  <span>今日数据</span>
                </div>
                <el-row class="panel-group" :gutter="40">
                  <el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
                    <info-block title="学员" number="30000" ></info-block>
                  </el-col>
                  <el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
                    <info-block title="教练" number="100" ></info-block>
                  </el-col>
                  <el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
                    <info-block title="场地" number="600" ></info-block>
                  </el-col>
                  <el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
                    <info-block title="飞机" number="800" ></info-block>
                  </el-col>
                </el-row>
              </el-card>
            </el-col>
          </el-row>


        </div>
    </div>
</template>

<script>
    import echarts from 'echarts/lib/echarts';
    // 引入柱状图
    import 'echarts/lib/chart/bar';
    import 'echarts/lib/chart/line';
    import 'echarts/lib/component/title';
    import 'echarts/lib/component/legend';
    import 'echarts/lib/component/toolbox';
    import 'echarts/lib/component/markPoint';
    import 'echarts/lib/component/tooltip';
    import infoblock from "../components/InfoBlock.vue"
    export default {
      components:{
        'info-block': infoblock
      },
      mounted(){
          this.myChart = echarts.init(document.getElementById('line1'));
          this.initData();
      },
      data() {
        return {
          title: "ss",
        }
      },
      props: ['sevenDate', 'sevenDay'],
      methods: {
          initData(){
              const colors = ['#d14a61', '#5793f3', '#675bba', '#13CE66'];
              // 指定图表的配置项和数据
               var option = {
                   title: {
                       text: 'ECharts 入门示例'
                   },
                   tooltip: {},
                   legend: {
                       data:['销量']
                   },
                   xAxis: {
                       data: ["衬衫","羊毛衫","雪纺衫","裤子","高跟鞋","袜子"]
                   },
                   yAxis: {},
                   series: [{
                       name: '销量',
                       type: 'bar',
                       data: [5, 20, 36, 10, 10, 20]
                   }]
               };

              this.myChart.setOption(option);
          }
      },
      watch: {
          sevenDate: function (){
              this.initData()
          },
          sevenDay: function (){
              this.initData()
          }
      }
    }
</script>


<style rel="stylesheet/scss" lang="scss" scoped>
  .panel-group {
    margin-top: 18px;
    .card-panel-col{
      margin-bottom: 32px;
    }
    .card-panel {
      height: 108px;
      cursor: pointer;
      font-size: 12px;
      position: relative;
      overflow: hidden;
      color: #666;
      background: #fff;
      box-shadow: 4px 4px 40px rgba(0, 0, 0, .05);
      border-color: rgba(0, 0, 0, .05);
      &:hover {
        .card-panel-icon-wrapper {
          color: #fff;
        }
        .icon-people {
          background: #40c9c6;
        }
        .icon-message {
          background: #36a3f7;
        }
        .icon-money {
          background: #f4516c;
        }
        .icon-shoppingCard {
          background: #34bfa3
        }
      }
      .icon-people {
        color: #40c9c6;
      }
      .icon-message {
        color: #36a3f7;
      }
      .icon-money {
        color: #f4516c;
      }
      .icon-shoppingCard {
        color: #34bfa3
      }
      .card-panel-icon-wrapper {
        float: left;
        margin: 14px 0 0 14px;
        padding: 16px;
        transition: all 0.38s ease-out;
        border-radius: 6px;
      }
      .card-panel-icon {
        float: left;
        font-size: 48px;
      }
      .card-panel-description {
        float: right;
        font-weight: bold;
        margin: 26px;
        margin-left: 0px;
        .card-panel-text {
          line-height: 18px;
          color: rgba(0, 0, 0, 0.45);
          font-size: 16px;
          margin-bottom: 12px;
        }
        .card-panel-num {
          font-size: 20px;
        }
      }
    }
  }
</style>



