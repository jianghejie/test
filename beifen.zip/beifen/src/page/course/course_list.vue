<template>
    <div class="fillcontain">
      <div class="head-top">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item>首页</el-breadcrumb-item>
          <el-breadcrumb-item>课程列表</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="main_content">

        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <el-button type="primary" size="small" icon="el-icon-plus"  @click="openAddForm">添加</el-button>
            <el-button size="mini" @click="toggleSelection(0)">全选</el-button>
            <el-button size="mini" @click="toggleSelection(1)">反选</el-button>
            <el-button size="mini" @click="toggleSelection(2)">清除</el-button>
            <el-input class="right" placeholder="搜索" v-model="input5" style="width:230px;">
              <el-button slot="append" icon="el-icon-search"></el-button>
            </el-input>
          </div>
          <el-table
            v-loading="listLoading"
            :data="tableData"
            ref="selectTable"
            border
            style="width: 100%">
            <el-table-column
              type="selection"
              width="55">
            </el-table-column>
            <el-table-column
              prop="catName"
              label="所属科目"
              :filters="[{ text: '农业无人机飞防专业', value: '1' }, { text: '理论课程', value: '2' }]"
                    :filter-method="filterTag"
                    filter-placement="bottom-end"
              width="180">
            </el-table-column>
            <el-table-column
              prop="name"
              label="课程名称">
            </el-table-column>
            <el-table-column
              prop="teachForm"
              label="授课形式">
            </el-table-column>
            <el-table-column
              prop="cover"
              label="封面">
              <template slot-scope="scope">
                <img width=100 height=50 :src="scope.row.cover" />
              </template>
            </el-table-column>
            <el-table-column
              prop="testNum"
              label="考题">
                <template slot-scope="scope">
                  <router-link to="/courseInfo/question"> {{ scope.row.testNum }} </router-link>
                </template>
            </el-table-column>
            <el-table-column
              prop="videoNum"
              label="视频">
                <template slot-scope="scope">
                  <router-link to="/courseInfo/vedio"> {{ scope.row.videoNum }} </router-link>
                </template>
            </el-table-column>
            <el-table-column
              prop="createTime"
              label="创建时间">
            </el-table-column>
            <el-table-column
              prop="status"
              label="状态">
            </el-table-column>
            <el-table-column
              fixed="right"
              label="操作">
              <template slot-scope="scope">
                <el-dropdown size="small" trigger="click" show-timeout="0" hide-timeout="0" @command="handleCommand">
                  <el-button size="mini" type="primary" plain>
                    修改<i class="el-icon-arrow-down el-icon--right"></i>
                  </el-button>
                  <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item :command="dropItemClickInfo(scope.row.id, 'edit')">编辑</el-dropdown-item>
                    <el-dropdown-item :command="dropItemClickInfo(scope.row.id, 'delete')">删除</el-dropdown-item>
                  </el-dropdown-menu>
                </el-dropdown>
                <el-dropdown size="small" trigger="click" show-timeout="0" hide-timeout="0" @command="handleCommand">
                  <el-button size="mini" type="primary" plain>
                    内容<i class="el-icon-arrow-down el-icon--right"></i>
                  </el-button>
                  <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item :command="dropItemClickInfo(scope.row.id, 'import-q')">导入试题</el-dropdown-item>
                    <el-dropdown-item :command="dropItemClickInfo(scope.row.id, 'import-v')">导入视频</el-dropdown-item>
                  </el-dropdown-menu>
                </el-dropdown>
              </template>
            </el-table-column>
          </el-table>
          <!-- 分页 -->
          <div class="pagination-container">
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="currentPage"
              :page-sizes="[5, 20, 50, 100]"
              :page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="totalElements">
            </el-pagination>
          </div>
        </el-card>
      </div>

      <!--对话框-->
      <!--编辑-->
      <el-dialog  :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible">
        <el-form :model="form">
          <el-form-item label="所属专业" :label-width="formLabelWidth">
            <el-cascader
              :options="options"
              :show-all-levels="false"
              v-model="selectedOptions">
            </el-cascader>
          </el-form-item>
          <el-form-item label="课程名称" :label-width="formLabelWidth">
            <el-input v-model="form.name"  auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="授课形式" :label-width="formLabelWidth">
            <el-select v-model="form.teachForm" placeholder="请选择">
              <el-option
                v-for="item in teachFormOptions"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="课程封面" :label-width="formLabelWidth">
            <uploader
              ref="upload"
              :onSuccess="onUploadSuccess"
              :srcUrl="form.cover"
              type="img"
              :showFileList = "false"
            >
            </uploader>
          </el-form-item>

          <el-form-item label="大纲" :label-width="formLabelWidth">
            <el-input
              type="textarea"
              :rows="2"
              placeholder="请输入内容"
              v-model="form.curriculum">
            </el-input>
          </el-form-item>
          <el-form-item label="课程介绍" :label-width="formLabelWidth">
            <el-input
              type="textarea"
              :rows="2"
              placeholder="请输入内容"
              v-model="form.description">
            </el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button v-if="dialogStatus=='create'" type="primary" @click="addItem">确 定</el-button>
          <el-button v-else type="primary" @click="saveItem">确 定</el-button>
        </div>
      </el-dialog>

      <!--导入题库-->
      <el-dialog
        width="50%"
        title="选择问题"
        :visible.sync="questionSelectVisible"
        append-to-body>
        <TtaTransfer
          :courseId="selectedId"
          :onSuccess="onImportQuestionSuccess"
          type="question"
          ref="ttaTransfer">
        </TtaTransfer>
        <div slot="footer" class="dialog-footer">
          <el-button @click="questionSelectVisible = false">取 消</el-button>
          <el-button :loading="questionImportLoading" type="primary" @click="importQuestions">导 入</el-button>
        </div>
      </el-dialog>
      <!--导入视频-->
      <el-dialog
        width="50%"
        title="选择视频"
        :visible.sync="videoSelectVisible"
        append-to-body>
        <TtaTransfer
          :courseId="selectedId"
          :onSuccess='onImportVideoSuccess'
          type='video'
          ref="ttaTransferv">
        </TtaTransfer>
        <div slot="footer" class="dialog-footer">
          <el-button @click="videoSelectVisible = false">取 消</el-button>
          <el-button :loading="videoImportLoading" type="primary" @click="importVideos">导 入</el-button>
        </div>
      </el-dialog>
    </div>
  </template>
  <style>
    .avatar-uploader .el-upload {
      border: 1px dashed #d9d9d9;
      border-radius: 6px;
      cursor: pointer;
      position: relative;
      overflow: hidden;
    }
    .avatar-uploader .el-upload:hover {
      border-color: #409EFF;
    }
    .avatar-uploader-icon {
      font-size: 28px;
      color: #8c939d;
      width: 178px;
      height: 178px;
      line-height: 178px;
      text-align: center;
    }
  </style>
  <script>
    import {getCourseByPage, deleteCourse, addCourse, getCourse, saveCourse, getAllClassCatgory} from '@/api/table'
    import {toast, formatTime, addSimpleData, deleteData, getOneForEdit, saveData} from '@/utils/index'
    import uploader from '@/components/uploader';
    import TtaTransfer from '@/components/TtaTransfer';
    export default {
      components: {
        uploader,
        TtaTransfer,
      },
      data() {
        return {
          //表格
          tableData: [],
          selectedId:'',
          listLoading: false,
          formLabelWidth: '120px',
          vedioDialogTableData:[
            {
              name: '地面站12-4',
              type: '地面站',
              cover: '/',
              duration: '2min',
              price: '10',
              time: '2010.10.23'
            },{
              name: '模拟器的使用',
              type: '模拟器',
              cover: '/',
              duration: '2min',
              price: '10',
              time: '2010.10.23'
            },{
              name: '模拟器的使用',
              type: '模拟器',
              cover: '/',
              duration: '2min',
              price: '10',
              time: '2010.10.23'
            }
          ],

          questionDialogTableData:[
            {
              content: '为什么有钱就可以为所欲为',
              answer: '因为有钱就是大爷 ',
              form: '选择题',
              time: '2017.11.29',

            },{
              content: '为什么有钱就可以为所欲为',
              answer: '因为有钱就是大爷 ',
              form: '选择题',
              time: '2017.11.29',
            },{
              content: '为什么有钱就可以为所欲为',
              answer: '因为有钱就是大爷 ',
              form: '选择题',
              time: '2017.11.29',
            }
          ],

          //选项
          options: [],
          teachFormOptions: [{value:0, label:"理论"}, {value:1, label:"口试"}, {value:2, label:"模拟"}],
          selectedOptions: [],

          //表单
          form: {
            name: "",
            catId: "",
            cover: "",
            curriculum: "",
            description: "",
            teachForm: 0
          },

          //对话框
          videoSelectVisible: false,
          dialogFormVisible: false,
          innerVisible: false,
          questionSelectVisible: false,
          textMap: {
            update: '编辑',
            create: '创建'
          },
          dialogStatus: '',

          //分页
          currentPage: 0,
          pageSize: 5,
          totalElements: 0,

          //导入加载状态
          questionImportLoading: false,
          videoImportLoading: false,
        }
      },

      mounted() {
        this.listLoading = false;
      },

      watch: {
        selectedOptions: function (newSelectedOptions) {
          this.form.catId = newSelectedOptions[newSelectedOptions.length-1];
        },
        teachFormSelectedOptions: function (newSelectedOptions) {
          this.form.teachForm = newSelectedOptions[0];
        },
      },

      created() {
        this.fetchData(this.currentPage, this.pageSize);
        this.getCategory();
      },

      methods: {
        //获取
        dropItemClickInfo (id, c) {
          var info = {id:id, action:c};
          return info;
        },

        //打开添加表单
        openAddForm() {
          this.dialogStatus = "create"
          this.dialogFormVisible = true;
          //清空表单数据
          for (let key in this.form) {
            this.form[key] = ""
          }
          this.selectedOptions = [];
          this.$refs.upload.reset();
        },

        //打开编辑表单
        openEditForm(id) {
          this.dialogStatus = "update"
          this.selectedId = id;
          var callBack = function () {
            this.selectedOptions = this.getCateRout(this.options, this.form.catId);
          };
          getOneForEdit(this, id, getCourse, callBack.bind(this));
        },

        //打开导入对话框
        openImportQ(id) {
          this.selectedId = id;
          this.questionSelectVisible = true;
          this.$nextTick(function () {
            this.$refs.ttaTransfer.reset();
          });
        },

        //打开导入对话框
        openImportV(id) {
          this.selectedId = id;
          this.videoSelectVisible = true;
          this.$nextTick(function () {
            this.$refs.ttaTransferv.reset();
          });
        },

        //根据id删除分类
        deleteItem(id) {
          deleteData(this, deleteCourse, id, '确定删除此课程吗?');
        },

        //添加课程
        addItem() {
          addSimpleData(this, addCourse);
        },

        //编辑课程
        saveItem() {
          saveData(this, saveCourse, this.selectedId);
        },

        //分页查询课程
        fetchData(page, size) {
          this.listLoading = true
          getCourseByPage(page, size).then(response => {
            const result = response.data;
            if(result.code == -1){
              this.$message({
                type: '失败',
                message: result.msg
              });
            }

            var temp = result.data.content;
            this.totalElements = result.data.totalElements;
            this.tableData = [];
            if(temp.length != 0){
              temp.forEach((item, index) => {
                const tableItem = {
                  id:item.id,
                  name: item.name,
                  catId: item.catId,
                  catName:item.catName,
                  teachForm: item.teachForm,
                  cover: item.cover,
                  description: item.description,
                  curriculum: item.curriculum,
                  testNum: item.testNum,
                  videoNum: item.videoNum,
                  testNum: item.testNum,
                  createTime: formatTime(item.createTime),
                  status: item.status
                }
                this.tableData.push(tableItem)
              })
            } else {

            }

          }).catch(function (error) {
            console.log(error);
          });
          this.listLoading = false
        },

        //列出分类
        getCategory() {
          getAllClassCatgory().then(response => {
            const result = response.data;
            if(result.code == -1){
              this.$message({
                type: '失败',
                message: result.msg
              });
            }
            const categoryList = result.data;
            this.options = [];
            this.options = this.refining(categoryList);
            console.log(this.options);
          }).catch(function (error) {
            console.log(error);
          });
        },

        refining(nestJson) {
          var opts = [];
          for (var i = 0; i < nestJson.length; i++) {
            var optionItem = {
              value: nestJson[i].id,
              label: nestJson[i].name,
              //为了便于查找一个分类的完整路径加上cateCode，注意这里数据库的命名有点不统一
              catCode: this.parseCatCode(nestJson[i].cateCode),
            };

            if (nestJson[i].children) {
              optionItem.children = this.refining(nestJson[i].children);
            }
            opts.push(optionItem);
          }
          return opts;
        },

        //根据catid获得完整分类路径
        getCateRout(nestJson, catId) {
          var opts;
          for (var i = 0; i < nestJson.length; i++) {
            if(catId == nestJson[i].value){
              opts = nestJson[i].catCode
              return opts;
            }
            if (nestJson[i].children) {
              var temp = this.getCateRout(nestJson[i].children, catId)
              if(temp != null)
                opts = temp
            }
          }
          return opts;
        },

        //把catecode解析成cascader能读取的形式,如[id1, id2, id3]
        parseCatCode(code){
          var fullPath = []
          for(var i = 0; i < code.length / 32; i++){
            fullPath.push(code.substring(i * 32, (i + 1) * 32))
          }
          return fullPath
        },

        onCategorySelected(cate) {
          console.log(cate);
        },

        //处理分页数据的变化
        handleSizeChange(val) {
          this.pageSize = val;
          this.currentPage = 0;
          this.fetchData(this.currentPage, this.pageSize);
        },

        handleCurrentChange(val) {
          if(val > 1) {
            this.currentPage = val - 1;
            this.fetchData(this.currentPage, this.pageSize);
          }
        },

        //下拉菜单点击事件
        handleCommand(command) {
          switch(command.action)
          {
            case "edit":
              this.openEditForm(command.id)
              break;
            case "delete":
              this.deleteItem(command.id);
              break;
            case "import-q":
              this.openImportQ(command.id);
              break;
            case "import-v":
              this.openImportV(command.id);
              break;
          }
        },

        toggleSelection(type){
          if(type === 0) {
            this.tableData.forEach((row, index) => {
              this.$refs.selectTable.toggleRowSelection(row,true);
            });
          } else if (type === 1) {
            this.tableData.forEach((row, index) => {
              this.$refs.selectTable.toggleRowSelection(row);
            });
          } else {
            this.$refs.selectTable.clearSelection();
          }
        },

        toggleQestionDialogSelection(type){
          if(type === 0) {
            this.questionDialogTableData.forEach((row, index) => {
              this.$refs.questionDialogSelectTable.toggleRowSelection(row,true);
            });
          } else if (type === 1) {
            this.questionDialogTableData.forEach((row, index) => {
              this.$refs.questionDialogSelectTable.toggleRowSelection(row);
            });
          } else {
            this.$refs.questionDialogSelectTable.clearSelection();
          }
        },

        toggleVideoDialogSelection(type){
          if(type === 0) {
            this.vedioDialogTableData.forEach((row, index) => {
              this.$refs.vedioDialogSelectTable.toggleRowSelection(row,true);
            });
          } else if (type === 1) {
            this.vedioDialogTableData.forEach((row, index) => {
              this.$refs.vedioDialogSelectTable.toggleRowSelection(row);
            });
          } else {
            this.$refs.vedioDialogSelectTable.clearSelection();
          }
        },

        onUploadSuccess(url) {
          this.form.cover = url;
        },

        importQuestions() {
          this.questionImportLoading = true;
          this.$refs.ttaTransfer.importAction();
        },

        importVideos() {
          this.videoImportLoading = true;
          this.$refs.ttaTransferv.importAction();
        },

        onImportQuestionSuccess() {
          this.questionImportLoading = false;
        },

        onImportVideoSuccess() {
          this.videoImportLoading = false;
        }
      },
    }
  </script>
