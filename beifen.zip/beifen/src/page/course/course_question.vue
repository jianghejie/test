<template>
  <div>
    <div>
      <el-card class="box-card">
        <div slot="header" class="clearfix">
          共30道题
          <el-button type="primary" size="mini" icon="el-icon-plus"  @click="dialogSelectVisible = true">导入题库</el-button>
        </div>
        <el-table
          :data="tableData"
          ref="multipleTable"
          @selection-change="handleSelectionChange"
          style="width: 100%">
          <el-table-column
            type="selection"
            width="55">
          </el-table-column>
          <el-table-column
            prop="content"
            label="试题内容">
          </el-table-column>
          <el-table-column
            prop="answer"
            label="答案">
          </el-table-column>
          <el-table-column
            prop="form"
            label="题型">
          </el-table-column>
          <el-table-column
            prop="time"
            label="创建时间">
          </el-table-column>

          <el-table-column
            fixed="right"
            label="操作">
            <template slot-scope="scope">

              <el-button type="text" size="small"  @click="dialogFormVisible = true"><i class="el-icon-close"></i></el-button>

            </template>
          </el-table-column>
        </el-table>
        <!-- 分页 -->
        <div class="pagination-container">
          <el-row :gutter="30">
            <el-col :span="6">
              <el-button size="mini" @click="toggleSelection(0)">全选</el-button>
              <el-button size="mini"  @click="toggleSelection(1)">反选</el-button>
              <el-button size="mini"  @click="toggleSelection(2)">清除</el-button>
              <el-button size="mini"  @click="deleteItems()">删除</el-button>
            </el-col>
            <el-col :span="3">
              <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="currentPage4"
                :page-sizes="[100, 200, 300, 400]"
                :page-size="100"
                layout="total, sizes, prev, pager, next, jumper"
                :total="400">

              </el-pagination>
            </el-col>
          </el-row>
        </div>
      </el-card>

    </div>
    <el-dialog
      width="50%"
      title="选择问题"
      :visible.sync="dialogSelectVisible"
      append-to-body>
      分类
      <el-select v-model="value" size="small"  placeholder="请选择" style="width:150px;margin-bottom: 15px;margin-left: 15px;">
        <el-option
          v-for="item in options"
          :key="item.value"
          :label="item.label"
          :value="item.value">
        </el-option>
      </el-select>
      <el-table
        :data="dialogTableData"
        v-loading="loading"
        ref="dialogSelectTable"
        @selection-change="handleCourseSelectionChange"
        style="width: 100%">
        <el-table-column
          type="selection"
          width="55">
        </el-table-column>
        <el-table-column
          prop="content"
          label="试题内容">
        </el-table-column>
        <el-table-column
          prop="answer"
          label="答案">
        </el-table-column>
        <el-table-column
          prop="form"
          label="题型">
        </el-table-column>
        <el-table-column
          prop="time"
          label="创建时间">
        </el-table-column>

      </el-table>
      <div class="pagination-container">
        <el-row :gutter="30">
          <el-col :span="21">
            <el-button size="mini" @click="toggleDialogSelection(0)">全选</el-button>
            <el-button size="mini"  @click="toggleDialogSelection(1)">反选</el-button>
            <el-button size="mini"  @click="toggleDialogSelection(2)">清除</el-button>
          </el-col>
          <el-col :span="3">
            <el-button size="mini" type="primary" @click="importCourse()">导入</el-button>
          </el-col>
        </el-row>
      </div>
    </el-dialog>

  </div>
</template>
<style>
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }

</style>
<script>
  export default {
    data() {
      return {
        tableData:[
          {
            content: '为什么有钱就可以为所欲为',
            answer: '因为有钱就是大爷 ',
            form: '选择题',
            time: '2017.11.29',

          },{
            content: '为什么有钱就可以为所欲为',
            answer: '因为有钱就是大爷 ',
            form: '选择题',
            time: '2017.11.29',
          },{
            content: '为什么有钱就可以为所欲为',
            answer: '因为有钱就是大爷 ',
            form: '选择题',
            time: '2017.11.29',
          }
        ],
        dialogTableData:[
          {
            content: '为什么有钱就可以为所欲为',
            answer: '因为有钱就是大爷 ',
            form: '选择题',
            time: '2017.11.29',

          },{
            content: '为什么有钱就可以为所欲为',
            answer: '因为有钱就是大爷 ',
            form: '选择题',
            time: '2017.11.29',
          },{
            content: '为什么有钱就可以为所欲为',
            answer: '因为有钱就是大爷 ',
            form: '选择题',
            time: '2017.11.29',
          }
        ],
        dialogTableVisible: false,
        dialogFormVisible: false,
        innerVisible: false,
        dialogSelectVisible: false,
        form: {
          name: '',
          region: '',
          date1: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          desc: ''
        },
        formLabelWidth: '120px',
        checkAll: false,
        checkedCities: ['培训课程', '资料分类'],
        currentPage4: 4,
        isIndeterminate: true,
        multipleSelection: [],
        multipleCourseSelection: []
      }
    },
    methods: {
      handleCheckAllChange(val) {
        this.checkedCities = val ? cityOptions : [];
        this.isIndeterminate = false;
      },
      handleCheckedCitiesChange(value) {
        let checkedCount = value.length;
        this.checkAll = checkedCount === this.cities.length;
        this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length;
      },
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`);
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`);
      },
      toggleSelection(type) {
        if(type === 0) {
          this.tableData.forEach((row, index) => {
            this.$refs.multipleTable.toggleRowSelection(row,true);
          });
        } else if (type === 1) {
          this.tableData.forEach((row, index) => {
            this.$refs.multipleTable.toggleRowSelection(row);
          });
        } else {
          this.$refs.multipleTable.clearSelection();
        }
      },
      toggleDialogSelection(type){
        if(type === 0) {
          this.dialogTableData.forEach((row, index) => {
            this.$refs.dialogSelectTable.toggleRowSelection(row,true);
          });
        } else if (type === 1) {
          this.dialogTableData.forEach((row, index) => {
            this.$refs.dialogSelectTable.toggleRowSelection(row);
          });
        } else {
          this.$refs.dialogSelectTable.clearSelection();
        }
      },
      deleteItems() {

      },
      importCourse () {

      },
      handleSelectionChange(val) {
        this.multipleSelection = val;
      },
      handleCourseSelectionChange(val) {
        this.multipleCourseSelection = val;
      },

    },
    created() {
      //this.loading = true;
    },
    mounted() {
      //this.loading = false;
    }
  }
</script>
