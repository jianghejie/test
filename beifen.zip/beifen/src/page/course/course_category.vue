<template>
    <div class="fillcontain">
      <div class="head-top">
        <el-breadcrumb separator="/">
        <el-breadcrumb-item>首页</el-breadcrumb-item>
        <el-breadcrumb-item>课程分类</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="main_content">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <el-button type="primary" size="small" icon="el-icon-plus"  @click="openAddForm('0')">添加学科</el-button>
          </div>
          <el-tree
            v-loading="listLoading"
            :data="treeData"
            :props="defaultProps"

            node-key="id"
            default-expand-all
            :expand-on-click-node="false"

            :render-content="renderContent" style="width:800px;">
          </el-tree>
        </el-card>
      </div>
      <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible">
        <el-form :model="form" ref="dataForm">
          <el-form-item label="名称" :label-width="formLabelWidth">
            <el-input v-model="form.name" auto-complete="off"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button v-if="dialogStatus=='create'" type="primary" @click="addData">确 定</el-button>
          <el-button v-else type="primary" @click="saveData">确 定</el-button>
        </div>
      </el-dialog>
    </div>
</template>


<script>
  import {addCourseCatgory, getCourseCatgory, getAllCourseCatgory, deleteCourseCatgory} from '@/api/table'
  import {toast, addSimpleData, deleteData, getOneForEdit, } from '@/utils/index'
  export default {
    data() {
      return {
        textMap: {
          update: '编辑',
          create: '创建'
        },
        dialogStatus: '',
        dialogFormVisible: false,
        form: {
          id:'',
          name: '',
          parentId: '',
        },
        treeData: [],
        defaultProps: {
          children: 'children',
          label: 'name'
        }
      }
    },

    created() {
      this.fetchData();
    },

    methods: {
      //打开添加表单
      openAddForm(parentId) {
        this.dialogStatus = "create"
        this.dialogFormVisible = true;
        //先清空表单中的数据（编辑的时候会留下一些数据）
        this.form = {
          name: '',
          parentId: parentId,
        }
      },

      //打开编辑表单
      openEditForm(row) {
        this.dialogStatus = "update"
        getOneForEdit(this, row.id, getCourseCatgory);
      },

      //列出分类
      fetchData() {
        this.listLoading = true
        getAllCourseCatgory().then(response => {
          const result = response.data;
          if(result.code == -1){
            this.$message({
              type: '失败',
              message: result.msg
            });
          }
          this.treeData = result.data;
          this.listLoading = false

        }).catch(function (error) {
          console.log(error);
        });
      },

      //根据id删除分类
      deleteItem(id) {
        deleteData(this, deleteCourseCatgory, id, '确定删除此分类吗?');
      },

      //添加分类
      addData() {
        addSimpleData(this, addCourseCatgory);
      },

      renderContent(h, { node, data, store }) {
        if(data.children == null){
          return (
            <span style="flex: 1; display: flex; align-items: center; justify-content: space-between; font-size: 14px; padding-right: 8px;">
              <span>
                <span>{data.name}</span>
              </span>
              <span >
                <el-button  plain  style="font-size: 12px;" type="primary" size="mini" on-click={ () => this.openAddForm(data.id) }>+子科目</el-button>
                <el-button  plain  style="font-size: 12px;" type="primary" size="mini" on-click={ () => this.deleteItem(data.id) }>删除</el-button>

              </span>
            </span>);
        } else {
          return (
            <span style="flex: 1; display: flex; align-items: center; justify-content: space-between; font-size: 14px; padding-right: 8px;">
              <span>
                <span>{data.name}</span>
              </span>
              <span>
                <el-button  plain  style="font-size: 12px;" type="primary" size="mini" on-click={ () => this.openAddForm(data.id) }>+子科目</el-button>
                <el-button  plain  style="font-size: 12px;" type="primary" size="mini" on-click={ () => this.deleteItem(data.id) }>删除</el-button>

              </span>
            </span>);
        }

      }
    }
  };
</script>
