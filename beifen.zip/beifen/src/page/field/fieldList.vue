<template>
    <div class="fillcontain">
      <div class="head-top">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item>首页</el-breadcrumb-item>
          <el-breadcrumb-item>场地管理</el-breadcrumb-item>
        </el-breadcrumb>
      </div>

      <div class="main_content">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <el-button type="primary" size="small" icon="el-icon-plus"  @click="openAddForm">添加场地</el-button>
            <el-button size="mini" @click="toggleSelection(0)">全选</el-button>
            <el-button size="mini" @click="toggleSelection(1)">反选</el-button>
            <el-button size="mini" @click="toggleSelection(2)">清除</el-button>
            <el-input class="right" placeholder="搜索" v-model="input5" style="width:230px;">
              <el-button slot="append" icon="el-icon-search"></el-button>
            </el-input>
          </div>
          <el-table
            :data="tableData"
            ref="selectTable"
            border
            style="width: 100%">
            <el-table-column
              type="selection"
              width="55">
            </el-table-column>
            <el-table-column
              prop="creatorId"
              label="创建者">
            </el-table-column>
            <el-table-column
              prop="name"
              label="场地名称">
            </el-table-column>
            <el-table-column
              prop="location"
              label="场地位置">
            </el-table-column>
            <el-table-column
              prop="catId"
              label="场地类型">
            </el-table-column>
            <el-table-column
              prop="usageCount"
              label="使用次数">
            </el-table-column>

            <el-table-column
              prop="map"
              label="地图">
              <template slot-scope="scope">
                <el-button type="text" @click="dialogMapVisible = true">查看</el-button>
              </template>
            </el-table-column>

            <el-table-column
              prop="createTime"
              label="创建时间">
            </el-table-column>
            <el-table-column
              fixed="right"
              label="操作">
              <template slot-scope="scope">
                <el-button size="mini" @click="openEditForm(scope.row.id)" type="primary" plain>编辑</el-button>
                <el-button size="mini" @click="deleteItem(scope.row.id)" type="primary" plain>删除</el-button>
              </template>
            </el-table-column>
          </el-table>
          <!-- 分页 -->
          <div class="pagination-container">
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="currentPage"
              :page-sizes="[5, 20, 50, 100]"
              :page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="totalElements">
            </el-pagination>
          </div>
        </el-card>

      </div>

      <el-dialog title="场地查看" :visible.sync="dialogMapVisible">
        <div class="amap-page-container">
          <el-amap vid="amap" :zoom="zoom" :amap-manager="amapManager" :center="center"
                   ref="map"
                   class="amap-demo">
            <el-amap-polygon v-for="(polygon, index) in polygons" :vid="index" :ref="`polygon_${index}`" :path="polygon.path" :events="polygon.events"></el-amap-polygon>
          </el-amap>
        </div>
      </el-dialog>

      <el-dialog  :title="textMap[dialogStatus]"  :visible.sync="dialogFormVisible">
        <el-form :model="form">
          <el-form-item label="类型" :label-width="formLabelWidth">
            <el-cascader
              :options="options"
              :show-all-levels="false"
              v-model="selectedOptions">
            </el-cascader>
          </el-form-item>
          <el-form-item label="名称" :label-width="formLabelWidth">
            <el-input v-model="form.name"  auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="创建者" :label-width="formLabelWidth">
            <el-input v-model="form.creatorId"  auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="位置" :label-width="formLabelWidth">
            <el-input v-model="form.location"  auto-complete="off"></el-input>
          </el-form-item>

          <el-form-item label="点" :label-width="formLabelWidth">
            <el-input v-model="form.points"  auto-complete="off"></el-input>
          </el-form-item>

          <el-form-item label="备注" :label-width="formLabelWidth">
            <el-input
              type="textarea"
              :rows="2"
              placeholder="请输入内容"
              v-model="form.description">
            </el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button v-if="dialogStatus=='create'" type="primary" @click="addItem">确 定</el-button>
          <el-button v-else type="primary" @click="saveItem">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </template>
<style>
  .amap-demo {
    height: 300px !important;
  }
</style>
  <script>
    import AMap from 'vue-amap';
    import {getFieldByPage, deleteField, addField, getField, saveField, getAllCourseCatgory} from '@/api/table'
    import {toast, formatTime, addSimpleData, deleteData, getOneForEdit, saveData} from '@/utils/index'
    let amapManager = new AMap.AMapManager();

    export default {
      created(){

      },
      data() {
        return {
          zoom: 30,
          center: [116.167863,40.19696],
          amapManager: amapManager,
          polygons: [
            {
              path: [[116.167863,40.19696], [116.167762,40.197022], [116.167689,40.196948], [116.167596,40.197008], [116.167525,40.196936], [116.167613,40.196874],[116.167781,40.196888],[116.167863,40.19696]],
              events: {
                click: () => {
                  console.log(amapManager.getComponent(0));
                  console.log(this.$refs.map.$$getCenter())
                  console.log(this.$refs.polygon_0[0].$$getPath())
                }
              }
            }
          ],
          tableData: [],
//          tableData: [{
//            creator: '陈向军',
//            name: '20171028十号场',
//            location: '福建',
//            type: '八字飞行，悬停训练',
//            ucount: '600',
//            state: '使用中',
//            map: '117.702276,39.061358',
//
//            create_time: '2017-08-21 17:43:54'
//          }],

          //对话框
          dialogFormVisible: false,
          dialogMapVisible: false,
          textMap: {
            update: '编辑',
            create: '创建'
          },
          dialogStatus: '',

          //表单
          form: {
            name: '',
            location: '',
            catId: '',
            points: '',
            creatorId:"",
            description: false,
          },
          formLabelWidth: '120px',

          //选项
          options: [],
          selectedOptions: [],

          //分页相关
          currentPage: 0,
          pageSize: 5,
          totalElements: 0,
        }
      },

      created() {
        this.fetchData(this.currentPage, this.pageSize);
        this.getCategory();
      },

      watch: {
        selectedOptions: function (newSelectedOptions) {
          this.form.catId = newSelectedOptions[newSelectedOptions.length-1];
        },
      },


      methods: {
        //打开添加表单
        openAddForm() {
          this.dialogStatus = "create"
          this.dialogFormVisible = true;
          //清空表单数据
          for (let key in this.form) {
            this.form[key] = ""
          }
          this.selectedOptions = [];
        },

        //打开编辑表单
        openEditForm(id) {
          this.dialogStatus = "update"
          this.selectedId = id;
          var callBack = function () {
            this.selectedOptions = this.getCateRout(this.options, this.form.catId);
          };
          getOneForEdit(this, id, getField, callBack.bind(this));
        },

        //根据id删除
        deleteItem(id) {
          deleteData(this, deleteField, id, '确定删除此场地吗?');
        },

        //添加
        addItem() {
          addSimpleData(this, addField);
        },

        //编辑
        saveItem() {
          saveData(this, saveField, this.selectedId);
        },

        //分页查询
        fetchData(page, size) {
          this.listLoading = true
          getFieldByPage(page, size).then(response => {
            const result = response.data;
            if(result.code == -1){
              this.$message({
                type: '失败',
                message: result.msg
              });
            }
            var temp = result.data.content;
            this.totalElements = result.data.totalElements;
            this.tableData = [];
            if(temp.length != 0){
              temp.forEach((item, index) => {
                const tableItem = {
                  id:item.id,
                  creatorId:item.creatorId,
                  name: item.name,
                  location: item.location,
                  description: item.description,
                  points: item.points,
                  catId:item.catId,
                  usageCount:item.usageCount == null ? 0 : item.usageCount,
                  createTime:formatTime(item.createTime),
                }
                this.tableData.push(tableItem)
              })
            } else {

            }

          }).catch(function (error) {
            console.log(error);
          });
          this.listLoading = false
        },

        //列出分类
        getCategory() {
          getAllCourseCatgory().then(response => {
            const result = response.data;
            if(result.code == -1){
              this.$message({
                type: '失败',
                message: result.msg
              });
            }
            const categoryList = result.data;
            this.options = [];
            this.options = this.refining(categoryList);
            console.log(this.options);
          }).catch(function (error) {
            console.log(error);
          });
        },

        refining(nestJson) {
          var opts = [];
          for (var i = 0; i < nestJson.length; i++) {
            var optionItem = {
              value: nestJson[i].id,
              label: nestJson[i].name,
              //为了便于查找一个分类的完整路径加上cateCode，注意这里数据库的命名有点不统一
              catCode: this.parseCatCode(nestJson[i].cateCode),
            };

            if (nestJson[i].children) {
              optionItem.children = this.refining(nestJson[i].children);
            }
            opts.push(optionItem);
          }
          return opts;
        },

        //根据catid获得完整分类路径
        getCateRout(nestJson, catId) {
          var opts;
          for (var i = 0; i < nestJson.length; i++) {
            if(catId == nestJson[i].value){
              opts = nestJson[i].catCode
              return opts;
            }
            if (nestJson[i].children) {
              var temp = this.getCateRout(nestJson[i].children, catId)
              if(temp != null)
                opts = temp
            }
          }
          return opts;
        },

        //把catecode解析成cascader能读取的形式,如[id1, id2, id3]
        parseCatCode(code){
          var fullPath = []
          for(var i = 0; i < code.length/32; i++){
            fullPath.push(code.substring(i*32, (i+1)*32))
          }
          return fullPath
        },

        //全选，不选，反选
        toggleSelection(type){
          if(type === 0) {
            this.tableData.forEach((row, index) => {
              this.$refs.selectTable.toggleRowSelection(row,true);
            });
          } else if (type === 1) {
            this.tableData.forEach((row, index) => {
              this.$refs.selectTable.toggleRowSelection(row);
            });
          } else {
            this.$refs.selectTable.clearSelection();
          }
        },
      }
    }
  </script>
