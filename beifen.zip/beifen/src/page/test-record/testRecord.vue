<template>
  <div class="fillcontain">
    <div class="head-top">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item>首页</el-breadcrumb-item>
        <el-breadcrumb-item>题库</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="main_content">
      <TtaListView
        :getPage="getQuestionByPage"
        :tableInfo="tableInfo"
        :formInfo="formInfo"
        :form="form"
        :addOne="addQuestion"
        :getOne="getQuestion"
        :saveOne="saveQuestion"
        :deleteOne="deleteQuestion"
        :renderDialog="renderForm"
        title="考试记录"></TtaListView>
    </div>
  </div>
</template>

<script>
  import {getQuestionByPage, deleteQuestion, addQuestion, getQuestion, saveQuestion, getAllCourseCatgory} from '@/api/table'
  import {toast, formatTime, addSimpleData, deleteData, getOneForEdit, saveData} from '@/utils/index'
  import TtaListView from '@/components/TtaListView';
  import SelectEditor from '@/components/SelectEditor';
  import SelectView from '@/components/SelectView';
  export default {
    components: {
      TtaListView,
      SelectEditor
    },
    data() {
      return {
        //表格
        tableInfo: [
          {property: 'userName', description: '考生'},
          {property: 'plane', description: '飞机'},
          {property: 'score', description: '评分'},
          {property: 'flyTime', description: '飞行时间'},
          {property: 'subject', description: '科目'},
          {property: 'outOffset', description: '内偏移'},
          {property: 'innerOffset', description: '外偏移'},
          {property: 'examiner', description: '考官'},
          {property: 'height', description: '高度'},
          {property: 'flyDuration', description: '飞行时长'},
          {property: 'id', description: '操作', renderContent: this.renderAction},
        ],
        tableData: [
          {id: '666666', userName: '9527', plane: '李跃02', score: '71', flyTime: '2分', subject: '悬停', outOffset: '2.17', innerOffset: '1.17',
            examiner: '董超', height: '100', flyDuration: '200'},
          {id: '888', userName: '9527', plane: '李跃02', score: '71', flyTime: '6分', subject: '悬停', outOffset: '2.17', innerOffset: '1.17',
            examiner: '董超', height: '100', flyDuration: '200'},
          {id: '111', userName: '9527', plane: '李跃02', score: '71', flyTime: '2分', subject: '悬停', outOffset: '2.17', innerOffset: '1.17',
            examiner: '董超', height: '100', flyDuration: '200'},
          {id: '333', userName: '9527', plane: '李跃02', score: '71', flyTime: '2分', subject: '悬停', outOffset: '2.17', innerOffset: '1.17',
            examiner: '董超', height: '100', flyDuration: '200'},
          {id: '666666', userName: '9527', plane: '李跃02', score: '71', flyTime: '2分', subject: '悬停', outOffset: '2.17', innerOffset: '1.17',
            examiner: '董超', height: '100', flyDuration: '200'},
        ],
        getQuestionByPage: getQuestionByPage,
        addQuestion: addQuestion,
        getQuestion: getQuestion,
        saveQuestion: saveQuestion,
        deleteQuestion: deleteQuestion,

        //表单
        form: {
          userName: '',
          plane: '',
          score: 0,
          flyTime: '',
          catCourseId: '',
        },

        //
        dialogFormVisible: false,
        textMap: {
          update: '编辑',
          create: '创建'
        },
        dialogStatus: '',


        formLabelWidth: '120px',

        //选项
        options: [],
        typeOptions: [{value:0, label:"选择题"}],
        selectedOptions: [],

        //分页相关
        currentPage: 0,
        pageSize: 5,
        totalElements: 0,

      }
    },

    created() {
      //this.fetchData(this.currentPage, this.pageSize);
      //this.getCategory();

    },

    methods: {
      updateSelection(value){
        this.form.selection = value;
      },
      updateType(value){
        this.form.typeId = value;
      },
      renderForm(h, form) {
       return <el-form>
        <el-form-item label ="姓名" label-width={this.formLabelWidth}>
          <el-input v-model={form.userName}></el-input>
        </el-form-item>

        <el-form-item label="飞机" label-width={this.formLabelWidth}>
          <el-input v-model={form.plane}></el-input>
        </el-form-item>

        <el-form-item label="评分" label-width={this.formLabelWidth}>
          <el-input v-model={form.score}></el-input>
        </el-form-item>
        </el-form>
      },
    }
  }
</script>
