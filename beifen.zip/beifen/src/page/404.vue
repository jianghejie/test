<template>
    <div class="fillcontain">
      <div class="head-top">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item :to="{ path: '/index' }">首页</el-breadcrumb-item>
          <el-breadcrumb-item>404</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="main_content">
        404
      </div>

    </div>
  </template>

  <script>
    import {getAllBlog} from '@/api/getData'
    export default {
      data() {
        return {
          tableData: [],
          dialogTableVisible: false,
          dialogFormVisible: false,
          form: {
            name: '',
            region: '',
            date1: '',
            date2: '',
            delivery: false,
            type: [],
            resource: '',
            desc: ''
          },
          formLabelWidth: '120px',
          checkAll: false,
          checkedCities: ['培训课程', '资料分类'],
          isIndeterminate: true
        }
      },
      created(){
        this.initData();
      },
      methods: {
        async initData(){
            try{
                this.getAllBlogs();
            }catch(err){
                console.log('获取数据失败', err);
            }
        },
      async getAllBlogs(){
            try{
                const blogs = await getAllBlog();
                this.tableData = [];
                blogs.forEach(item => {
                  const tableItem = {
                    title: item.title,
                    content: item.content,
                    thumbnail: item.thumbnail,
                    time: item.time,
                  }
                  this.tableData.push(tableItem)
                })
            }catch(err){
                console.log('获取数据失败', err);
            }
        },
        handleCheckAllChange(val) {
          this.checkedCities = val ? cityOptions : [];
          this.isIndeterminate = false;
        },
        handleCheckedCitiesChange(value) {
          let checkedCount = value.length;
          this.checkAll = checkedCount === this.cities.length;
          this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length;
        },
        open() {
          this.$confirm('此操作将永久删除该角色, 是否继续?', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
          }).then(() => {
          this.$message({
              type: 'success',
              message: '删除成功!'
            });
          }).catch(() => {

          });
        }
      }
    }
  </script>
