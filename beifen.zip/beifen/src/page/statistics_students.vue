<template>
    <div class="fillcontain">
        <div class="head-top">
          <el-breadcrumb separator="/">
            <el-breadcrumb-item :to="{ path: '/index' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>学员统计</el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        <div class="main_content">
          <el-row :gutter="30">
            <el-col :span="12">
              <div class="grid-content bg-purple">
                <div class="chart-box">
                  <div class="chart-box-title">学员分布<span></span></div>
                  <div id="map" class="chart"></div>
                </div>
              </div>
            </el-col>
            <el-col :span="12">
              <div class="grid-content bg-purple">
                <div class="chart-box">
                  <div class="chart-box-title">整体进度<span></span></div>
                  <div id="progress" class="chart"></div>
                </div>
              </div>
            </el-col>
          </el-row>
          <el-row :gutter="30">
            <el-col :span="12">
              <div class="grid-content bg-purple">
                <div class="chart-box">
                  <div class="chart-box-title">旷课情况<span></span></div>
                  <div  id="absent" class="chart"></div>
                </div>
              </div>
            </el-col>
            <el-col :span="12">
              <div class="grid-content bg-purple">
                <div class="chart-box">
                  <div class="chart-box-title">...<span></span></div>
                  <div   class="chart"></div>
                </div>
              </div>
            </el-col>
          </el-row>
        </div>
    </div>
</template>

<script>
    import echarts from 'echarts/lib/echarts';
    import china from 'echarts/map/js/china'
    // 引入柱状图
    import 'echarts/lib/chart/bar';
    import 'echarts/lib/chart/line';
    import 'echarts/lib/component/title';
    import 'echarts/lib/component/legend';
    import 'echarts/lib/component/toolbox';
    import 'echarts/lib/component/markPoint';
    import 'echarts/lib/component/tooltip';
    export default {
        mounted(){
            this.drawProgress();
            this.drawMap();
            this.drawAbsent();
        },
        props: ['sevenDate', 'sevenDay'],
        methods: {
          drawMap(){
            this.myChart = echarts.init(document.getElementById('map'));
            var myData = [

              {name: '海门', value: [121.15, 31.89, 60]},
              {name: '鄂尔多斯', value: [109.781327, 39.608266, 30]},
              {name: '招远', value: [120.38, 37.35, 60]},
              {name: '舟山', value: [122.207216, 29.985295, 80]},
            ]

            var option = {
              tooltip: {
                trigger: 'item',
                formatter: function(params) {
                  return params.name + ' : ' + params.value[2];
                }
              },
              legend: {
                show: false
              },
              visualMap: {
                min: 50,
                max: 100,
                bottom: 50,
                dimension: 2,
                splitNumber: 5,
                calculable: true,
                inRange: {
                  color: ['#255B78', '#2A7484', '#2F9696', '#3BBCB0', '#51D4EB'],

                },
                outOfRange:{  //定义 在选中范围外 的视觉元素。

                },
                textStyle: {
                  color: '#fff'
                }
              },
              geo: {
                map: 'china',
                label: {
                  emphasis: {
                    show: false
                  }
                },
                itemStyle: {					// 定义样式
                  normal: {					// 普通状态下的样式
                    areaColor: '#c6c6c6',
                    borderColor: '#ececec'
                  },
                  emphasis: {					// 高亮状态下的样式
                    areaColor: '#2a333d'
                  }
                }
              },
              backgroundColor: '#ffffff',
              series: [
                {
                  name: '销量',
                  type: 'scatter',
                  coordinateSystem: 'geo',
                  symbolSize: function(val) {
                    return val[2] / 3;
                  },
                  itemStyle: {
                    normal:{
                      borderColor: '#c6c6c6',
                      borderWidth: 1,
                      opacity: 0.6
                    },
                    emphasis: {
                      borderColor: '#fff',
                      borderWidth: 1
                    },
                    label: {
                      show: true
                    },
                  },
                  data: myData // series数据内容
                }
              ]
            }
            this.myChart.setOption(option);
          },
          drawProgress(){
            this.myChart = echarts.init(document.getElementById('progress'));
            var seriesLabel = {
              normal: {
                show: true,
                textBorderColor: '#333',
                textBorderWidth: 2
              }
            };
            var option = {
              title: {
                text: ''
              },
              tooltip: {
                trigger: 'axis'
              },
              legend: {
                data: ['AOPA一期学员进度']
              },
              toolbox: {
                show: true,
                feature: {
                  mark: {show: true},
                  dataView: {show: true, readOnly: false},
                  magicType: {show: true, type: ['line', 'bar']},
                  restore: {show: true},
                  saveAsImage: {show: true}
                }
              },
              calculable: true,
              xAxis: [
                {
                  type: 'value',
                  splitArea: {show: true},
                  boundaryGap: [0, 0.01],
                  max: 28
                }
              ],
              yAxis: [
                {
                  type: 'category',
                  data: ['张三', '李四', '王明', '学员3', '学员1', '学员2']
                }
              ],
              series: [
                {
                  clickable: true,
                  name: '学员进度',
                  label: seriesLabel,
                  type: 'bar',
                  data: [2, 5, 28, 5, 15, 10],
                  itemStyle: {
                    normal: {
                      color: '#409EFF',
                    },
                    label: {
                      show: true
                    }
                  },
                }
              ]
            };
            this.myChart.setOption(option);
          },
          drawAbsent() {
            this.myChart = echarts.init(document.getElementById('absent'));
            var option = {
              title: {
                text: ' '
              },
              tooltip: {
                trigger: 'axis'
              },
              legend: {
                data:['旷课','请假']
              },
              grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
              },
              toolbox: {
                feature: {
                  saveAsImage: {}
                }
              },
              xAxis: {
                type: 'category',
                boundaryGap: false,
                data: ['2017.11.17','2017.11.18','2017.11.19','2017.11.20','2017.11.21','2017.11.22','2017.11.23']
              },
              yAxis: {
                type: 'value'
              },
              series: [
                {
                  name:'旷课',
                  type:'line',
                  data:[5, 3, 2, 6, 8, 5, 1]
                },
                {
                  name:'请假',
                  type:'line',
                  data:[5, 20, 30, 15, 14, 11, 30]
                }
              ]
            };
            this.myChart.setOption(option);
          }
        },
        watch: {
            sevenDate: function (){
                this.initData()
            },
            sevenDay: function (){
                this.initData()
            }
        }
    }
</script>

<style lang="less">
	@import '../style/mixin';
    .line1{
        display: flex;
        justify-content: center;
    }
  .chart-box{
    width:100%;
    height: 500px;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #e3e3e3;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;
  }
  .chart{
    width:100%;
    height: 400px;
  }
</style>

